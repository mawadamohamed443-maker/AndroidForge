package com.nico.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Person(val id: String, var name: String, var phone: String = "", var photo: String = "", var voice: FloatArray? = null, var owner: Boolean = false, var birthday: String = "", var relation: String = "")

/** الأشخاص: اسم + صورة + رقم (لواتساب) + بصمة صوت. بيتخزنوا محلياً بس. */
class People(private val ctx: Context) {
    private val f = File(ctx.filesDir, "people.json")
    val list: MutableList<Person> = load()

    private fun load(): MutableList<Person> = try {
        val a = JSONArray(f.readText()); val out = ArrayList<Person>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val v = o.optJSONArray("voice")?.let { arr -> FloatArray(arr.length()) { arr.getDouble(it).toFloat() } }
            out.add(Person(o.getString("id"), o.getString("name"), o.optString("phone"), o.optString("photo"), v, o.optBoolean("owner"), o.optString("birthday"), o.optString("relation")))
        }
        out
    } catch (_: Exception) { mutableListOf() }

    fun save() {
        val a = JSONArray()
        list.forEach { p ->
            val o = JSONObject().put("id", p.id).put("name", p.name).put("phone", p.phone).put("photo", p.photo).put("owner", p.owner).put("birthday", p.birthday).put("relation", p.relation)
            p.voice?.let { v -> o.put("voice", JSONArray(v.map { it.toDouble() })) }
            a.put(o)
        }
        try { f.writeText(a.toString()) } catch (_: Exception) {}
    }

    fun add(name: String): Person { val p = Person(System.currentTimeMillis().toString(), name); list.add(p); save(); return p }
    fun remove(p: Person) { list.remove(p); try { File(p.photo).delete() } catch (_: Exception) {}; save() }
    fun owner(): Person? = list.firstOrNull { it.owner }

    fun byName(spoken: String): Person? {
        val q = Skills.norm(spoken).trim(); if (q.isBlank()) return null
        list.firstOrNull { Skills.norm(it.name) == q }?.let { return it }
        list.firstOrNull { val n = Skills.norm(it.name); n.contains(q) || q.contains(n) }?.let { return it }
        return list.firstOrNull { Mix.lev(Skills.norm(it.name), q) <= 1 && q.length >= 3 }
    }
}

