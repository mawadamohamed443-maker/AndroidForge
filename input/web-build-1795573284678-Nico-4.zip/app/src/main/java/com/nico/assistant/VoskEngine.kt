package com.nico.assistant

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.SystemClock
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * تعرف على الصوت أوفلاين (Vosk) بعدة لغات. كل لغة بتتنزل أو بتتستورد مرة واحدة وبعدها بتشتغل من غير نت.
 * الاستماع بميكروفون بنفتحه احنا (AudioRecord) من غير ما نعتمد على أي كلاسات تانية في مكتبة Vosk.
 */
class VoskEngine(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("nico", Context.MODE_PRIVATE)
    private val models = HashMap<String, Model>()
    private var worker: Thread? = null

    @Volatile
    var listening = false
        private set

    var lang: String
        get() = prefs.getString("lang", "ar") ?: "ar"
        set(v) { prefs.edit().putString("lang", v).apply() }

    fun dirFor(code: String) = File(ctx.filesDir, "vosk/$code")
    private fun valid(d: File) = File(d, "am").isDirectory && File(d, "conf").isDirectory
    fun installed(code: String) = valid(dirFor(code))
    fun installedLangs(): List<Lang> = Langs.all.filter { installed(it.code) }
    fun available() = installed(lang)

    /** بيحمّل موديل اللغة الحالية في الرام. بيرجع null لو نجح، أو رسالة الخطأ. */
    @Synchronized
    fun prepare(): String? {
        val code = lang
        if (models.containsKey(code)) return null
        if (!installed(code)) return "اللغة دي مش منزلة. نزّليها أو استوردي موديلها من زر اللغات."
        return try {
            models[code] = Model(dirFor(code).absolutePath)
            null
        } catch (e: Throwable) {
            "فشل تحميل موديل الصوت: ${e.message}"
        }
    }

    @Synchronized
    fun drop(code: String) {
        val m = models.remove(code)
        try { m?.close() } catch (_: Throwable) {}
    }

    fun delete(code: String) { stop(); drop(code); dirFor(code).deleteRecursively() }

    // ---------- تثبيت / تنزيل ----------
    private class Counting(i: InputStream, val onBytes: (Long) -> Unit) : FilterInputStream(i) {
        var n = 0L
        override fun read(): Int { val r = super.read(); if (r >= 0) { n++; onBytes(n) }; return r }
        override fun read(b: ByteArray, off: Int, len: Int): Int { val r = super.read(b, off, len); if (r > 0) { n += r; onBytes(n) }; return r }
    }

    /** بيفك zip الموديل لفولدر اللغة. بيرجع null لو نجح. */
    fun installStream(code: String, input: InputStream, progress: (String) -> Unit): String? {
        stop(); drop(code)
        val tmp = File(ctx.filesDir, "vosk-tmp-$code")
        return try {
            tmp.deleteRecursively(); tmp.mkdirs()
            val root = tmp.canonicalPath + File.separator
            var n = 0
            ZipInputStream(input.buffered()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val f = File(tmp, e.name)
                    if (!f.canonicalPath.startsWith(root)) continue // حماية zip-slip
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { o -> z.copyTo(o, 1 shl 20) }
                        n++
                        if (n % 15 == 0) progress("بفك الموديل… $n ملف")
                    }
                }
            }
            val src = tmp.walkTopDown().firstOrNull { it.isDirectory && valid(it) }
                ?: return "الملف ده مش موديل Vosk صحيح (لازم فيه فولدرات am و conf)."
            val dst = dirFor(code)
            dst.deleteRecursively(); dst.parentFile?.mkdirs()
            if (!src.renameTo(dst)) src.copyRecursively(dst, true)
            null
        } catch (e: Throwable) {
            "فشل التثبيت: ${e.message}"
        } finally {
            tmp.deleteRecursively()
        }
    }

    /** تنزيل لغة من النت (أول مرة بس). */
    fun download(l: Lang, progress: (String) -> Unit): String? {
        var c: HttpURLConnection? = null
        return try {
            val conn = URL(Langs.url(l)).openConnection() as HttpURLConnection
            c = conn
            conn.connectTimeout = 15000; conn.readTimeout = 30000; conn.instanceFollowRedirects = true
            if (conn.responseCode != 200) return "السيرفر رد بكود ${conn.responseCode}. جربي بعدين."
            val total = if (conn.contentLengthLong > 0) conn.contentLengthLong else l.mb * 1_000_000L
            var last = 0L
            val cin = Counting(conn.inputStream) { n ->
                val now = System.currentTimeMillis()
                if (now - last > 400) { last = now; progress("بنزّل ${l.label}… ${minOf(99L, n * 100 / total)}%") }
            }
            installStream(l.code, cin, progress)
        } catch (e: java.io.IOException) {
            "مفيش اتصال بالنت أو الاتصال اتقطع. التنزيل بيحتاج نت أول مرة بس."
        } catch (e: Throwable) {
            "فشل التنزيل: ${e.message}"
        } finally {
            try { c?.disconnect() } catch (_: Throwable) {}
        }
    }

    // ---------- الاستماع ----------
    fun stop() { listening = false }

    /**
     * بيسمع لحد ما يخلص جملة (أو 15 ثانية). الـ callbacks بتتنادى من thread خلفي.
     * لازم prepare() تكون رجّعت null قبلها، وإذن المايك يكون متاح.
     */
    fun listen(onPartial: (String) -> Unit, onFinal: (String) -> Unit, onError: (String) -> Unit) {
        val model: Model = synchronized(this) { models[lang] } ?: run { onError("الموديل مش محمّل."); return }
        if (listening) return
        listening = true
        val t = Thread {
            var rec: AudioRecord? = null
            var r: Recognizer? = null
            try {
                val sr = 16000
                val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val ar = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000))
                rec = ar
                if (ar.state != AudioRecord.STATE_INITIALIZED) { onError("المايك مش متاح دلوقتي."); return@Thread }
                val recognizer = VoskCompat.newRecognizer(model, sr.toFloat())
                r = recognizer
                val buf = ShortArray(1600)
                val start = SystemClock.elapsedRealtime()
                var lastPartial = ""
                ar.startRecording()
                var done = false
                while (listening && !done && SystemClock.elapsedRealtime() - start < 15000) {
                    val k = ar.read(buf, 0, buf.size)
                    if (k <= 0) continue
                    if (VoskCompat.feed(recognizer, buf, k)) {
                        val text = VoskCompat.text(recognizer.result)
                        if (text.isNotBlank()) { listening = false; done = true; onFinal(text) }
                    } else {
                        val p = VoskCompat.partial(recognizer.partialResult)
                        if (p.isNotBlank() && p != lastPartial) { lastPartial = p; onPartial(p) }
                    }
                }
                if (listening && !done) {
                    listening = false
                    onFinal(VoskCompat.text(recognizer.finalResult))
                }
            } catch (e: Throwable) {
                onError(e.message ?: "خطأ في الميكروفون")
            } finally {
                listening = false
                try { rec?.stop() } catch (_: Throwable) {}
                try { rec?.release() } catch (_: Throwable) {}
                VoskCompat.close(r)
            }
        }
        t.name = "nico-vosk"
        worker = t
        t.start()
    }
}
