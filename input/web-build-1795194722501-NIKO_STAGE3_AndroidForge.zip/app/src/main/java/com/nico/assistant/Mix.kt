package com.nico.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings

/** دمج اللغات: أفعال إنجليزي جوه جملة عربي، أسماء تطبيقات بالعربي/الإنجليزي، وفتح شات واتساب بالاسم. */
object Mix {
    private val verbs = mapOf(
        "open" to "افتح", "launch" to "افتح", "start" to "شغل", "play" to "شغل", "stop" to "وقف", "close" to "اقفل",
        "call" to "اتصل", "answer" to "رد", "reject" to "ارفض", "decline" to "ارفض", "back" to "ارجع",
        "اوبن" to "افتح", "كول" to "اتصل", "apri" to "افتح", "ouvre" to "افتح", "abre" to "افتح", "öffne" to "افتح")

    fun normalize(t: String): String = t.trim().split(Regex("\\s+")).joinToString(" ") { verbs[it.lowercase()] ?: it }

    fun lev(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private fun lctx(ctx: Context): Context = NicoAccessibilityService.inst ?: ctx
    private fun go(ctx: Context, i: Intent): Boolean = try { lctx(ctx).startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true } catch (_: Exception) { false }

    private fun appIntent(name: String): Intent? = when (name) {
        in setOf("phone", "dialer", "فون", "الفون", "الهاتف", "هاتف", "تليفون", "التليفون", "الاتصال", "الارقام", "telefono", "telephone") -> Intent(Intent.ACTION_DIAL)
        in setOf("contacts", "جهات الاتصال", "الكونتاكت", "كونتاكت", "الاسماء", "الاسامي", "rubrica", "contatti") -> Intent(Intent.ACTION_VIEW, ContactsContract.Contacts.CONTENT_URI)
        in setOf("messages", "sms", "الرسايل", "الرسائل", "رسايل", "المسجات", "مسجات", "messaggi") -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MESSAGING)
        in setOf("camera", "كاميرا", "الكاميرا", "fotocamera") -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
        in setOf("settings", "الاعدادات", "اعدادات", "impostazioni") -> Intent(Settings.ACTION_SETTINGS)
        else -> null
    }

    /** "افتح phone" / "open الكاميرا" ... بيرجع رسالة لو اتنفذ، وإلا null عشان باقي النظام يكمل. */
    fun tryOpen(ctx: Context, raw: String): String? {
        val q = Skills.norm(normalize(raw))
        val m = Regex("^(?:افتح|شغل)\\s*(?:تطبيق|app)?\\s*(.+)$").find(q) ?: return null
        val name = m.groupValues[1].trim()
        val i = appIntent(name) ?: return null
        return if (go(ctx, i)) "بفتح $name." else null
    }

    private fun waNumber(p: String): String? {
        var d = p.filter { it.isDigit() }
        if (d.isEmpty()) return null
        if (d.startsWith("00")) d = d.drop(2) else if (d.startsWith("0") && d.length == 11) d = "20" + d.drop(1)
        return d
    }

    /** "افتح شات ماما واتساب" - بيفتح محادثة الشخص (لو ليه رقم). بيرجع null لو مش متاح (الوكيل ممكن يكمل). */
    fun whatsapp(ctx: Context, raw: String, speaker: Person?, people: People): String? {
        val q = Skills.norm(raw)
        if (!(q.contains("واتس") || q.contains("whatsapp"))) return null
        if (!(q.contains("شات") || q.contains("محادث") || q.contains("chat"))) return null
        val stop = setOf("افتح", "روح", "ادخل", "شات", "chat", "محادثه", "محادثات", "مع", "علي", "على", "في", "ف", "واتس", "واتساب", "اب", "whatsapp", "بتاع", "بتاعه", "open")
        val name = q.split(" ").filter { it !in stop }.joinToString(" ").trim()
        val mine = name.contains("شاتي") || name.contains("بتاعي")
        val p: Person = (if (mine) speaker else people.byName(name)) ?: return null
        val num = waNumber(p.phone) ?: return null
        val uri = Uri.parse("https://wa.me/$num")
        val ok = go(ctx, Intent(Intent.ACTION_VIEW, uri).setPackage("com.whatsapp")) || go(ctx, Intent(Intent.ACTION_VIEW, uri))
        return if (ok) "بفتح شات ${p.name}." else null
    }
}
