package com.nico.assistant

import android.content.SharedPreferences
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale


object Mood {
    fun fromText(t: String): Emotion {
        val q = Skills.norm(t)
        return when {
            Regex("ههه|هه هه|نكته|نكت |ضحك|اضحك|😂|🤣").containsMatchIn(q) -> Emotion.LAUGH
            Regex("مقدرتش|معرفتش|ملقتش|فشل|للاسف|مش قادر|حزين|وحشتني|تعبان").containsMatchIn(q) -> Emotion.SAD
            Regex("شكرا|بحبك|جميل|برافو|يا قمر|ذكي|عظيم").containsMatchIn(q) -> Emotion.SHY
            Regex("واو|ايه ده|معقول|بجد\\?|!\\?|\\?!").containsMatchIn(q) -> Emotion.SURPRISED
            Regex("عملته|تمام|خلصت|اتعمل|حاضر|بفتح|اهلا|يا هلا|ازيك|صباح|مساء").containsMatchIn(q) -> Emotion.HAPPY
            Regex("هفكر|ثانيه|استني|لحظه").containsMatchIn(q) -> Emotion.THINK
            else -> Emotion.NEUTRAL
        }
    }
}

/** اختيار أحسن صوت متاح أوفلاين + نبرة حسب المشاعر عشان الصوت ما يبقاش روبوتي. */
object Voices {
    fun forLang(tts: TextToSpeech, l: Lang): List<Voice> = try {
        val lc = Locale.forLanguageTag(l.tag).language
        (tts.voices ?: emptySet()).filter { it.locale.language == lc }
            .sortedWith(compareBy<Voice>({ it.isNetworkConnectionRequired }, { -it.quality }, { if (it.locale.country.equals(l.tag.substringAfter('-'), true)) 0 else 1 }))
    } catch (_: Throwable) { emptyList() }

    fun apply(tts: TextToSpeech, l: Lang, prefs: SharedPreferences) {
        try { tts.setLanguage(Locale.forLanguageTag(l.tag)) } catch (_: Throwable) {}
        val vs = forLang(tts, l)
        val saved = prefs.getString("voice_${l.code}", null)
        val best = vs.firstOrNull { it.name == saved } ?: vs.firstOrNull()
        if (best != null) try { tts.voice = best } catch (_: Throwable) {}
    }

    fun prosody(tts: TextToSpeech, e: Emotion, prefs: SharedPreferences) {
        val base = floatArrayOf(0.85f, 1f, 1.2f)[prefs.getInt("rate", 1).coerceIn(0, 2)]
        val (p, r) = when (e) {
            Emotion.HAPPY -> 1.08f to 1.04f
            Emotion.LAUGH -> 1.15f to 1.08f
            Emotion.SURPRISED -> 1.18f to 1.05f
            Emotion.SAD -> 0.92f to 0.88f
            Emotion.THINK -> 0.98f to 0.95f
            Emotion.SHY -> 1.1f to 0.95f
            Emotion.ANGRY -> 0.94f to 1.12f
            else -> 1f to 1f
        }
        try { tts.setPitch(p); tts.setSpeechRate(base * r) } catch (_: Throwable) {}
    }
}
