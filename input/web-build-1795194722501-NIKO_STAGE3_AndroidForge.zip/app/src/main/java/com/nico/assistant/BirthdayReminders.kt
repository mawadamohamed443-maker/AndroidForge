package com.nico.assistant

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

object BirthdayReminders {
    private const val CHANNEL = "nico_birthdays"
    private fun requestCode(id: String) = id.hashCode()
    fun schedule(ctx: Context, p: Person) {
        if (p.birthday.isBlank()) { cancel(ctx, p.id); return }
        val parts = p.birthday.split("-")
        if (parts.size != 3) return
        if (parts[0].length != 4 || parts[0].toIntOrNull() == null) return
        val month = parts[1].toIntOrNull() ?: return
        val day = parts[2].toIntOrNull() ?: return
        val now = Calendar.getInstance()
        val next = Calendar.getInstance().apply {
            clear()
            set(Calendar.YEAR, now.get(Calendar.YEAR))
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, 9)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            isLenient = false
        }
        try { next.timeInMillis } catch (_: Exception) {
            if (month == 2 && day == 29) { next.isLenient = true; next.set(Calendar.DAY_OF_MONTH, 28) }
            else return
        }
        if (!next.after(now)) {
            next.set(Calendar.YEAR, now.get(Calendar.YEAR) + 1)
            try { next.timeInMillis } catch (_: Exception) {
                next.set(Calendar.MONTH, Calendar.FEBRUARY)
                next.set(Calendar.DAY_OF_MONTH, 28)
            }
        }
        val at = next.timeInMillis
        val intent = Intent(ctx, BirthdayReceiver::class.java).putExtra("id", p.id).putExtra("name", p.name)
        val pi = PendingIntent.getBroadcast(ctx, requestCode(p.id), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else am.set(AlarmManager.RTC_WAKEUP, at, pi)
    }
    fun cancel(ctx: Context, id: String) {
        val pi = PendingIntent.getBroadcast(ctx, requestCode(id), Intent(ctx, BirthdayReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) (ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pi)
    }
    fun rescheduleAll(ctx: Context) {
        val people = People(ctx)
        people.list.forEach { schedule(ctx, it) }
    }
    fun notify(ctx: Context, name: String) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CHANNEL, "أعياد الميلاد", NotificationManager.IMPORTANCE_DEFAULT))
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("عيد ميلاد سعيد")
            .setContentText("النهارده عيد ميلاد $name")
            .setAutoCancel(true).build()
        try { nm.notify(name.hashCode(), n) } catch (_: SecurityException) {}
    }
}

class BirthdayReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra("id") ?: return
        val p = People(context).list.firstOrNull { it.id == id } ?: return
        BirthdayReminders.notify(context, p.name)
        BirthdayReminders.schedule(context, p)
    }
}
class BirthdayBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED || intent.action == Intent.ACTION_MY_PACKAGE_REPLACED)
            BirthdayReminders.rescheduleAll(context)
    }
}
