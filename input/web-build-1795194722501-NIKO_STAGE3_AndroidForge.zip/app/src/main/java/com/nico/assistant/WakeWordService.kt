package com.nico.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.app.NotificationCompat
import java.util.Locale

/**
 * Wake listener that is explicitly started by the user. It uses Android's installed
 * speech-recognition provider in short sessions; offline behavior depends on that provider.
 */
class WakeWordService : Service() {
    companion object {
        const val ACTION_START = "com.nico.assistant.WAKE_START"
        const val ACTION_STOP = "com.nico.assistant.WAKE_STOP"
        const val ACTION_WAKE = "com.nico.assistant.WAKE_DETECTED"
        private const val CHANNEL = "nico_wake"
        private const val NOTIFICATION_ID = 731
    }
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var running = false

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "استماع نيكو", NotificationManager.IMPORTANCE_LOW))
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            getSharedPreferences("nico", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
            stopListening(); stopSelf(); return START_NOT_STICKY
        }
        val stop = PendingIntent.getService(this, 732, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("نيكو مستعد")
            .setContentText("الاستماع لكلمة «نيكو» شغال. اضغطي لإيقافه من الإشعار.")
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stop)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(NOTIFICATION_ID, notification)
        if (!running) { running = true; listenAgain() }
        return START_NOT_STICKY
    }

    private fun listenAgain() {
        if (!running) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { handler.postDelayed({ listenAgain() }, 5000); return }
        try {
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    val normalized = Skills.norm(heard)
                    if (normalized.contains("نيكو") || normalized.contains("يا نيكو")) {
                        val command = heard.replace(Regex("(?i)(يا\\s*)?نيكو[،,.!؟]?"), "").trim()
                        val open = Intent(this@WakeWordService, MainActivity::class.java)
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            .putExtra("wake_command", command.ifBlank { "__WAKE_ONLY__" })
                        startActivity(open)
                    }
                    scheduleNext()
                }
                override fun onError(error: Int) { scheduleNext() }
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val req = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            recognizer?.startListening(req)
        } catch (_: Throwable) { scheduleNext() }
    }

    private fun scheduleNext() { handler.removeCallbacksAndMessages(null); if (running) handler.postDelayed({ listenAgain() }, 900) }
    private fun stopListening() {
        running = false; handler.removeCallbacksAndMessages(null)
        try { recognizer?.cancel(); recognizer?.destroy() } catch (_: Throwable) {}
        recognizer = null
    }
    override fun onDestroy() {
        stopListening()
        getSharedPreferences("nico", MODE_PRIVATE).edit().putBoolean("wake", false).apply()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
