plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nico.assistant"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.nico.assistant"
        minSdk = 24
        targetSdk = 34
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            // توقيع بمفتاح الـ debug علشان الـ APK يتثبت على أي موبايل
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    lint { abortOnError = false }
    androidResources { noCompress += listOf("zip", "task") }
    packaging { resources { excludes += "/META-INF/{AL2.0,LGPL2.1}" } }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    // تعرف على الصوت أوفلاين (Vosk)
    implementation("com.alphacephei:vosk-android:0.3.75")
    implementation("net.java.dev.jna:jna:5.18.1@aar")
    // ذكاء اصطناعي محلي (MediaPipe LLM Inference)
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
}
