package com.nico.assistant

import android.content.Context
import java.io.File
import java.io.InputStream
import java.util.Locale
import java.util.zip.ZipInputStream

/** إدارة حزم اللغات (موديلات Vosk) المخزنة جوه الجهاز - كلها أوفلاين. */
object LangPacks {
    private fun root(c: Context) = File(c.filesDir, "models").apply { mkdirs() }
    private fun clean(code: String) = code.lowercase().replace(Regex("[^a-z0-9_-]"), "")

    fun installed(c: Context): List<String> =
        (root(c).listFiles() ?: emptyArray()).filter { it.isDirectory && !it.name.endsWith(".tmp") && findModel(it, 3) != null }
            .map { it.name }.sorted()

    fun modelDir(c: Context, code: String): File? = findModel(File(root(c), clean(code)), 3)

    private fun findModel(d: File, depth: Int): File? {
        if (!d.isDirectory) return null
        if (File(d, "am").exists() && File(d, "conf").exists()) return d
        if (depth == 0) return null
        d.listFiles()?.forEach { f -> findModel(f, depth - 1)?.let { return it } }
        return null
    }

    fun active(c: Context): String =
        c.getSharedPreferences("nico", Context.MODE_PRIVATE).getString("lang", "ar") ?: "ar"

    fun setActive(c: Context, code: String) =
        c.getSharedPreferences("nico", Context.MODE_PRIVATE).edit().putString("lang", clean(code)).apply()

    fun locale(code: String): Locale = when (clean(code)) {
        "ar" -> Locale("ar", "EG")
        else -> Locale(clean(code).substringBefore("-"))
    }

    /** يفك ملف zip لموديل Vosk ويثبته تحت اسم اللغة. يرجع true لو نجح. */
    fun installZip(c: Context, code: String, input: InputStream, onProgress: (Long) -> Unit = {}): Boolean {
        val cc = clean(code)
        if (cc.isEmpty()) return false
        val tmp = File(root(c), "$cc.tmp")
        tmp.deleteRecursively(); tmp.mkdirs()
        var total = 0L
        try {
            val canon = tmp.canonicalPath
            ZipInputStream(input.buffered()).use { z ->
                var e = z.nextEntry
                while (e != null) {
                    val out = File(tmp, e.name)
                    if (!out.canonicalPath.startsWith(canon)) throw SecurityException("bad zip path")
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { o ->
                            val buf = ByteArray(65536)
                            while (true) {
                                val n = z.read(buf)
                                if (n < 0) break
                                o.write(buf, 0, n)
                                total += n
                            }
                        }
                        onProgress(total)
                    }
                    z.closeEntry()
                    e = z.nextEntry
                }
            }
        } catch (ex: Exception) {
            tmp.deleteRecursively(); return false
        }
        if (findModel(tmp, 3) == null) { tmp.deleteRecursively(); return false }
        val dst = File(root(c), cc)
        dst.deleteRecursively()
        return tmp.renameTo(dst)
    }

    /** لو الـ APK متبني ومعاه موديل عربي جوه assets/models/ar.zip، نثبته أول مرة. */
    fun installBundled(c: Context, onProgress: (Long) -> Unit = {}): Boolean {
        if (modelDir(c, "ar") != null) return false
        val has = try { c.assets.list("models")?.contains("ar.zip") == true } catch (e: Exception) { false }
        if (!has) return false
        return try { c.assets.open("models/ar.zip").use { installZip(c, "ar", it, onProgress) } } catch (e: Exception) { false }
    }
}
