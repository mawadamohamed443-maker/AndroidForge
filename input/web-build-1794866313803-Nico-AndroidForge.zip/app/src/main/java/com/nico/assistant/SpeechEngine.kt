package com.nico.assistant

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService

/** التعرف على الصوت أوفلاين بالكامل (Vosk). */
class SpeechEngine(private val ctx: Context) {
    private var model: Model? = null
    private var loadedCode: String? = null
    private var service: SpeechService? = null

    val ready: Boolean get() = model != null
    val isListening: Boolean get() = service != null

    /** تحميل الموديل (تقيل) - نادّيه من thread خلفي. يرجع رسالة خطأ أو null لو تمام. */
    @Synchronized
    fun load(code: String): String? {
        if (loadedCode == code && model != null) return null
        val dir = LangPacks.modelDir(ctx, code) ?: return "مفيش موديل صوت مثبت للغة ($code)."
        return try {
            model = Model(dir.absolutePath)
            loadedCode = code
            null
        } catch (e: Throwable) {
            model = null; loadedCode = null
            "فشل تحميل موديل الصوت: ${e.message}"
        }
    }

    fun start(onPartial: (String) -> Unit, onFinal: (String) -> Unit, fail: (String) -> Unit) {
        val m = model ?: run { fail("موديل الصوت لسه مش جاهز."); return }
        stop()
        try {
            var done = false
            val s = SpeechService(Recognizer(m, 16000.0f), 16000.0f)
            service = s
            s.startListening(object : RecognitionListener {
                override fun onPartialResult(h: String?) { jf(h, "partial")?.let(onPartial) }
                override fun onResult(h: String?) { finish(jf(h, "text")) }
                override fun onFinalResult(h: String?) { finish(jf(h, "text")) }
                override fun onError(e: Exception?) { stop(); fail(e?.message ?: "خطأ في المايك") }
                override fun onTimeout() { stop() }
                private fun finish(t: String?) {
                    if (done || t.isNullOrBlank()) return
                    done = true
                    stop()
                    onFinal(t)
                }
            })
        } catch (e: Throwable) {
            service = null
            fail("مقدرتش أشغل المايك: ${e.message}")
        }
    }

    fun stop() {
        val s = service ?: return
        service = null
        try { s.stop() } catch (_: Throwable) {}
        try { s.shutdown() } catch (_: Throwable) {}
    }

    private fun jf(json: String?, key: String): String? =
        try { JSONObject(json ?: return null).optString(key, "").ifBlank { null } } catch (e: Exception) { null }
}
