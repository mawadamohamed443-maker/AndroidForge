package com.nico.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var brain: NicoBrain
    private lateinit var speech: SpeechEngine
    private lateinit var llm: LlmEngine
    private var tts: TextToSpeech? = null
    private var sysSr: SpeechRecognizer? = null
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private var pendingCode = "ar"

    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)

    private val pickLang = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) installLang(uri, pendingCode) }
    private val pickLlm = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) installLlm(uri) }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        brain = NicoBrain(this); speech = SpeechEngine(this); llm = LlmEngine(this)
        log = findViewById(R.id.log); status = findViewById(R.id.status)
        scroll = findViewById(R.id.scroll); input = findViewById(R.id.input)

        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) applyTtsLang() }
        requestPermissions(perms, 1)

        findViewById<Button>(R.id.btnPerm).setOnClickListener { requestPermissions(perms, 1) }
        findViewById<Button>(R.id.btnAcc).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.btnLang).setOnClickListener { langMenu() }
        findViewById<Button>(R.id.btnLlm).setOnClickListener { llmMenu() }
        findViewById<Button>(R.id.btnMic).setOnClickListener { listen() }
        findViewById<Button>(R.id.btnSend).setOnClickListener { send() }
        input.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        add("نيكو: أهلا! اضغطي على المايك واتكلمي، أو اكتبي أمر.")
        bootModels()
    }

    // ---------- تجهيز الموديلات أول ما التطبيق يفتح ----------
    private fun bootModels() {
        status.text = "بجهّز الصوت..."
        thread {
            val first = LangPacks.installBundled(this) { mb -> runOnUiThread { status.text = "بفك الموديل العربي… ${mb / 1_000_000} MB" } }
            if (first) runOnUiThread { add("نيكو: ثبّت الموديل العربي أوفلاين.") }
            val code = LangPacks.active(this)
            val err = if (LangPacks.modelDir(this, code) == null) "NOMODEL" else speech.load(code)
            runOnUiThread {
                status.text = "نيكو"
                when {
                    err == null -> add("نيكو: الصوت العربي أوفلاين جاهز ✅")
                    err == "NOMODEL" -> add("نيكو: مفيش موديل صوت مثبت. من زر \"اللغات\" ضيفي ملف الموديل العربي مرة واحدة (التفاصيل في README).")
                    else -> add("نيكو: $err")
                }
                if (llm.installed) add("نيكو: موديل الذكاء موجود، اسأليني أي حاجة.")
            }
        }
    }

    private fun applyTtsLang() {
        val loc = LangPacks.locale(LangPacks.active(this))
        val r = tts?.setLanguage(loc) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (r < 0) tts?.setLanguage(Locale(loc.language))
    }

    // ---------- معالجة الأوامر ----------
    private fun send() { val t = input.text.toString().trim(); if (t.isNotEmpty()) { input.setText(""); process(t) } }

    private fun process(t: String) {
        add("أنتِ: $t")
        val r = try { brain.handle(t) } catch (e: Exception) { "حصل خطأ وأنا بنفذ الأمر: ${e.javaClass.simpleName}" }
        if (r != null) { if (r.isNotEmpty()) { add("نيكو: $r"); say(r) }; return }
        if (!llm.installed) {
            add("نيكو: معرفتش قصدك. ولو عايزاني أجاوب على أي سؤال أوفلاين، ثبتي موديل الذكاء من زر \"الذكاء\".")
            return
        }
        status.text = "بفكر..."
        thread {
            val a = llm.ask(t)
            runOnUiThread { if (!isFinishing) { status.text = "نيكو"; add("نيكو: $a"); say(a) } }
        }
    }

    private fun say(t: String) { tts?.speak(t.take(1500), TextToSpeech.QUEUE_FLUSH, null, "nico") }

    private fun add(t: String) { log.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    // ---------- الاستماع ----------
    private fun listen() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            add("نيكو: اسمحي بإذن المايك الأول وبعدين اضغطي على المايك تاني.")
            return
        }
        if (speech.isListening) { speech.stop(); status.text = "نيكو"; return }
        tts?.stop()
        if (speech.ready) {
            status.text = "بسمعك..."
            speech.start(
                onPartial = { status.text = it },
                onFinal = { status.text = "نيكو"; process(it) },
                fail = { status.text = "نيكو"; add("نيكو: $it") }
            )
        } else {
            add("نيكو: موديل الصوت الأوفلاين لسه مش متثبت، هستخدم تعرف الصوت بتاع الجهاز.")
            listenSystem()
        }
    }

    // احتياطي: تعرف الصوت بتاع أندرويد لو مفيش موديل Vosk
    private fun listenSystem(offline: Boolean = true) {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { add("نيكو: الاستماع مش متاح على الجهاز ده."); return }
        sysSr?.destroy()
        sysSr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "بسمعك..." }
                override fun onResults(r: Bundle?) {
                    status.text = "نيكو"
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
                }
                override fun onError(e: Int) {
                    status.text = "نيكو"
                    if (offline && (e == 12 || e == 13 || e == 5)) { listenSystem(false); return }
                    add("نيكو: معرفتش أسمعك (كود $e)، جربي تاني.")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline))
        }
    }

    // ---------- اللغات ----------
    private fun langMenu() {
        val langs = LangPacks.installed(this)
        val cur = LangPacks.active(this)
        val items = ArrayList<String>()
        langs.forEach { items.add((if (it == cur) "✓ " else "") + it) }
        items.add("➕ إضافة لغة (ملف موديل zip)")
        items.add("🔊 تنزيل صوت النطق للغة")
        AlertDialog.Builder(this).setTitle("اللغات").setItems(items.toTypedArray()) { _, i ->
            when {
                i < langs.size -> switchLang(langs[i])
                i == langs.size -> askLangCode()
                else -> ttsData()
            }
        }.show()
    }

    private fun askLangCode() {
        val e = EditText(this).apply { hint = "كود اللغة: ar أو en-us أو fr"; setText("ar") }
        AlertDialog.Builder(this).setTitle("كود اللغة").setView(e)
            .setPositiveButton("اختيار الملف") { _, _ -> pendingCode = e.text.toString().trim().ifEmpty { "ar" }; pickLang.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
            .setNegativeButton("إلغاء", null).show()
    }

    private fun switchLang(code: String) {
        LangPacks.setActive(this, code); applyTtsLang()
        status.text = "بحمّل $code..."
        thread {
            val err = speech.load(code)
            runOnUiThread { status.text = "نيكو"; add(if (err == null) "نيكو: اللغة دلوقتي: $code ✅" else "نيكو: $err") }
        }
    }

    private fun installLang(uri: Uri, code: String) {
        status.text = "بثبّت اللغة..."
        thread {
            val ok = try {
                contentResolver.openInputStream(uri)?.use { s ->
                    LangPacks.installZip(this, code, s) { n -> runOnUiThread { status.text = "بفك… ${n / 1_000_000} MB" } }
                } ?: false
            } catch (e: Exception) { false }
            runOnUiThread {
                status.text = "نيكو"
                if (ok) { add("نيكو: اتثبتت اللغة ($code)."); switchLang(code) }
                else add("نيكو: الملف ده مش موديل Vosk صالح (لازم يكون zip جواه فولدرات am و conf و graph).")
            }
        }
    }

    private fun ttsData() {
        try { startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA)) }
        catch (e: Exception) {
            try { startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
            catch (e2: Exception) { add("نيكو: افتحي إعدادات الجهاز > اللغة > تحويل النص إلى كلام ونزّلي صوت اللغة.") }
        }
    }

    // ---------- موديل الذكاء ----------
    private fun llmMenu() {
        val items = arrayOf(
            if (llm.installed) "🔁 استبدال موديل الذكاء (ملف .task)" else "➕ تثبيت موديل الذكاء (ملف .task)",
            "🗑 حذف موديل الذكاء"
        )
        AlertDialog.Builder(this).setTitle("الذكاء الأوفلاين").setItems(items) { _, i ->
            if (i == 0) pickLlm.launch(arrayOf("*/*"))
            else { llm.release(); llm.modelFile.delete(); add("نيكو: اتمسح موديل الذكاء.") }
        }.show()
    }

    private fun installLlm(uri: Uri) {
        var name = "model.task"
        try { contentResolver.query(uri, null, null, null, null)?.use { if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = it.getString(i) ?: name } } } catch (_: Exception) {}
        if (!name.lowercase().endsWith(".task")) { add("نيكو: لازم الملف يكون بامتداد .task (موديل MediaPipe)."); return }
        status.text = "بنسخ موديل الذكاء..."
        thread {
            llm.release()
            val dst = llm.modelFile.apply { parentFile?.mkdirs() }
            val tmp = File(dst.parentFile, "model.tmp")
            val ok = try {
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o ->
                        val buf = ByteArray(1 shl 20); var total = 0L
                        while (true) { val n = i.read(buf); if (n < 0) break; o.write(buf, 0, n); total += n; if (total % (50L shl 20) < (1L shl 20)) runOnUiThread { status.text = "بنسخ… ${total / 1_000_000} MB" } }
                    }
                    dst.delete(); tmp.renameTo(dst)
                } ?: false
            } catch (e: Exception) { tmp.delete(); false }
            if (ok) llm.setTemplateFrom(name)
            val err = if (ok) llm.load() else "النسخ فشل (مساحة التخزين كفاية؟)."
            runOnUiThread { status.text = "نيكو"; add(if (err == null) "نيكو: موديل الذكاء جاهز ✅ اسأليني أي حاجة." else "نيكو: $err") }
        }
    }

    override fun onDestroy() { speech.stop(); sysSr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
