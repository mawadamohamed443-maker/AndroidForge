package com.nico.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaRecorder
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.SeekBar
import android.view.WindowManager
import android.graphics.Color
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.speech.tts.UtteranceProgressListener
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var brain: NicoBrain
    private lateinit var llm: LlmEngine
    private lateinit var store: Store
    private lateinit var vosk: VoskEngine
    private var pendingLang: Lang? = null
    private val pickVosk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val l = pendingLang
        if (uri != null && l != null) importLangZip(l, uri)
    }
    private val curLang get() = Langs.byCode(vosk.lang)
    private lateinit var people: People
    private val agent by lazy { Agent(llm) }
    private val prefs by lazy { getSharedPreferences("nico", MODE_PRIVATE) }
    private var pendingPerson: Person? = null
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> val p = pendingPerson; if (uri != null && p != null) savePhoto(p, uri) }
    private lateinit var orb: WaterOrbView
    private val h = android.os.Handler(android.os.Looper.getMainLooper())
    private val pickLlm = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) installLlm(uri) }
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    private lateinit var chatList: LinearLayout
    private lateinit var caption: TextView
    private lateinit var historyPanel: View
    private lateinit var scrim: View
    private lateinit var historyList: ListView
    private var historyOpen = false
    private var transcriptOpen = false
    private var speaker: Person? = null
    private val pickVoiceFile = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> val p = pendingPerson; if (uri != null && p != null) importVoiceFile(p, uri) }
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        brain = NicoBrain(this); llm = LlmEngine(this); vosk = VoskEngine(this)
        chatList = findViewById(R.id.chatList); status = findViewById(R.id.status); caption = findViewById(R.id.caption)
        scroll = findViewById(R.id.scroll); input = findViewById(R.id.input)
        historyPanel = findViewById(R.id.historyPanel); scrim = findViewById(R.id.scrim); historyList = findViewById(R.id.historyList)
        store = Store(this); people = People(this); orb = findViewById(R.id.orb)
        applyOrbPrefs()
        orb.setOnClickListener { listen() }
        val panel = findViewById<View>(R.id.transcriptPanel)
        val plp = panel.layoutParams; plp.height = (resources.displayMetrics.heightPixels * 0.55f).toInt(); panel.layoutParams = plp
        caption.setOnClickListener { toggleTranscript() }
        caption.visibility = if (prefs.getBoolean("caption", true)) View.VISIBLE else View.GONE
        refreshChat()
        llm.seed(store.pairs()); llm.memory = store.memoryText()

        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar", "EG")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (r < 0) tts?.setLanguage(Locale("ar"))
                tts?.let { Voices.apply(it, curLang, prefs); Voices.prosody(it, Emotion.NEUTRAL, prefs) }
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.SPEAKING } }
                    override fun onDone(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.IDLE } }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.IDLE } }
                })
            }
        }

        findViewById<View>(R.id.btnGear).setOnClickListener { mainMenu() }
        findViewById<View>(R.id.btnMenu).setOnClickListener { toggleHistory() }
        findViewById<View>(R.id.btnChat).setOnClickListener { toggleTranscript() }
        findViewById<View>(R.id.btnMic).setOnClickListener { listen() }
        findViewById<View>(R.id.btnSend).setOnClickListener { send() }
        findViewById<View>(R.id.btnNewChat).setOnClickListener { newChat() }
        scrim.setOnClickListener { toggleHistory(false) }
        historyList.setOnItemClickListener { _, _, i, _ -> val c = store.sorted().getOrNull(i); if (c != null) openChat(c) }
        historyList.setOnItemLongClickListener { _, _, i, _ -> val c = store.sorted().getOrNull(i); if (c != null) chatOptions(c); true }
        input.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        if (prefs.getBoolean("warm", true)) warmUp()
        playIntro()
        if (intent?.getBooleanExtra("assist", false) == true) h.postDelayed({ listen() }, 2600)
    }

    private fun pf(r: String) = if (prefs.getBoolean("persona", true)) Persona.flavor(r) else r

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- المحادثة (فقاعات) ----------
    private fun addBubble(line: String) {
        val mine = line.startsWith("أنتِ: ")
        val tv = TextView(this)
        tv.text = line.removePrefix("أنتِ: ").removePrefix("نيكو: ")
        tv.textSize = 15f; tv.setTextColor(Color.WHITE)
        tv.setPadding(dp(14), dp(10), dp(14), dp(10))
        tv.setBackgroundResource(if (mine) R.drawable.bg_bubble_user else R.drawable.bg_bubble_nico)
        tv.maxWidth = (resources.displayMetrics.widthPixels * 0.78f).toInt()
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.gravity = if (mine) Gravity.START else Gravity.END
        lp.setMargins(0, dp(4), 0, dp(4))
        chatList.addView(tv, lp)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun refreshChat() {
        chatList.removeAllViews()
        store.lines.takeLast(80).forEach { addBubble(it) }
        val last = store.lines.lastOrNull()
        caption.text = last?.removePrefix("أنتِ: ")?.removePrefix("نيكو: ") ?: "اضغطي على الكرة وتكلمي، أو اكتبي أمر"
    }

    private fun toggleTranscript(show: Boolean = !transcriptOpen) {
        transcriptOpen = show
        val panel = findViewById<View>(R.id.transcriptPanel)
        if (show) {
            panel.alpha = 0f; panel.visibility = View.VISIBLE
            panel.animate().alpha(1f).setDuration(200).start()
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        } else {
            panel.animate().alpha(0f).setDuration(160).withEndAction { panel.visibility = View.GONE }.start()
        }
    }

    // ---------- سجل المحادثات (زي ChatGPT) ----------
    private fun toggleHistory(show: Boolean = !historyOpen) {
        historyOpen = show
        if (show) {
            refreshHistory()
            scrim.alpha = 0f; scrim.visibility = View.VISIBLE; historyPanel.visibility = View.VISIBLE
            scrim.animate().alpha(1f).setDuration(220).start()
            historyPanel.post {
                historyPanel.translationX = historyPanel.width.toFloat()
                historyPanel.animate().translationX(0f).setDuration(240).start()
            }
        } else {
            scrim.animate().alpha(0f).setDuration(200).start()
            historyPanel.animate().translationX(historyPanel.width.toFloat()).setDuration(200).withEndAction {
                historyPanel.visibility = View.GONE; scrim.visibility = View.GONE
            }.start()
        }
    }

    private fun refreshHistory() {
        val items = store.sorted()
        historyList.adapter = object : ArrayAdapter<Chat>(this, android.R.layout.simple_list_item_1, items) {
            override fun getView(pos: Int, cv: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(pos, cv, parent) as TextView
                val c = getItem(pos)!!
                val cur = c.id == store.current.id
                v.text = (if (cur) "● " else "") + c.title
                v.setTextColor(if (cur) Color.parseColor("#AAB4FF") else Color.WHITE)
                v.textSize = 15f; v.maxLines = 1; v.ellipsize = android.text.TextUtils.TruncateAt.END
                return v
            }
        }
    }

    private fun newChat() {
        store.newChat(); llm.clearHistory(); llm.seed(emptyList()); refreshChat()
        caption.text = "محادثة جديدة. اتكلمي معايا."
        toggleHistory(false)
    }

    private fun openChat(c: Chat) {
        store.switchTo(c.id); llm.clearHistory(); llm.seed(store.pairs()); refreshChat(); toggleHistory(false)
    }

    private fun chatOptions(c: Chat) {
        AlertDialog.Builder(this).setTitle(c.title).setItems(arrayOf("✏ إعادة تسمية", "🗑 حذف المحادثة")) { _, i ->
            if (i == 0) askText("اسم المحادثة", c.title) { v -> store.rename(c.id, v); refreshHistory() }
            else confirm("حذف المحادثة دي؟") {
                store.deleteChat(c.id); llm.clearHistory(); llm.seed(store.pairs()); refreshChat(); refreshHistory()
            }
        }.show()
    }

    // ---------- بداية متطورة ----------
    private fun playIntro() {
        val intro = findViewById<View>(R.id.intro)
        orb.alpha = 0f; orb.scaleX = 0.6f; orb.scaleY = 0.6f
        findViewById<View>(R.id.introTitle).animate().alpha(1f).setDuration(800).start()
        findViewById<View>(R.id.introSub).animate().alpha(1f).setStartDelay(400).setDuration(800).start()
        h.postDelayed({
            orb.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1200).start()
            intro.animate().alpha(0f).setDuration(900).withEndAction { intro.visibility = View.GONE }.start()
        }, 1500)
        if (!prefs.getBoolean("welcomed", false)) h.postDelayed({ showWelcome() }, 2800)
    }

    private fun showWelcome() {
        if (isFinishing) return
        prefs.edit().putBoolean("welcomed", true).apply()
        AlertDialog.Builder(this).setTitle("أهلاً بيك في نيكو 👋")
            .setMessage("خطوات سريعة للبداية:\n\n١) اسمحي بالأذونات.\n٢) من ⚙ فعّلي \"التحكم الكامل\" عشان نيكو ينفذ الأوامر.\n٣) من ⚙ ثبّتي موديل الذكاء عشان يجاوب على أي سؤال.\n٤) اضغطي على الكرة وتكلمي.\n\nكل الخيارات في الترس ⚙، وسجل المحادثات في ☰.")
            .setPositiveButton("ابدأ") { _, _ -> requestPermissions(perms, 1) }
            .setNegativeButton("بعدين", null).show()
    }

    // ---------- الكرة: حجم ومكان ----------
    private fun applyOrbPrefs() {
        val size = 0.5f + prefs.getInt("orb_size", 50) / 100f
        val x = (prefs.getInt("orb_x", 50) - 50) / 100f * 1.2f
        val y = (prefs.getInt("orb_y", 50) - 50) / 100f * 1.2f
        orb.adjust(size, x, y)
    }

    private fun orbMenu() {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL; box.setPadding(dp(22), dp(8), dp(22), 0)
        fun row(label: String, key: String) {
            val tv = TextView(this); tv.text = label; tv.setTextColor(Color.WHITE); tv.textSize = 14f; tv.setPadding(0, dp(14), 0, 0)
            val sb = SeekBar(this); sb.max = 100; sb.progress = prefs.getInt(key, 50).coerceIn(0, 100)
            sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { prefs.edit().putInt(key, p).apply(); applyOrbPrefs() }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            box.addView(tv); box.addView(sb)
        }
        row("حجم الكرة", "orb_size"); row("المكان: يمين ↔ شمال", "orb_x"); row("المكان: فوق ↕ تحت", "orb_y")
        AlertDialog.Builder(this).setTitle("الكرة 🎨").setView(box)
            .setPositiveButton("تمام", null)
            .setNeutralButton("إعادة الضبط") { _, _ -> prefs.edit().remove("orb_size").remove("orb_x").remove("orb_y").apply(); applyOrbPrefs() }
            .show()
    }

    private fun mainMenu() {
        val items = arrayOf("🧠 مكتبة الذكاء (النماذج)", "🎙 مكتبة الصوت (Vosk واللغات)", "🔐 الأذونات", "♿ التحكم الكامل (Accessibility)",
            "🏠 اجعل نيكو المساعد الافتراضي", "👥 الأشخاص", "💭 الذاكرة", "💬 المحادثات (السجل)", "🎨 الكرة: الحجم والمكان",
            "🔊 الصوت والنطق", "⚙ إعدادات المساعد", "🧹 مسح المحادثة")
        AlertDialog.Builder(this).setTitle("نيكو ⚙").setItems(items) { _, i ->
            when (i) {
                0 -> llmLibMenu()
                1 -> voiceLibMenu()
                2 -> { requestPermissions(perms, 1); add("نيكو: اسمحي بالأذونات اللي هتظهر.") }
                3 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                4 -> assistantSettings()
                5 -> peopleMenu()
                6 -> memoryMenu()
                7 -> toggleHistory(true)
                8 -> orbMenu()
                9 -> voiceMenu()
                10 -> settingsMenu()
                else -> confirm("مسح المحادثة كلها؟") { clearChat() }
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (historyOpen) toggleHistory(false) else if (transcriptOpen) toggleTranscript(false) else super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        val day = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
        if (prefs.getString("bday_day", "") != day) {
            val g = Birthdays.greeting(people.list)
            if (g != null) { prefs.edit().putString("bday_day", day).apply(); reply(g) }
        }
    }

    private fun send() { val t = input.text.toString().trim(); if (t.isNotEmpty()) { input.setText(""); speaker = null; process(t) } }

    private fun process(t: String) {
        add("أنتِ: $t")
        if (prefs.getBoolean("persona", true)) Persona.onUser(t)?.let { orb.feel(Persona.mood, 8000); reply(it); return }
        Skills.handle(t, store, this)?.let { llm.memory = store.memoryText(); reply(it); return }
        Birthdays.reply(t, people)?.let { reply(it); return }
        val steps = Skills.split(t)
        if (steps.size > 1) { add("نيكو: فهمت ${steps.size} خطوات، هنفذهم واحدة واحدة."); runPlan(steps, 0); return }
        runSingle(t)
    }

    private fun tryBrain(t0: String): String? {
        val t = Mix.normalize(t0)
        Mix.whatsapp(this, t, speaker, people)?.let { return it }
        Mix.tryOpen(this, t)?.let { return it }
        return try { brain.handle(t) } catch (e: Exception) { "حصل خطأ وأنا بنفذ الأمر: ${e.javaClass.simpleName}" }
    }

    private fun runSingle(t: String) {
        val r = tryBrain(t)
        if (r != null) {
            if (r.isNotEmpty()) {
                val failed = r.startsWith("ملقتش") || r.startsWith("مقدرتش") || r.startsWith("معرفتش") || r.startsWith("حصل خطأ")
                if (prefs.getBoolean("ack", true) && Skills.isCommand(t) && !failed) { add("نيكو: $r"); say(pf("عملته")) } else reply(pf(r))
            }
            return
        }
        if (Skills.isCommand(t) && agentReady()) { runAgent(t) {}; return }
        if (!llm.installed) {
            reply("معرفتش قصدك. علشان أجاوب على أي سؤال أوفلاين، ثبتي موديل الذكاء من زر \"الذكاء\".")
            return
        }
        status.text = "بفكر..."; orb.state = WaterOrbView.State.THINKING
        llm.memory = store.memoryText(); llm.persona = if (prefs.getBoolean("persona", true)) Persona.hint() else ""
        thread {
            val a = llm.ask(t)
            runOnUiThread { if (!isFinishing) { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; reply(a) } }
        }
    }

    private fun runPlan(steps: List<String>, i: Int) {
        if (i >= steps.size) { reply("خلصت كل الخطوات."); return }
        val s = steps[i]
        add("نيكو: [${i + 1}/${steps.size}] $s")
        val r = tryBrain(s)
        if (r != null) { if (r.isNotEmpty()) add("نيكو: $r") } else add("نيكو: معرفتش أنفذ الخطوة دي.")
        h.postDelayed({ runPlan(steps, i + 1) }, 2500)
    }

    private fun say(t: String) {
        if (!prefs.getBoolean("speak", true)) return
        val engine = tts ?: return
        val e = Persona.emotionFor(t); orb.feel(e); Voices.prosody(engine, e, prefs)
        orb.state = WaterOrbView.State.SPEAKING
        engine.speak(t.take(1500), TextToSpeech.QUEUE_FLUSH, null, "nico")
    }
    private fun reply(t: String) { add("نيكو: $t"); say(t) }
    private fun add(t: String) {
        store.addLine(t); addBubble(t)
        caption.text = t.removePrefix("أنتِ: ").removePrefix("نيكو: ")
        caption.setTextColor(Color.parseColor(if (t.startsWith("أنتِ: ")) "#8A93C9" else "#E9EBFF"))
        caption.alpha = 0f; caption.animate().alpha(1f).setDuration(250).start()
    }

    private fun listen(offline: Boolean = true) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            add("نيكو: اسمحي بإذن المايك الأول وبعدين اضغطي على المايك تاني.")
            return
        }
        if (vosk.listening) { vosk.stop(); orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"; return }
        if (vosk.available()) { listenVosk(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { add("نيكو: الاستماع مش متاح. أضيفي موديل صوت من ⚙ ← مكتبة الصوت."); return }
        tts?.stop(); sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "بسمعك..."; orb.state = WaterOrbView.State.LISTENING }
                override fun onResults(r: Bundle?) {
                    status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
                }
                override fun onError(e: Int) {
                    status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                    if (e == 12 || e == 13) add("نيكو: اللغة العربية مش منزلة أوفلاين. اضغطي زر \"العربي أوفلاين\" ونزّليها مرة واحدة.")
                    else add("نيكو: معرفتش أسمعك (كود $e)، جربي تاني.")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) { orb.pulse((v / 10f).coerceIn(0f, 1f)) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline))
        }
    }

    private fun voiceMenu() {
        val items = arrayOf("🗣 اختيار صوت النطق (طبيعي أكتر)", "🔊 تحميل بيانات صوت النطق", "⚙ إعدادات النطق في النظام", "🎤 تحميل العربي لجوجل (للميكروفون أوفلاين)")
        AlertDialog.Builder(this).setTitle("الصوت والنطق").setItems(items) { _, i ->
            when (i) {
                0 -> voicePickMenu()
                1 -> open("android.speech.tts.engine.INSTALL_TTS_DATA")
                2 -> open("com.android.settings.TTS_SETTINGS")
                else -> { add("نيكو: في الشاشة اللي هتفتح اختاري Google ثم اللغات وحمّلي العربية للاستخدام بدون نت."); open("android.settings.VOICE_INPUT_SETTINGS") }
            }
        }.show()
    }

    private fun open(action: String) {
        try { startActivity(Intent(action)) } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    private fun askText(title: String, def: String, onOk: (String) -> Unit) {
        val e = EditText(this); e.setText(def)
        AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("حفظ") { _, _ -> onOk(e.text.toString().trim()) }.setNegativeButton("إلغاء", null).show()
    }

    private fun voicePickMenu() {
        val l = curLang; val vs = tts?.let { Voices.forLang(it, l) } ?: emptyList()
        if (vs.isEmpty()) { add("نيكو: مفيش أصوات للغة ${l.label}. نزّلي بيانات النطق من اللغات."); return }
        val names = vs.map { "${it.name}  ${if (it.isNetworkConnectionRequired) "(نت)" else "(أوفلاين)"}  جودة ${it.quality}" }
        AlertDialog.Builder(this).setTitle("صوت النطق (جودة أعلى = أطبيعي أكتر)").setItems(names.toTypedArray()) { _, i ->
            prefs.edit().putString("voice_${l.code}", vs[i].name).apply(); applyTts(); say("ده صوتي الجديد، عجبك؟")
        }.show()
    }

    private fun memoryMenu() {
        if (store.memories.isEmpty()) { AlertDialog.Builder(this).setTitle("الذاكرة 🧠").setMessage("فاضية. قولي لنيكو: \"افتكر إن ...\" وهيحفظها. وتقدري تمسحيها من هنا أو بـ \"انسى ...\".").setPositiveButton("تمام", null).show(); return }
        AlertDialog.Builder(this).setTitle("اللي نيكو فاكره عنك (اضغطي على واحدة لمسحها)")
            .setItems(store.memories.toTypedArray()) { _, i -> store.removeMemory(i); llm.memory = store.memoryText(); memoryMenu() }
            .setNeutralButton("مسح الكل") { _, _ -> confirm("مسح كل الذاكرة؟") { store.clearMemory(); llm.memory = "" } }
            .setPositiveButton("إغلاق", null).show()
    }

    private fun savePhoto(p: Person, uri: Uri) {
        thread {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return@thread
                val sq = Bitmap.createScaledBitmap(bmp, 256, 256, true)
                val f = File(filesDir, "people/${p.id}.jpg"); f.parentFile?.mkdirs()
                f.outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                p.photo = f.absolutePath; people.save()
                runOnUiThread { add("نيكو: اتحفظت صورة ${p.name}."); peopleMenu() }
            } catch (e: Exception) { runOnUiThread { add("نيكو: معرفتش أحفظ الصورة.") } }
        }
    }

    private fun peopleMenu() {
        val list = people.list
        val lv = ListView(this)
        val ad = object : ArrayAdapter<Person>(this, 0, list) {
            override fun getView(pos: Int, cv: View?, parent: android.view.ViewGroup): View {
                val p = getItem(pos)!!
                val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(24, 16, 24, 16); gravity = Gravity.CENTER_VERTICAL }
                val img = ImageView(context).apply { layoutParams = LinearLayout.LayoutParams(120, 120) }
                val bm = if (p.photo.isNotBlank()) BitmapFactory.decodeFile(p.photo) else null
                if (bm != null) img.setImageBitmap(bm) else img.setImageResource(android.R.drawable.ic_menu_myplaces)
                val tv = TextView(context).apply {
                    text = p.name + (if (p.owner) "  ⭐ المالك" else "") + "\n" + (if (p.relation.isNotBlank()) p.relation + " " else "") + (if (p.voice != null) "🎙 بصمة " else "") + (if (p.phone.isNotBlank()) "📱 رقم " else "") + (if (p.birthday.isNotBlank()) "🎂 ${p.birthday}" else "")
                    textSize = 17f; setPadding(24, 0, 0, 0)
                }
                row.addView(img); row.addView(tv); return row
            }
        }
        lv.adapter = ad
        val dlg = AlertDialog.Builder(this).setTitle("الأشخاص 👥 (${list.size})").setView(lv)
            .setPositiveButton("➕ شخص جديد") { _, _ -> askText("اسم الشخص", "") { n -> if (n.isNotBlank()) personMenu(people.add(n)) } }
            .setNegativeButton("إغلاق", null).create()
        lv.setOnItemClickListener { _, _, i, _ -> dlg.dismiss(); personMenu(list[i]) }
        dlg.show()
    }

    private fun personMenu(p: Person) {
        val items = arrayOf("🖼 اختيار صورة", "📱 رقم الواتساب/الموبايل", "✏ تغيير الاسم", "⭐ ${if (p.owner) "إلغاء" else "تعيين"} كمالك (صاحب الموبايل)", "🎂 تاريخ الميلاد (يوم/شهر أو يوم/شهر/سنة)", "👪 صلة القرابة/العلاقة: ${p.relation.ifBlank { "غير محددة" }}", "🎙 تسجيل بصمة الصوت (3 جمل)", "📁 بصمة من ملف صوتي (تسجيل لشخص)", "🗑 حذف الشخص")
        AlertDialog.Builder(this).setTitle(p.name).setItems(items) { _, i ->
            when (i) {
                0 -> { pendingPerson = p; pickPhoto.launch(arrayOf("image/*")) }
                1 -> askText("رقم ${p.name} (مثال 01012345678)", p.phone) { v -> p.phone = v; people.save(); add("نيكو: اتحفظ الرقم. دلوقتي قولي: نيكو افتح شات ${p.name} واتساب."); peopleMenu() }
                2 -> askText("الاسم", p.name) { v -> if (v.isNotBlank()) { p.name = v; people.save() }; peopleMenu() }
                3 -> { val was = p.owner; people.list.forEach { it.owner = false }; p.owner = !was; people.save(); peopleMenu() }
                4 -> askText("تاريخ ميلاد ${p.name} (مثال 25/3 أو 25/3/1999)", p.birthday) { v ->
                    if (v.isBlank() || Birthdays.parse(v) != null) { p.birthday = v; people.save(); add("نيكو: اتحفظ تاريخ الميلاد.") }
                    else add("نيكو: الصيغة غلط. اكتبي زي 25/3 أو 25/3/1999.")
                    peopleMenu()
                }
                5 -> askText("صلة القرابة أو العلاقة", p.relation) { v -> p.relation = v; people.save(); personMenu(p) }
                6 -> recordVoiceprint(p)
                7 -> { pendingPerson = p; pickVoiceFile.launch(arrayOf("audio/*")) }
                else -> confirm("حذف ${p.name}؟") { people.remove(p); peopleMenu() }
            }
        }.setNegativeButton("رجوع") { _, _ -> peopleMenu() }.show()
    }

    private fun <T> onMain(f: () -> T): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return f()
        var r: T? = null; val l = CountDownLatch(1)
        runOnUiThread { try { r = f() } catch (_: Throwable) {}; l.countDown() }
        l.await(6, TimeUnit.SECONDS); return r
    }

    private fun execAction(a: String, v: String): String = onMain {
        val acc = NicoAccessibilityService.inst
        when (a) {
            "open" -> brain.handle("افتح $v")?.ifBlank { null } ?: "فتحت $v"
            "click" -> if (acc?.clickText(v) == true) "ضغطت على \"$v\"" else "ملقيتش \"$v\" على الشاشة"
            "type" -> if (acc?.typeText(v) == true) "كتبت \"$v\"" else "ملقيتش خانة كتابة"
            "scroll" -> if (acc?.scroll(v != "up") == true) "سكرولت" else "معرفتش أسكرول"
            "back" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_BACK); "رجعت" }
            "home" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_HOME); "روحت للرئيسية" }
            else -> "أمر غير معروف: $a"
        }
    } ?: "التنفيذ اتأخر"

    private fun runAgent(goal: String, done: () -> Unit) {
        status.text = "بنفذ..."; orb.state = WaterOrbView.State.THINKING
        llm.memory = store.memoryText()
        thread {
            val res = agent.run(goal, prefs.getBoolean("sens", false),
                screen = { onMain { NicoAccessibilityService.inst?.readScreen(1200) } ?: "" },
                pkg = { onMain { NicoAccessibilityService.inst?.currentPackage() } ?: "" },
                exec = { a, v -> execAction(a, v) },
                log = { s -> runOnUiThread { add("نيكو: $s") } })
            runOnUiThread { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; reply(res); done() }
        }
    }

    private fun agentReady() = prefs.getBoolean("agent", true) && NicoAccessibilityService.inst != null && llm.installed

    private fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("أيوه") { _, _ -> ok() }.setNegativeButton("لا", null).show()
    }

    private fun clearChat() {
        store.clearHistory(); llm.clearHistory(); chatList.removeAllViews(); caption.text = ""
        add("نيكو: مسحت المحادثة.")
    }

    private fun applyTts() { tts?.let { Voices.apply(it, curLang, prefs); Voices.prosody(it, Emotion.NEUTRAL, prefs) } }

    private fun settingsMenu() {
        fun on(k: String, d: Boolean) = prefs.getBoolean(k, d)
        fun onoff(k: String, d: Boolean) = if (on(k, d)) "شغّال" else "واقف"
        val items = arrayOf(
            "🔊 النطق التلقائي: ${onoff("speak", true)}",
            "⏩ سرعة النطق: ${arrayOf("بطيء", "عادي", "سريع")[prefs.getInt("rate", 1).coerceIn(0, 2)]}",
            "🗣 اختيار صوت النطق (طبيعي أكتر)",
            "🎭 مشاعر نيكو (يزعل ويتكسف ويغضب): ${onoff("persona", true)}",
            "✅ يقول \"عملته\" بعد تنفيذ الأمر: ${onoff("ack", true)}",
            "📝 الكلام المكتوب تحت الكرة: ${onoff("caption", true)}",
            "🤖 الوكيل الذكي (ينفذ أي أمر بالشاشة): ${onoff("agent", true)}",
            "⚠ خطوات حساسة للوكيل (إرسال/حذف/دفع): ${if (on("sens", false)) "مسموحة" else "ممنوعة"}",
            "📏 طول الرد: ${arrayOf("مختصر", "متوسط", "مفصّل")[prefs.getInt("style", 0).coerceIn(0, 2)]}",
            "🔒 ينفذ لصوتي أنا بس (بصمة المالك): ${onoff("ownerOnly", false)}",
            "⚡ تحميل الموديلات أول ما يفتح التطبيق (ردود أسرع): ${onoff("warm", true)}"
        )
        AlertDialog.Builder(this).setTitle("إعدادات المساعد ⚙").setItems(items) { _, i ->
            var reopen = true
            when (i) {
                0 -> prefs.edit().putBoolean("speak", !on("speak", true)).apply()
                1 -> { prefs.edit().putInt("rate", (prefs.getInt("rate", 1) + 1) % 3).apply(); applyTts() }
                2 -> { voicePickMenu(); reopen = false }
                3 -> prefs.edit().putBoolean("persona", !on("persona", true)).apply()
                4 -> prefs.edit().putBoolean("ack", !on("ack", true)).apply()
                5 -> { val v = !on("caption", true); prefs.edit().putBoolean("caption", v).apply(); caption.visibility = if (v) View.VISIBLE else View.GONE }
                6 -> prefs.edit().putBoolean("agent", !on("agent", true)).apply()
                7 -> prefs.edit().putBoolean("sens", !on("sens", false)).apply()
                8 -> { val st = (prefs.getInt("style", 0) + 1) % 3; prefs.edit().putInt("style", st).apply(); llm.style = st }
                9 -> {
                    if (!on("ownerOnly", false) && people.owner()?.voice == null) add("نيكو: سجّلي بصمة صوتك الأول: الأشخاص ← اختاري نفسك ← تعيين كمالك ← تسجيل بصمة الصوت.")
                    else prefs.edit().putBoolean("ownerOnly", !on("ownerOnly", false)).apply()
                }
                10 -> prefs.edit().putBoolean("warm", !on("warm", true)).apply()
            }
            if (reopen) settingsMenu()
        }.setPositiveButton("إغلاق", null).show()
    }

    // ---------- المساعد الافتراضي ----------
    private fun assistantSettings() {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = getSystemService(android.app.role.RoleManager::class.java)
                if (rm != null && rm.isRoleAvailable("android.app.role.ASSISTANT")) {
                    if (rm.isRoleHeld("android.app.role.ASSISTANT")) { add("نيكو: أنا فعلاً المساعد الرقمي الافتراضي."); return }
                    startActivityForResult(rm.createRequestRoleIntent("android.app.role.ASSISTANT"), 77)
                    return
                }
            } catch (_: Throwable) {}
        }
        add("نيكو: في الشاشة اللي هتفتح اختاري \"تطبيق المساعد الرقمي\" ثم نيكو.")
        try {
            startActivity(Intent("android.settings.VOICE_INPUT_SETTINGS"))
        } catch (_: Exception) {
            try { startActivity(Intent("android.settings.MANAGE_DEFAULT_APPS_SETTINGS")) } catch (_: Exception) {
                try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
            }
        }
    }

    // ---------- مكتبة الصوت (Vosk) ----------
    private fun voiceLibMenu() {
        val ls = Langs.all
        val items = ls.map { l ->
            val st = when {
                vosk.installed(l.code) && vosk.lang == l.code -> "✅ شغّالة"
                vosk.installed(l.code) -> "✔ منزّلة"
                else -> "غير منزّلة (${l.mb}MB)"
            }
            "${l.label} — $st"
        } + listOf("📦 إضافة موديل صوت من ملف zip", "🗑 حذف لغة")
        AlertDialog.Builder(this).setTitle("🎙 مكتبة الصوت (Vosk)").setItems(items.toTypedArray()) { _, i ->
            when {
                i < ls.size -> langOptions(ls[i])
                i == ls.size -> importLangMenu()
                else -> deleteLangMenu()
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun langOptions(l: Lang) {
        if (vosk.installed(l.code)) { setLang(l); return }
        val items = arrayOf("⬇ تنزيل من الإنترنت (${l.mb}MB، مرة واحدة)", "📦 استيراد ملف zip نزّلتيه")
        AlertDialog.Builder(this).setTitle(l.label).setItems(items) { _, i ->
            if (i == 0) {
                confirm("هنزّل ${l.label} (${l.mb}MB) من الإنترنت مرة واحدة بس، وبعدها بتشتغل من غير نت. نكمل؟") { downloadLang(l) }
            } else {
                pendingLang = l
                add("نيكو: اختاري ملف موديل ${l.label} (zip).")
                pickVosk.launch(arrayOf("*/*"))
            }
        }.show()
    }

    private fun importLangMenu() {
        val ls = Langs.all
        AlertDialog.Builder(this).setTitle("الموديل ده لأنهي لغة؟").setItems(ls.map { it.label }.toTypedArray()) { _, i ->
            pendingLang = ls[i]
            pickVosk.launch(arrayOf("*/*"))
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun importLangZip(l: Lang, uri: Uri) {
        status.text = "بفك الموديل..."; orb.state = WaterOrbView.State.THINKING
        thread {
            val err: String? = try {
                val input = contentResolver.openInputStream(uri)
                if (input == null) "مقدرتش أفتح الملف." else input.use { vosk.installStream(l.code, it) { m -> runOnUiThread { status.text = m } } }
            } catch (e: Exception) {
                "فشل الاستيراد: ${e.message}"
            }
            runOnUiThread {
                status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                if (err == null) { add("نيكو: موديل ${l.label} جاهز."); setLang(l) } else add("نيكو: $err")
            }
        }
    }

    private fun downloadLang(l: Lang) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        orb.state = WaterOrbView.State.THINKING; status.text = "بنزّل ${l.label}…"
        thread {
            val err = vosk.download(l) { m -> runOnUiThread { status.text = m } }
            runOnUiThread {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"
                if (err == null) { add("نيكو: ${l.label} اتنزلت وهتشتغل من غير نت."); setLang(l) } else add("نيكو: $err")
            }
        }
    }

    private fun deleteLangMenu() {
        val ls = vosk.installedLangs()
        if (ls.isEmpty()) { add("نيكو: مفيش لغات منزّلة."); return }
        AlertDialog.Builder(this).setTitle("حذف لغة").setItems(ls.map { it.label }.toTypedArray()) { _, i ->
            val l = ls[i]
            vosk.delete(l.code)
            add("نيكو: اتمسحت ${l.label}.")
        }.setNegativeButton("إلغاء", null).show()
    }

    private fun setLang(l: Lang) {
        vosk.stop(); vosk.lang = l.code; llm.replyLang = l; applyTts()
        add("نيكو: اللغة دلوقتي: ${l.label}.")
    }

    private fun listenVosk() {
        tts?.stop(); orb.state = WaterOrbView.State.LISTENING; status.text = "بجهّز الاستماع..."
        thread {
            val err = vosk.prepare()
            runOnUiThread {
                if (err != null) {
                    orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"; add("نيكو: $err")
                    return@runOnUiThread
                }
                status.text = "بسمعك..."
                vosk.listen(
                    onPartial = { t -> runOnUiThread { orb.pulse(0.8f); status.text = t } },
                    onFinal = { t ->
                        runOnUiThread { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE }
                        if (t.isNotBlank()) {
                            val pcm = vosk.lastAudio()
                            thread {
                                val sp = identifySpeaker(pcm)
                                runOnUiThread { handleHeard(t, sp) }
                            }
                        }
                    },
                    onError = { m -> runOnUiThread { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; add("نيكو: $m") } }
                )
            }
        }
    }

    // ---------- مكتبة الذكاء (موديلات LLM) ----------
    private fun llmLibMenu() {
        val all = llm.models()
        val active = llm.modelFile.name
        val items = all.map { f -> (if (f.name == active) "✅ " else "• ") + f.name + "  (" + (f.length() / 1_000_000) + "MB)" } +
            listOf("➕ إضافة موديل ذكاء (.task / .litertlm)", "ℹ أنواع الموديلات المدعومة")
        AlertDialog.Builder(this).setTitle("🧠 مكتبة الذكاء").setItems(items.toTypedArray()) { _, i ->
            when {
                i < all.size -> llmOptions(all[i])
                i == all.size -> pickLlm.launch(arrayOf("*/*"))
                else -> llmTypesInfo()
            }
        }.setNegativeButton("إغلاق", null).show()
    }

    private fun llmOptions(f: File) {
        AlertDialog.Builder(this).setTitle(f.name).setItems(arrayOf("✅ استخدام الموديل ده", "🗑 حذف الموديل")) { _, i ->
            if (i == 0) {
                llm.setActive(f)
                status.text = "بحمّل الموديل..."; orb.state = WaterOrbView.State.THINKING
                thread {
                    val err = llm.load()
                    runOnUiThread {
                        status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                        add(if (err == null) "نيكو: الموديل جاهز (${f.name})." else "نيكو: $err")
                    }
                }
            } else {
                confirm("حذف ${f.name}؟") { llm.deleteModel(f); add("نيكو: اتمسح ${f.name}.") }
            }
        }.show()
    }

    private fun llmTypesInfo() {
        AlertDialog.Builder(this).setTitle("أنواع الموديلات")
            .setMessage("• .task — صيغة MediaPipe (Gemma وQwen2.5 وغيرهم). ده المدعوم بشكل أساسي.\n\n• .litertlm — صيغة LiteRT-LM (Gemma 3n وQwen3). ممكن مايشتغلش مع المحرك الحالي.\n\n• .gguf (زي Qwen3 Q4_K_M) — صيغة llama.cpp، ومش مدعومة حالياً لأنها محتاجة محرك تاني.\n\nتقدري تضيفي أكتر من موديل وتختاري الشغّال من القايمة.")
            .setPositiveButton("تمام", null).show()
    }

    private fun installLlm(uri: Uri) {
        var name = "model.task"
        try {
            contentResolver.query(uri, null, null, null, null)?.use {
                if (it.moveToFirst()) {
                    val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0) name = it.getString(i) ?: name
                }
            }
        } catch (_: Exception) {}
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext == "gguf") { llmTypesInfo(); return }
        if (ext != "task" && ext != "litertlm" && ext != "bin") { add("نيكو: النوع ده مش مدعوم. المدعوم: .task أو .litertlm"); return }
        status.text = "بنسخ موديل الذكاء..."
        thread {
            val dst = llm.fileFor(name)
            val tmp = File(dst.parentFile, "copy.tmp")
            val ok: Boolean = try {
                val pfd = contentResolver.openFileDescriptor(uri, "r")
                if (pfd == null) false else {
                    val copied: Boolean = pfd.use { d ->
                        java.io.FileInputStream(d.fileDescriptor).use { fin ->
                            java.io.FileOutputStream(tmp).use { fout ->
                                val inCh = fin.channel
                                val outCh = fout.channel
                                val size = inCh.size()
                                var pos = 0L
                                while (pos < size) {
                                    val n = inCh.transferTo(pos, minOf(64L shl 20, size - pos), outCh)
                                    if (n <= 0L) break
                                    pos += n
                                    val shown = pos / 1_000_000
                                    runOnUiThread { status.text = "بنسخ… $shown MB" }
                                }
                                size > 0L && pos >= size
                            }
                        }
                    }
                    copied && tmp.renameTo(dst)
                }
            } catch (e: Exception) {
                tmp.delete(); false
            }
            if (ok) llm.setActive(dst)
            val err = if (ok) llm.load() else "النسخ فشل (مساحة التخزين كفاية؟)."
            runOnUiThread {
                status.text = "نيكو"
                add(if (err == null) "نيكو: موديل الذكاء جاهز ✅ ($name)" else "نيكو: $err")
            }
        }
    }

    // ---------- بصمة الصوت ----------
    private fun warmUp() {
        thread {
            try { if (vosk.available()) vosk.prepare() } catch (_: Throwable) {}
            try { if (llm.installed) llm.load() } catch (_: Throwable) {}
        }
    }

    private fun identifySpeaker(pcm: ShortArray): Person? {
        if (people.list.none { it.voice != null } || !Voiceprint.ready(vosk) || pcm.size < 16000 * 2) return null
        return Voiceprint.identify(Voiceprint.embed(vosk, pcm, pcm.size), people.list)
    }

    private fun handleHeard(t: String, sp: Person?) {
        speaker = sp
        if (prefs.getBoolean("ownerOnly", false)) {
            val o = people.owner()
            if (o != null && o.voice != null && sp?.id != o.id) {
                add("أنتِ: $t"); reply("الصوت ده مش صوتك، مش هنفذ."); return
            }
        }
        if (sp != null) status.text = "🎙 ${sp.name}"
        process(t)
    }

    private fun ensureSpk(after: () -> Unit) {
        if (Voiceprint.ready(vosk)) { after(); return }
        confirm("محتاج موديل بصمة الصوت (${Langs.SPK_MB}MB) من النت مرة واحدة بس. أنزّله؟") {
            status.text = "بنزّل موديل بصمة الصوت…"
            thread {
                val err = vosk.downloadSpk { msg -> runOnUiThread { status.text = msg } }
                runOnUiThread { status.text = "نيكو"; if (err == null) after() else add("نيكو: $err") }
            }
        }
    }

    private fun recordVoiceprint(p: Person) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            add("نيكو: اسمحي بإذن المايك الأول وبعدين جرّبي تاني."); return
        }
        if (vosk.installedLangs().isEmpty()) { add("نيكو: أضيفي موديل صوت (عربي مثلاً) الأول من مكتبة الصوت."); return }
        ensureSpk { runVoiceRecording(p) }
    }

    private fun runVoiceRecording(p: Person) {
        vosk.stop()
        val prompts = listOf("قولي: أنا اسمي ${p.name} وده صوتي", "قولي: نيكو افتح الكاميرا وبعدين اتصل بماما", "اتكلمي أي كلام عادي لحد ما أقولك")
        thread {
            try { Thread.sleep(600) } catch (_: Throwable) {}
            val vecs = ArrayList<FloatArray>()
            for ((i, pr) in prompts.withIndex()) {
                runOnUiThread { orb.state = WaterOrbView.State.LISTENING; orb.pulse(0.8f); status.text = "(${i + 1}/3) $pr" }
                val pcm = try { captureSeconds(5) } catch (e: Throwable) { ShortArray(0) }
                val v = Voiceprint.embed(vosk, pcm, pcm.size)
                if (v != null) vecs.add(v)
            }
            val avg = Voiceprint.average(vecs)
            runOnUiThread {
                orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"
                if (avg != null && vecs.size >= 2) { p.voice = avg; people.save(); add("نيكو: حفظت بصمة صوت ${p.name}.") }
                else add("نيكو: البصمة ماتسجلتش (الصوت مش واضح أو الميزة مش متاحة في نسخة Vosk دي). جربي في مكان هادي.")
                peopleMenu()
            }
        }
    }

    private fun captureSeconds(sec: Int): ShortArray {
        val sr = 16000
        val out = ShortArray(sr * sec)
        val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000))
        var n = 0
        try {
            rec.startRecording()
            while (n < out.size) {
                val k = rec.read(out, n, minOf(1600, out.size - n))
                if (k <= 0) break
                n += k
            }
        } finally {
            try { rec.stop() } catch (_: Throwable) {}
            rec.release()
        }
        return out.copyOf(n)
    }

    private fun importVoiceFile(p: Person, uri: Uri) {
        ensureSpk {
            status.text = "بحلل الصوت..."; orb.state = WaterOrbView.State.THINKING
            thread {
                val pcm = decodeAudio(uri)
                val v = if (pcm != null && pcm.size >= 16000 * 3) Voiceprint.embed(vosk, pcm, minOf(pcm.size, 16000 * 20)) else null
                runOnUiThread {
                    status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                    if (v != null) { p.voice = v; people.save(); add("نيكو: حفظت بصمة ${p.name} من الملف.") }
                    else add("نيكو: معرفتش أطلع بصمة من الملف (لازم صوت واضح 3 ثواني على الأقل).")
                    peopleMenu()
                }
            }
        }
    }

    /** بيفك أي ملف صوتي (mp3/m4a/wav/ogg...) لـ 16kHz mono. */
    private fun decodeAudio(uri: Uri): ShortArray? {
        val ex = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            ex.setDataSource(this, uri, null)
            var idx = -1
            var fmt: MediaFormat? = null
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; fmt = f; break }
            }
            if (idx < 0 || fmt == null) return null
            ex.selectTrack(idx)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: return null
            var sr = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            val c = MediaCodec.createDecoderByType(mime)
            codec = c
            c.configure(fmt, null, null, 0)
            c.start()
            val info = MediaCodec.BufferInfo()
            val out = java.io.ByteArrayOutputStream()
            var inDone = false
            var outDone = false
            var guard = 0
            while (!outDone && guard < 20000) {
                guard++
                if (!inDone) {
                    val ii = c.dequeueInputBuffer(10000)
                    if (ii >= 0) {
                        val buf = c.getInputBuffer(ii)
                        val n = if (buf != null) ex.readSampleData(buf, 0) else -1
                        if (n < 0) { c.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                        else { c.queueInputBuffer(ii, 0, n, ex.sampleTime, 0); ex.advance() }
                    }
                }
                val oi = c.dequeueOutputBuffer(info, 10000)
                if (oi >= 0) {
                    val ob = c.getOutputBuffer(oi)
                    if (ob != null && info.size > 0) { val chunk = ByteArray(info.size); ob.get(chunk); out.write(chunk) }
                    c.releaseOutputBuffer(oi, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outDone = true
                    if (out.size() > sr * ch * 2 * 40) outDone = true
                } else if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = c.outputFormat
                    sr = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    ch = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            }
            val sb = java.nio.ByteBuffer.wrap(out.toByteArray()).order(java.nio.ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val total = sb.remaining() / ch
            if (total <= 0) return null
            val outLen = (total.toLong() * 16000 / sr).toInt()
            val res = ShortArray(outLen)
            for (i in 0 until outLen) {
                val src = minOf((i.toLong() * sr / 16000).toInt(), total - 1)
                var acc = 0
                for (k in 0 until ch) acc += sb.get(src * ch + k).toInt()
                res[i] = (acc / ch).toShort()
            }
            return res
        } catch (e: Throwable) {
            return null
        } finally {
            try { codec?.stop() } catch (_: Throwable) {}
            try { codec?.release() } catch (_: Throwable) {}
            try { ex.release() } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() { sr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
