package com.nico.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import kotlin.math.sqrt
import java.io.File

class Person(val id: String, var name: String, var phone: String = "", var photo: String = "", var voice: FloatArray? = null, var owner: Boolean = false, var birthday: String = "", var relation: String = "")

/** الأشخاص: اسم + صورة + رقم (لواتساب) + بصمة صوت. بيتخزنوا محلياً بس. */
class People(private val ctx: Context) {
    private val f = File(ctx.filesDir, "people.json")
    val list: MutableList<Person> = load()

    private fun load(): MutableList<Person> = try {
        val a = JSONArray(f.readText()); val out = ArrayList<Person>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val v = o.optJSONArray("voice")?.let { arr -> FloatArray(arr.length()) { arr.getDouble(it).toFloat() } }
            out.add(Person(o.getString("id"), o.getString("name"), o.optString("phone"), o.optString("photo"), v, o.optBoolean("owner"), o.optString("birthday"), o.optString("relation")))
        }
        out
    } catch (_: Exception) { mutableListOf() }

    fun save() {
        val a = JSONArray()
        list.forEach { p ->
            val o = JSONObject().put("id", p.id).put("name", p.name).put("phone", p.phone).put("photo", p.photo).put("owner", p.owner).put("birthday", p.birthday).put("relation", p.relation)
            p.voice?.let { v -> o.put("voice", JSONArray(v.map { it.toDouble() })) }
            a.put(o)
        }
        try { f.writeText(a.toString()) } catch (_: Exception) {}
    }

    fun add(name: String): Person { val p = Person(System.currentTimeMillis().toString(), name); list.add(p); save(); return p }
    fun remove(p: Person) { list.remove(p); try { File(p.photo).delete() } catch (_: Exception) {}; save() }
    fun owner(): Person? = list.firstOrNull { it.owner }

    fun byName(spoken: String): Person? {
        val q = Skills.norm(spoken).trim(); if (q.isBlank()) return null
        list.firstOrNull { Skills.norm(it.name) == q }?.let { return it }
        list.firstOrNull { val n = Skills.norm(it.name); n.contains(q) || q.contains(n) }?.let { return it }
        return list.firstOrNull { Mix.lev(Skills.norm(it.name), q) <= 1 && q.length >= 3 }
    }
}


/** بصمة الصوت: متجه x-vector من موديل Vosk للمتكلم + مقارنة cosine. بتتنادى بالـ reflection عشان البناء ما يقعش لو النسخة مختلفة. */
object Voiceprint {
    var threshold = 0.45
    private var spk: Any? = null

    fun ready(v: VoskEngine) = File(v.dirFor("spk"), "final.ext.raw").exists()

    @Synchronized
    private fun spkModel(v: VoskEngine): Any? {
        if (spk == null && ready(v)) {
            spk = try {
                Class.forName("org.vosk.SpeakerModel").getConstructor(String::class.java).newInstance(v.dirFor("spk").absolutePath)
            } catch (_: Throwable) { null }
        }
        return spk
    }

    /** بيطلّع متجه البصمة من صوت 16kHz mono. بيرجع null لو الميزة مش متاحة أو الصوت قصير. */
    fun embed(v: VoskEngine, pcm: ShortArray, n: Int): FloatArray? {
        if (n < 16000) return null
        val sm = spkModel(v) ?: return null
        val code = listOf("en", "ar").firstOrNull { v.installed(it) } ?: v.installedLangs().firstOrNull()?.code ?: return null
        val model = v.modelOf(code) ?: return null
        var r: Recognizer? = null
        return try {
            val ctor = Recognizer::class.java.getConstructor(Model::class.java, java.lang.Float.TYPE, Class.forName("org.vosk.SpeakerModel"))
            val rec = ctor.newInstance(model, 16000f, sm) as Recognizer
            r = rec
            VoskCompat.feed(rec, pcm, n)
            val a = JSONObject(rec.finalResult).optJSONArray("spk") ?: return null
            FloatArray(a.length()) { a.getDouble(it).toFloat() }
        } catch (_: Throwable) { null } finally { VoskCompat.close(r) }
    }

    fun dist(a: FloatArray, b: FloatArray): Double {
        var d = 0.0; var na = 0.0; var nb = 0.0
        for (i in 0 until minOf(a.size, b.size)) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        return if (na == 0.0 || nb == 0.0) 1.0 else 1.0 - d / (sqrt(na) * sqrt(nb))
    }

    fun identify(vec: FloatArray?, people: List<Person>): Person? {
        if (vec == null) return null
        var best: Person? = null; var bd = 2.0
        for (p in people) {
            val pv = p.voice ?: continue
            val d = dist(vec, pv)
            if (d < bd) { bd = d; best = p }
        }
        return if (best != null && bd < threshold) best else null
    }

    fun average(vs: List<FloatArray>): FloatArray? {
        if (vs.isEmpty()) return null
        val out = FloatArray(vs[0].size)
        for (v in vs) for (i in out.indices) out[i] += v[i] / vs.size
        return out
    }
}
