package com.nico.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer

/** نيكو كمساعد رقمي افتراضي: بيظهر في إعدادات "تطبيق المساعد الرقمي" وبيتفتح بالضغط المطوّل على Home أو زر التشغيل. */
class NicoInteractionService : VoiceInteractionService()

class NicoSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = NicoSession(this)
}

class NicoSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        try {
            context.startActivity(Intent(context, LauncherActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("assist", true))
        } catch (_: Throwable) {}
        hide()
    }
}

/** الأندرويد بيطلب RecognitionService مع أي مساعد رقمي. ده تنفيذ بسيط؛ نيكو بيسمع من جوه تطبيقه. */
class NicoRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: RecognitionService.Callback?) {
        try { listener?.error(SpeechRecognizer.ERROR_CLIENT) } catch (_: Throwable) {}
    }
    override fun onCancel(listener: RecognitionService.Callback?) {}
    override fun onStopListening(listener: RecognitionService.Callback?) {}
}
