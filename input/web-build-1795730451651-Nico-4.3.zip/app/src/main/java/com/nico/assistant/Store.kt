package com.nico.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

class Chat(val id: String, var title: String, var ts: Long)

/** تخزين دائم: محادثات متعددة (زي ChatGPT) + الذاكرة طويلة المدى (بموافقة المستخدم). */
class Store(ctx: Context) {
    private val dir = File(ctx.filesDir, "chats")
    private val idx = File(dir, "index.json")
    private val old = File(ctx.filesDir, "history.json")
    private val mf = File(ctx.filesDir, "memory.json")

    private fun read(f: File): MutableList<String> = try {
        val a = JSONArray(f.readText()); MutableList(a.length()) { a.getString(it) }
    } catch (_: Exception) { mutableListOf() }
    private fun write(f: File, l: List<String>) { try { f.parentFile?.mkdirs(); f.writeText(JSONArray(l).toString()) } catch (_: Exception) {} }

    val chats: MutableList<Chat> = ArrayList()
    var current: Chat
        private set
    var lines: MutableList<String> = ArrayList()
        private set
    val memories: MutableList<String> = read(mf)

    init {
        dir.mkdirs()
        try {
            val a = JSONArray(idx.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                chats.add(Chat(o.getString("id"), o.optString("title", "محادثة"), o.optLong("ts")))
            }
        } catch (_: Exception) {}
        if (chats.isEmpty()) {
            val c = Chat(newId(), "محادثة جديدة", System.currentTimeMillis())
            chats.add(c)
            val ol = read(old)
            if (ol.isNotEmpty()) {
                write(file(c), ol)
                c.title = ol.firstOrNull { it.startsWith("أنتِ: ") }?.removePrefix("أنتِ: ")?.take(32) ?: "محادثة قديمة"
            }
            saveIndex()
        }
        current = chats.maxByOrNull { it.ts } ?: chats[0]
        lines = read(file(current))
    }

    private fun newId() = java.util.UUID.randomUUID().toString().take(8)
    private fun file(c: Chat) = File(dir, c.id + ".json")
    private fun saveIndex() {
        try {
            val a = JSONArray()
            chats.forEach { a.put(JSONObject().put("id", it.id).put("title", it.title).put("ts", it.ts)) }
            idx.writeText(a.toString())
        } catch (_: Exception) {}
    }

    fun sorted(): List<Chat> = chats.sortedByDescending { it.ts }

    fun addLine(s: String) {
        lines.add(s); while (lines.size > 600) lines.removeAt(0)
        if (s.startsWith("أنتِ: ") && (current.title == "محادثة جديدة" || current.title == "محادثة قديمة")) current.title = s.removePrefix("أنتِ: ").take(32)
        current.ts = System.currentTimeMillis()
        write(file(current), lines); saveIndex()
    }
    fun clearHistory() { lines.clear(); write(file(current), lines) }

    fun newChat(): Chat {
        val c = Chat(newId(), "محادثة جديدة", System.currentTimeMillis())
        chats.add(c); current = c; lines = ArrayList(); write(file(c), lines); saveIndex(); return c
    }
    fun switchTo(id: String) { val c = chats.firstOrNull { it.id == id } ?: return; current = c; lines = read(file(c)) }
    fun deleteChat(id: String) {
        val c = chats.firstOrNull { it.id == id } ?: return
        chats.remove(c); try { file(c).delete() } catch (_: Exception) {}
        if (chats.isEmpty()) newChat() else if (current.id == id) { current = chats.maxByOrNull { it.ts } ?: chats[0]; lines = read(file(current)) }
        saveIndex()
    }
    fun rename(id: String, title: String) { chats.firstOrNull { it.id == id }?.let { if (title.isNotBlank()) it.title = title.trim().take(40); saveIndex() } }

    fun addMemory(s: String) { if (s.isNotBlank() && memories.none { it == s }) { memories.add(s.trim()); write(mf, memories) } }
    fun removeMemory(i: Int) { if (i in memories.indices) { memories.removeAt(i); write(mf, memories) } }
    fun removeMemoryLike(t: String): Int { val n = memories.size; memories.removeAll { it.contains(t) }; write(mf, memories); return n - memories.size }
    fun clearMemory() { memories.clear(); write(mf, memories) }
    fun memoryText() = memories.joinToString("؛ ")

    /** آخر أزواج (سؤال، رد) من المحادثة الحالية عشان الذكاء يكمل من حيث وقف. */
    fun pairs(): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        var q: String? = null
        for (l in lines) {
            if (l.startsWith("أنتِ: ")) q = l.removePrefix("أنتِ: ")
            else if (l.startsWith("نيكو: ") && q != null) { out.add(q to l.removePrefix("نيكو: ")); q = null }
        }
        return out
    }
}
