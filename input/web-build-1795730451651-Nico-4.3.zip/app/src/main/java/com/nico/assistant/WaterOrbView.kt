package com.nico.assistant

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/**
 * نيكو: كرة ميد نايت حرة (من غير مية). وقت الكلام جنباتها بتتمدد وتنضغط وبتتمايل يمين وشمال،
 * والمشاعر بتغيّر طريقة الحركة (الغضب = حركة مسننة وسريعة، الزعل = بطيئة وهادية).
 * (الاسم القديم WaterOrbView اتسابت عشان باقي الملفات.)
 */
class WaterOrbView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state = State.IDLE
    var lowPower = false
    private var emo = Emotion.NEUTRAL
    private var emoUntil = 0L
    fun feel(e: Emotion, ms: Long = 5000) { emo = e; emoUntil = if (e == Emotion.NEUTRAL) 0L else nowMs() + ms }
    fun pulse(v: Float = 1f) { target = v.coerceIn(0f, 1f) }
    private fun nowMs() = System.nanoTime() / 1_000_000

    private var target = 0f
    private var level = 0f
    private var amp = 0.006f
    private var env = 0f
    private var sway = 0f
    private val t0 = System.nanoTime()

    private var cx = 0f; private var cy = 0f; private var r = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val blob = Path()
    private var body: Shader? = null
    private var shine: Shader? = null

    private var tint = 0xFF3347D6.toInt()
    private var GLOW = tint
    private var RIM = 0xFF6B7CFF.toInt()

    /** لون الكرة الأساسي (من إعدادات الكرة). التدرج والتوهج والإطار بيتشتقوا منه. */
    fun setTint(base: Int) {
        tint = base or 0xFF000000.toInt()
        GLOW = shade(tint, 1.15f)
        RIM = shade(tint, 1.6f)
        if (width > 0 && height > 0) { geometry(width, height); invalidate() }
    }

    private fun shade(c: Int, f: Float): Int {
        val r = (Color.red(c) * f).toInt().coerceIn(0, 255)
        val g = (Color.green(c) * f).toInt().coerceIn(0, 255)
        val b = (Color.blue(c) * f).toInt().coerceIn(0, 255)
        return Color.rgb(r, g, b)
    }

    private var userScale = 1f
    private var offX = 0f
    private var offY = 0f

    /** حجم (0.5..1.5) ومكان (-0.6..0.6) من إعدادات الكرة. */
    fun adjust(size: Float, x: Float, y: Float) {
        userScale = size.coerceIn(0.4f, 1.6f); offX = x.coerceIn(-0.7f, 0.7f); offY = y.coerceIn(-0.7f, 0.7f)
        if (width > 0 && height > 0) { geometry(width, height); invalidate() }
    }

    private fun geometry(w: Int, h: Int) {
        cx = w / 2f + offX * w / 2f; cy = h / 2f + offY * h / 2f
        r = min(w, h) / 2f * 0.80f * userScale
        body = RadialGradient(cx - r * 0.30f, cy - r * 0.35f, r * 1.45f,
            intArrayOf(shade(tint, 1.5f), shade(tint, 0.55f), shade(tint, 0.18f)), floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP)
        shine = RadialGradient(cx - r * 0.38f, cy - r * 0.48f, r * 0.62f, intArrayOf(0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { geometry(w, h) }

    /** حدود الكرة: دايرة + تمدد جانبي (cos 2θ) + موجات تانية. */
    private fun buildBlob(t: Float, a: Float, side: Float, e: Emotion) {
        blob.reset()
        val n = 96
        val sp = when (e) { Emotion.ANGRY -> 1.9f; Emotion.SAD -> 0.55f; Emotion.LAUGH, Emotion.HAPPY -> 1.3f; else -> 1f }
        val k2 = if (e == Emotion.ANGRY) 7 else 3
        val k3 = if (e == Emotion.ANGRY) 11 else 5
        for (i in 0..n) {
            val th = i.toFloat() / n * 6.2831855f
            val d = side * cos(2f * th) +
                a * (sin(k2 * th - t * 4.3f * sp + 1.3f) * 0.6f + sin(k3 * th + t * 5.7f * sp + 2.1f) * 0.4f)
            val rr = r * (1f + d)
            val x = cx + rr * cos(th); val y = cy + rr * sin(th)
            if (i == 0) blob.moveTo(x, y) else blob.lineTo(x, y)
        }
        blob.close()
    }

    override fun onDraw(cv: Canvas) {
        if (r <= 0f) return
        val t = (System.nanoTime() - t0) / 1e9f
        if (emoUntil != 0L && nowMs() > emoUntil) { emo = Emotion.NEUTRAL; emoUntil = 0L }
        val e = emo

        target *= 0.93f; level += (target - level) * 0.18f
        val speech = abs(sin(t * 7.3f)) * (0.55f + 0.45f * abs(sin(t * 3.1f + 1f))) * (0.7f + 0.3f * sin(t * 13f))
        env += (speech.coerceIn(0f, 1f) - env) * 0.25f

        val tgtAmp = when (state) {
            State.IDLE -> 0.008f
            State.LISTENING -> 0.012f + 0.05f * level
            State.THINKING -> 0.02f + 0.01f * sin(t * 3f)
            State.SPEAKING -> 0.025f + 0.05f * env
        }
        amp += (tgtAmp - amp) * 0.22f
        // التمدد الجانبي: بيطلع من الجنبين مع كل مقطع كلام
        val tgtSide = when (state) {
            State.SPEAKING -> 0.05f + 0.12f * env * (0.6f + 0.4f * sin(t * 6.1f))
            State.LISTENING -> 0.01f + 0.07f * level
            State.THINKING -> 0.015f * sin(t * 2.5f)
            State.IDLE -> 0.008f * sin(t * 1.4f)
        }
        side = side + (tgtSide - side) * 0.3f
        // الكرة نفسها بتتمايل يمين وشمال وهي بتتكلم
        val tgtSway = if (state == State.SPEAKING) r * 0.10f * env * sin(t * 5.2f) else 0f
        sway += (tgtSway - sway) * 0.2f

        buildBlob(t, amp, side, e)
        cv.save(); cv.translate(sway, 0f)

        for (i in 6 downTo 1) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE
            p.strokeWidth = r * 0.05f * i; p.color = GLOW
            var al = 9 + 3 * (7 - i)
            if (state == State.SPEAKING) al += (30 * env).toInt()
            if (state == State.LISTENING) al += (30 * level).toInt()
            p.alpha = al.coerceAtMost(90); cv.drawPath(blob, p)
        }
        p.reset(); p.isAntiAlias = true; p.shader = body; cv.drawPath(blob, p)
        p.reset(); p.isAntiAlias = true; p.shader = shine; cv.drawPath(blob, p)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.02f; p.color = RIM; p.alpha = 0xCC
        cv.drawPath(blob, p)
        if (state == State.THINKING) {
            p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.04f; p.strokeCap = Paint.Cap.ROUND; p.color = Color.WHITE
            cv.drawArc(cx - r * 1.2f, cy - r * 1.2f, cx + r * 1.2f, cy + r * 1.2f, t * 220f, 70f, false, p)
        }
        cv.restore()
        if (lowPower && state == State.IDLE && e == Emotion.NEUTRAL) postInvalidateDelayed(110) else postInvalidateOnAnimation()
    }

    private var side = 0f
}
