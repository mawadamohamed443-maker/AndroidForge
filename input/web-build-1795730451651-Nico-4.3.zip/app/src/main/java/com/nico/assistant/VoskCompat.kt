package com.nico.assistant

import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

/**
 * غلاف حوالين Vosk. المستخدم مباشرة (متأكد منه من أمثلة Vosk الرسمية): Model(path) و Recognizer(model, rate)
 * و acceptWaveForm(byte[], len) و getResult/getPartialResult/getFinalResult و close().
 * أي حاجة تانية (قاموس محدود للكلمات) بتتنادى بالـ reflection عشان البناء ما يقعش لو النسخة مختلفة.
 */
object VoskCompat {
    fun newRecognizer(model: Model, rate: Float, grammar: String? = null): Recognizer {
        if (grammar != null) {
            try {
                val c = Recognizer::class.java.getConstructor(Model::class.java, java.lang.Float.TYPE, String::class.java)
                return c.newInstance(model, rate, grammar) as Recognizer
            } catch (_: Throwable) {}
        }
        return Recognizer(model, rate)
    }

    fun pcmBytes(pcm: ShortArray, n: Int): ByteArray {
        val out = ByteArray(n * 2)
        for (i in 0 until n) {
            val v = pcm[i].toInt()
            out[2 * i] = (v and 0xFF).toByte()
            out[2 * i + 1] = ((v shr 8) and 0xFF).toByte()
        }
        return out
    }

    /** بيدّي الصوت للـ recognizer. بيرجع true لما يخلص جملة. */
    fun feed(r: Recognizer, pcm: ShortArray, n: Int): Boolean {
        val b = pcmBytes(pcm, n)
        return r.acceptWaveForm(b, b.size)
    }

    fun text(json: String): String = try { JSONObject(json).optString("text") } catch (_: Throwable) { "" }
    fun partial(json: String): String = try { JSONObject(json).optString("partial") } catch (_: Throwable) { "" }
    fun close(r: Recognizer?) { try { r?.close() } catch (_: Throwable) {} }
}
