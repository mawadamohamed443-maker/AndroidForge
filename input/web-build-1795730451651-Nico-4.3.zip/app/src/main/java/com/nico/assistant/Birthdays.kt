package com.nico.assistant

import java.util.Calendar

/** أعياد ميلاد الأشخاص: تاريخ بصيغة يوم/شهر أو يوم/شهر/سنة. */
object Birthdays {
    private val rx = Regex("(\\d{1,2})\\s*[/\\-.]\\s*(\\d{1,2})(?:\\s*[/\\-.]\\s*(\\d{4}))?")

    fun parse(s: String): Triple<Int, Int, Int?>? {
        val m = rx.find(Skills.norm(s)) ?: return null
        val d = m.groupValues[1].toInt(); val mo = m.groupValues[2].toInt()
        if (d !in 1..31 || mo !in 1..12) return null
        return Triple(d, mo, m.groupValues[3].toIntOrNull())
    }

    private fun midnight(c: Calendar): Calendar {
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0); return c
    }

    /** كام يوم لحد عيد الميلاد الجاي (0 = النهارده). */
    fun daysUntil(p: Person): Int? {
        val b = parse(p.birthday) ?: return null
        val today = midnight(Calendar.getInstance())
        val cand = midnight(Calendar.getInstance())
        cand.set(Calendar.MONTH, b.second - 1); cand.set(Calendar.DAY_OF_MONTH, b.first)
        if (cand.before(today)) cand.add(Calendar.YEAR, 1)
        return ((cand.timeInMillis - today.timeInMillis) / 86_400_000L).toInt()
    }

    fun age(p: Person): Int? {
        val y = parse(p.birthday)?.third ?: return null
        val a = Calendar.getInstance().get(Calendar.YEAR) - y
        return if (a in 1..120) a else null
    }

    private fun label(p: Person): String {
        val d = daysUntil(p) ?: return p.name
        val a = age(p)?.let { " (هيبقى عنده $it سنة)" } ?: ""
        return when (d) { 0 -> "النهارده عيد ميلاد ${p.name}$a"; 1 -> "بكرة عيد ميلاد ${p.name}$a"; else -> "عيد ميلاد ${p.name} بعد $d يوم$a" }
    }

    /** رسالة تهنئة لو في عيد ميلاد النهارده أو بكرة، وإلا null. */
    fun greeting(people: List<Person>): String? {
        val today = people.filter { daysUntil(it) == 0 }
        val tomorrow = people.filter { daysUntil(it) == 1 }
        val parts = ArrayList<String>()
        if (today.isNotEmpty()) parts.add("النهارده عيد ميلاد " + today.joinToString(" و ") { it.name } + "، كل سنة وهو طيب! فكّر تكلمه.")
        if (tomorrow.isNotEmpty()) parts.add("وبكرة عيد ميلاد " + tomorrow.joinToString(" و ") { it.name } + ".")
        return if (parts.isEmpty()) null else parts.joinToString(" ")
    }

    /** أسئلة زي: "عيد ميلاد ماما امتى" / "عيد ميلاد مين النهارده" / "عيد الميلاد الجاي". */
    fun reply(raw: String, people: People): String? {
        val q = Skills.norm(raw)
        if (!(q.contains("عيد ميلاد") || q.contains("عيد الميلاد") || q.contains("birthday"))) return null
        val withDate = people.list.filter { Birthdays.parse(it.birthday) != null }
        if (q.contains("النهارده") || q.contains("انهارده") || q.contains("اليوم")) {
            val t = withDate.filter { daysUntil(it) == 0 }
            return if (t.isEmpty()) "مفيش حد عيد ميلاده النهارده." else "النهارده عيد ميلاد " + t.joinToString(" و ") { it.name } + "."
        }
        if (q.contains("الجاي") || q.contains("القادم") || q.contains("قريب") || q.contains("الجاى")) {
            val n = withDate.minByOrNull { daysUntil(it) ?: 999 } ?: return "مفيش تواريخ ميلاد متسجلة لسه. سجليها من الأشخاص."
            return label(n)
        }
        val stop = setOf("عيد", "ميلاد", "الميلاد", "امتي", "امتى", "متي", "ايه", "مين", "كام", "سن", "عمر", "بتاع", "بتاعه", "لـ", "ل", "هو", "هي", "birthday", "when", "is")
        val name = q.split(" ").filter { it !in stop }.joinToString(" ").trim()
        val p = people.byName(name) ?: return null
        if (Birthdays.parse(p.birthday) == null) return "مش مسجل تاريخ ميلاد ${p.name}. سجليه من الأشخاص."
        return label(p)
    }
}
