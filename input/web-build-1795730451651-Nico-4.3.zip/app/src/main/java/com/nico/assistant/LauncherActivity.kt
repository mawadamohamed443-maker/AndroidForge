package com.nico.assistant

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File

/**
 * أول شاشة بتفتح: لو في انهيار قديم متسجل بتعرضه (تقدري تصوريه أو تنسخيه وتبعتيه)، وإلا بتفتح نيكو على طول.
 * مكتوبة بالكود من غير تخطيط XML عشان ما تقعش هي نفسها.
 */
class LauncherActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val f = File(filesDir, "crash.txt")
        if (!f.exists()) {
            val assist = intent?.action == Intent.ACTION_ASSIST || intent?.getBooleanExtra("assist", false) == true
            startActivity(Intent(this, MainActivity::class.java).putExtra("assist", assist))
            finish(); return
        }
        val trace = try { f.readText() } catch (_: Exception) { "(تعذر قراءة الملف)" }

        val title = TextView(this).apply {
            text = "نيكو وقع في خطأ في المرة اللي فاتت. صوّري الشاشة دي أو انسخي النص وابعتيه عشان أصلحه."
            setTextColor(Color.WHITE); textSize = 15f; setPadding(28, 40, 28, 16)
        }
        val tv = TextView(this).apply {
            text = trace; textSize = 11f; typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#C9D0FF")); setPadding(28, 8, 28, 8); setTextIsSelectable(true)
        }
        val sv = ScrollView(this); sv.addView(tv)
        fun btn(t: String, a: () -> Unit) = Button(this).apply { text = t; setOnClickListener { a() } }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            addView(btn("📋 نسخ") {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("nico-crash", trace))
            })
            addView(btn("📤 مشاركة") {
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, trace), "مشاركة"))
            })
            addView(btn("▶ جرّب تاني") {
                try { f.delete() } catch (_: Exception) {}
                startActivity(Intent(this@LauncherActivity, MainActivity::class.java)); finish()
            })
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#05060F"))
            addView(title)
            addView(sv, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
            addView(row)
        }
        setContentView(root)
    }
}
