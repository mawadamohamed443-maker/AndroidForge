plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.nico.assistant"
    compileSdk = 34
    defaultConfig { applicationId = "com.nico.assistant"; minSdk = 24; targetSdk = 34; versionCode = 44; versionName = "4.3" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { jniLibs { pickFirsts += setOf("**/libc++_shared.so", "**/libjnidispatch.so") } }
    signingConfigs {
        create("nico") { storeFile = file("nico.jks"); storePassword = "nico123456"; keyAlias = "nico"; keyPassword = "nico123456" }
    }
    buildTypes {
        getByName("debug") { signingConfig = signingConfigs.getByName("nico") }
        getByName("release") { isMinifyEnabled = false; signingConfig = signingConfigs.getByName("nico") }
    }
}
dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.mediapipe:tasks-genai:0.10.27")
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
}
