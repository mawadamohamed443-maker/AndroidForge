package com.nico.assistant

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.min
import kotlin.math.sin

/** نيكو: كرة مائية حية بوش (عيون بترمش وبتبص حواليها) ومشاعر بتغيّر اللون والملامح. */
class WaterOrbView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state = State.IDLE
    var lowPower = false
    private var emo = Emotion.NEUTRAL
    private var emoUntil = 0L
    fun feel(e: Emotion, ms: Long = 5000) { emo = e; emoUntil = if (e == Emotion.NEUTRAL) 0L else nowMs() + ms }
    fun pulse(v: Float = 1f) { target = v.coerceIn(0f, 1f) }
    private fun nowMs() = System.nanoTime() / 1_000_000

    private var target = 0f
    private var level = 0f
    private var amp = 0.02f
    private val t0 = System.nanoTime()
    private val rnd = java.util.Random()

    private var cx = 0f; private var cy = 0f; private var r = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path(); private val wave = Path(); private val rect = RectF()
    private var bg: Shader? = null; private var shine: Shader? = null
    private val cur = intArrayOf(0xFF2EE6D6.toInt(), 0xFF1486C8.toInt(), 0xFF0B3D8F.toInt())

    private var nextBlink = 0L; private var blinkStart = 0L
    private var nextLook = 0L; private var tx = 0f; private var ty = 0f; private var lx = 0f; private var ly = 0f

    private fun palette(e: Emotion): IntArray = when (e) {
        Emotion.NEUTRAL -> intArrayOf(0xFF2EE6D6.toInt(), 0xFF1486C8.toInt(), 0xFF0B3D8F.toInt())
        Emotion.HAPPY -> intArrayOf(0xFF7CF5C8.toInt(), 0xFF22B8D8.toInt(), 0xFF1060B0.toInt())
        Emotion.LAUGH -> intArrayOf(0xFFFFE08A.toInt(), 0xFFFFA24D.toInt(), 0xFFE0602B.toInt())
        Emotion.SURPRISED -> intArrayOf(0xFFB8FFFF.toInt(), 0xFF4CC9FF.toInt(), 0xFF2A7BE0.toInt())
        Emotion.SAD -> intArrayOf(0xFF8FB0E0.toInt(), 0xFF4A6FA8.toInt(), 0xFF22365E.toInt())
        Emotion.THINK -> intArrayOf(0xFFC9A8FF.toInt(), 0xFF7A5CE8.toInt(), 0xFF3A2A9A.toInt())
        Emotion.SHY -> intArrayOf(0xFFFFB3D1.toInt(), 0xFFE5589F.toInt(), 0xFF8E2A6B.toInt())
    }
    private fun lerp(a: Int, b: Int, t: Float): Int {
        fun ch(s: Int) = ((a shr s and 255) + ((b shr s and 255) - (a shr s and 255)) * t).toInt().coerceIn(0, 255)
        return (ch(24) shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f; r = min(w, h) / 2f * 0.70f
        clip.reset(); clip.addCircle(cx, cy, r, Path.Direction.CW)
        bg = RadialGradient(cx, cy, r, intArrayOf(0xFF0A2038.toInt(), 0xFF050B18.toInt()), null, Shader.TileMode.CLAMP)
        shine = RadialGradient(cx - r * .35f, cy - r * .45f, r * .75f, intArrayOf(0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
    }

    private fun alpha(c: Int, a: Int) = (c and 0x00FFFFFF) or (a shl 24)

    private fun drawWave(cv: Canvas, level: Float, a: Float, k: Float, phase: Float, sh: Shader) {
        wave.reset(); val left = cx - r; val right = cx + r
        wave.moveTo(left, cy + r)
        var x = left
        while (x <= right + 6f) { wave.lineTo(x, level + a * sin(x * k + phase)); x += 6f }
        wave.lineTo(right, cy + r); wave.close()
        p.reset(); p.isAntiAlias = true; p.shader = sh; cv.drawPath(wave, p)
    }

    private fun drawFace(cv: Canvas, t: Float, e: Emotion) {
        val now = nowMs()
        if (now >= nextBlink) { blinkStart = now; nextBlink = now + 2500 + rnd.nextInt(3500) }
        val bp = ((now - blinkStart) / 160f).coerceIn(0f, 1f)
        val open = if (bp < 1f) abs(1f - 2f * bp) else 1f
        if (now >= nextLook) { tx = (rnd.nextFloat() - .5f) * 2f; ty = (rnd.nextFloat() - .5f) * 1.2f; nextLook = now + 1200 + rnd.nextInt(2800) }
        if (e == Emotion.THINK) { tx = 0.8f; ty = -0.8f }
        lx += (tx - lx) * 0.08f; ly += (ty - ly) * 0.08f

        val ey = cy - r * 0.12f; val ex = r * 0.30f
        var er = r * 0.13f; if (e == Emotion.SURPRISED) er *= 1.35f
        val stroke = r * 0.045f
        for (side in intArrayOf(-1, 1)) {
            val x = cx + side * ex
            when (e) {
                Emotion.HAPPY, Emotion.LAUGH, Emotion.SHY -> {
                    p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = stroke; p.strokeCap = Paint.Cap.ROUND; p.color = Color.WHITE
                    rect.set(x - er, ey - er * 0.7f, x + er, ey + er * 0.9f); cv.drawArc(rect, 200f, 140f, false, p)
                }
                else -> {
                    val h = er * (if (e == Emotion.SAD) 0.75f else 1f) * open
                    p.reset(); p.isAntiAlias = true; p.color = Color.WHITE
                    rect.set(x - er, ey - h, x + er, ey + h); cv.drawOval(rect, p)
                    p.color = 0xFF08202F.toInt()
                    val pr = er * (if (e == Emotion.SURPRISED) 0.35f else 0.55f)
                    cv.drawCircle(x + lx * er * 0.4f, ey + ly * er * 0.35f + (if (e == Emotion.SAD) er * .2f else 0f), pr * open.coerceAtLeast(0.2f), p)
                    if (e == Emotion.SAD) { p.color = alpha(cur[2], 255); p.style = Paint.Style.STROKE; p.strokeWidth = stroke; cv.drawLine(x - side * er * 1.2f, ey - er * 0.9f, x + side * er * 1.2f, ey - er * 1.6f, p) }
                }
            }
        }
        if (e == Emotion.SHY) { p.reset(); p.isAntiAlias = true; p.color = 0x66FF4D8D; cv.drawCircle(cx - ex * 1.35f, ey + er * 2.1f, er * 0.9f, p); cv.drawCircle(cx + ex * 1.35f, ey + er * 2.1f, er * 0.9f, p) }

        // الفم
        val my = cy + r * 0.24f; val mw = r * 0.22f
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = stroke; p.strokeCap = Paint.Cap.ROUND; p.color = Color.WHITE
        if (state == State.SPEAKING) {
            val h = r * (0.03f + 0.09f * abs(sin(t * 11f)))
            p.style = Paint.Style.FILL; p.color = 0xFF08202F.toInt(); rect.set(cx - mw * 0.8f, my - h, cx + mw * 0.8f, my + h); cv.drawOval(rect, p)
            p.style = Paint.Style.STROKE; p.color = Color.WHITE; cv.drawOval(rect, p)
        } else when (e) {
            Emotion.LAUGH -> { rect.set(cx - mw, my - mw * 0.6f, cx + mw, my + mw * 0.9f); p.style = Paint.Style.FILL; p.color = 0xFF08202F.toInt(); cv.drawArc(rect, 0f, 180f, true, p); p.style = Paint.Style.STROKE; p.color = Color.WHITE; cv.drawArc(rect, 0f, 180f, true, p) }
            Emotion.SURPRISED -> cv.drawCircle(cx, my, r * 0.05f, p)
            Emotion.SAD -> { rect.set(cx - mw, my, cx + mw, my + mw); cv.drawArc(rect, 200f, 140f, false, p) }
            Emotion.HAPPY, Emotion.SHY -> { rect.set(cx - mw, my - mw * 0.5f, cx + mw, my + mw * 0.6f); cv.drawArc(rect, 20f, 140f, false, p) }
            else -> { rect.set(cx - mw * 0.6f, my - mw * 0.3f, cx + mw * 0.6f, my + mw * 0.3f); cv.drawArc(rect, 20f, 140f, false, p) }
        }
    }

    override fun onDraw(cv: Canvas) {
        if (r <= 0f) return
        val t = (System.nanoTime() - t0) / 1e9f
        if (emoUntil != 0L && nowMs() > emoUntil) { emo = Emotion.NEUTRAL; emoUntil = 0L }
        val e = emo

        target *= 0.93f; level += (target - level) * 0.18f
        val tgtAmp = when (state) {
            State.IDLE -> 0.035f
            State.LISTENING -> 0.05f + 0.12f * level
            State.THINKING -> 0.07f
            State.SPEAKING -> 0.06f + 0.07f * (0.5f + 0.5f * sin(t * 9f))
        } + (if (e == Emotion.LAUGH) 0.03f * abs(sin(t * 12f)) else 0f)
        amp += (tgtAmp - amp) * 0.08f
        val speed = if (state == State.THINKING) 4.5f else if (state == State.IDLE) 1.4f else 2.6f
        val scale = 1f + when (state) {
            State.IDLE -> 0.015f * sin(t * 1.5f)
            State.LISTENING -> 0.02f + 0.06f * level
            State.THINKING -> 0.02f * sin(t * 3f)
            State.SPEAKING -> 0.03f * sin(t * 8f)
        } + (if (e == Emotion.LAUGH) 0.025f * sin(t * 14f) else 0f)

        val pal = palette(e)
        for (i in 0..2) cur[i] = lerp(cur[i], pal[i], 0.08f)
        val w1 = LinearGradient(0f, cy - r, 0f, cy + r, intArrayOf(alpha(cur[0], 0xCC), alpha(cur[1], 0xDD), alpha(cur[2], 0xEE)), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        val w2 = LinearGradient(0f, cy - r, 0f, cy + r, intArrayOf(alpha(cur[0], 0x88), alpha(cur[1], 0x88), alpha(cur[2], 0x88)), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)

        cv.save(); cv.scale(scale, scale, cx, cy)
        for (i in 7 downTo 1) {
            p.reset(); p.isAntiAlias = true
            p.color = (cur[1] and 0x00FFFFFF); var al = (9 + 3 * (8 - i)).coerceAtMost(40)
            if (state == State.LISTENING) al = (al + 20 * level).toInt().coerceAtMost(90)
            p.alpha = al; cv.drawCircle(cx, cy, r + i * r * 0.05f, p)
        }
        cv.save(); cv.clipPath(clip)
        p.reset(); p.isAntiAlias = true; p.shader = bg; cv.drawCircle(cx, cy, r, p)
        val lvl = cy + r * (0.18f - 0.10f * level); val a = r * amp
        drawWave(cv, lvl + r * .04f, a * 1.2f, 0.021f, -t * speed * 0.8f + 1.7f, w2)
        drawWave(cv, lvl, a, 0.017f, t * speed, w1)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x99BFF6FF.toInt()
        for (i in 0 until 5) {
            val bt = (t * (0.15f + i * 0.04f) + i * 0.37f) % 1f
            val bx = cx + r * 0.55f * sin(i * 2.3f + t * 0.4f); val by = cy + r - bt * r * 1.5f
            if (by > lvl) cv.drawCircle(bx, by, r * (0.02f + 0.012f * i), p)
        }
        cv.restore()

        p.reset(); p.isAntiAlias = true; p.shader = shine; cv.drawCircle(cx, cy, r, p)
        drawFace(cv, t, e)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = r * 0.025f; p.color = alpha(cur[0], 0xCC); cv.drawCircle(cx, cy, r, p)
        if (state == State.THINKING) {
            p.strokeWidth = r * 0.045f; p.strokeCap = Paint.Cap.ROUND; p.color = Color.WHITE
            cv.drawArc(cx - r * 1.1f, cy - r * 1.1f, cx + r * 1.1f, cy + r * 1.1f, t * 220f, 70f, false, p)
        }
        cv.restore()
        if (lowPower && state == State.IDLE && e == Emotion.NEUTRAL) postInvalidateDelayed(110) else postInvalidateOnAnimation()
    }
}
