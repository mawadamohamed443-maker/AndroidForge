package com.nico.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioManager
import android.media.MediaRecorder
import android.media.ToneGenerator
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.telephony.TelephonyManager
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import org.vosk.Recognizer
import java.util.concurrent.Callable
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.math.sqrt

/**
 * استماع دائم في الخلفية بأقل استهلاك للبطارية:
 *  1) VAD بسيط (طاقة الصوت) - لو في صمت مفيش أي معالجة.
 *  2) كاشف كلمة النداء "نيكو" خفيف (موديل English صغير بقاموس محدود).
 *  3) لما يسمع النداء بس: فك الكلام الكامل بكل اللغات المنزلة مع بعض + بصمة الصوت + تنفيذ فوري.
 */
class ListenService : Service() {
    companion object {
        const val CH = "nico_listen"
        const val ACT_STOP = "com.nico.assistant.STOP"
        @Volatile var running = false
        @Volatile var externalPause = false
        fun start(c: Context) { val i = Intent(c, ListenService::class.java); if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i) }
        fun stop(c: Context) { c.stopService(Intent(c, ListenService::class.java)) }
        private val WAKE_EN = setOf("nico", "niko", "neeko", "nicko", "neko", "nikko")
        private val WAKE_AR = setOf("نيكو", "نيكوا", "نيكول", "ميكو", "نكو", "ليكو", "نيكا", "نيكي")
    }

    private val sr = 16000
    private val main = Handler(Looper.getMainLooper())
    private val exec = Executors.newCachedThreadPool()
    private lateinit var prefs: SharedPreferences
    private lateinit var runner: CommandRunner
    private var worker: Thread? = null
    private var tts: TextToSpeech? = null
    @Volatile private var ttsReady = false
    private val latches = ConcurrentHashMap<String, CountDownLatch>()
    @Volatile private var busy = false
    private var overlay: WaterOrbView? = null
    private var tone: ToneGenerator? = null

    // حالة الجملة الحالية
    private var wake: Recognizer? = null
    private val utt = ShortArray(sr * 12)
    private var n = 0
    private var speaking = false
    private val wakeText = StringBuilder()
    private var cmdMode = false
    private var cmdUntil = 0L
    private var wakeCode = "en"

    override fun onBind(i: Intent?): IBinder? = null

    private val callRx = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val st = i.getStringExtra(TelephonyManager.EXTRA_STATE) ?: return
            when (st) {
                TelephonyManager.EXTRA_STATE_RINGING -> {
                    i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER)?.let { Calls.number = it }
                    if (!Calls.ringing) {
                        Calls.ringing = true
                        if (prefs.getBoolean("announce", true)) exec.execute {
                            Thread.sleep(900)
                            val who = Calls.contactName(this@ListenService, Calls.number)
                            speak((who ?: "في مكالمة داخلة") + " بيتصل. قولي أرد أو أعتذر.")
                        }
                    }
                }
                TelephonyManager.EXTRA_STATE_OFFHOOK -> { Calls.ringing = false; Calls.active = true }
                TelephonyManager.EXTRA_STATE_IDLE -> { Calls.ringing = false; Calls.active = false; Calls.number = null }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        Shared.init(this)
        prefs = getSharedPreferences("nico", MODE_PRIVATE)
        runner = CommandRunner(this)
        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                Voices.apply(tts!!, Langs.byCode(Shared.vosk.lang), prefs)
                tts!!.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { latches.remove(id)?.countDown() }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { latches.remove(id)?.countDown() }
                })
                ttsReady = true
            }
        }
        try { tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70) } catch (_: Throwable) {}
        val f = IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(callRx, f, Context.RECEIVER_EXPORTED) else registerReceiver(callRx, f)
    }

    override fun onStartCommand(i: Intent?, flags: Int, id: Int): Int {
        if (i?.action == ACT_STOP) { prefs.edit().putBoolean("always", false).apply(); stopSelf(); return START_NOT_STICKY }
        val nt = notif("سامعك… قولي \"نيكو\" وبعدها أي أمر")
        if (Build.VERSION.SDK_INT >= 30) startForeground(1, nt, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE) else startForeground(1, nt)
        if (!running) {
            running = true
            if (prefs.getBoolean("float", true)) showOverlay()
            worker = Thread { loop() }.also { it.name = "nico-listen"; it.start() }
        }
        return START_STICKY
    }

    private fun notif(text: String): Notification {
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "نيكو سامعك", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 1, Intent(this, ListenService::class.java).setAction(ACT_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val open = PendingIntent.getActivity(this, 2, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH).setContentTitle("نيكو").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).setOngoing(true).setContentIntent(open).addAction(0, "إيقاف", stop).build()
    }
    private fun updateNotif(t: String) { try { getSystemService(NotificationManager::class.java).notify(1, notif(t)) } catch (_: Throwable) {} }

    // ---------- كرة عائمة (اختيارية) ----------
    private fun showOverlay() {
        main.post {
            try {
                if (overlay != null || !Settings.canDrawOverlays(this)) return@post
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                val v = WaterOrbView(this); v.lowPower = true
                val sz = (96 * resources.displayMetrics.density).toInt()
                val lp = WindowManager.LayoutParams(sz, sz,
                    if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
                lp.gravity = Gravity.TOP or Gravity.START; lp.x = 0; lp.y = 400
                var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
                v.setOnTouchListener { _, e ->
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false }
                        MotionEvent.ACTION_MOVE -> { if (Math.abs(e.rawX - sx) > 12 || Math.abs(e.rawY - sy) > 12) moved = true; lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); try { wm.updateViewLayout(v, lp) } catch (_: Throwable) {} }
                        MotionEvent.ACTION_UP -> if (!moved) startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    true
                }
                wm.addView(v, lp); overlay = v
            } catch (_: Throwable) {}
        }
    }
    private fun hideOverlay() { main.post { try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Throwable) {}; overlay = null } }
    private fun orb(s: WaterOrbView.State, e: Emotion = Emotion.NEUTRAL) { main.post { overlay?.state = s; overlay?.feel(e, 4000) } }

    // ---------- الصوت ----------
    private fun speak(t: String) {
        if (!ttsReady) return
        val e = Mood.fromText(t); orb(WaterOrbView.State.SPEAKING, e)
        Voices.prosody(tts!!, e, prefs)
        val l = CountDownLatch(1); val id = "n${System.nanoTime()}"
        latches[id] = l
        tts!!.speak(t.take(1000), TextToSpeech.QUEUE_FLUSH, null, id)
        l.await(20, TimeUnit.SECONDS); latches.remove(id)
        Thread.sleep(350); orb(WaterOrbView.State.IDLE)
    }

    private fun speakCall(msg: String) {
        val t = tts ?: return
        try { t.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()) } catch (_: Throwable) {}
        speak(msg)
        try { t.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()) } catch (_: Throwable) {}
    }

    private fun fail(msg: String) { updateNotif(msg); running = false; stopSelf() }

    private fun batteryLow(): Boolean {
        if (!prefs.getBoolean("lowbat", true)) return false
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val lvl = i.getIntExtra("level", 100) * 100 / i.getIntExtra("scale", 100).coerceAtLeast(1)
        return lvl < 15 && i.getIntExtra("plugged", 0) == 0
    }

    private fun txt(j: String): String = try { JSONObject(j).optString("text") } catch (_: Exception) { "" }

    private fun loop() {
        val minBuf = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec: AudioRecord = try {
            AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, 16000))
        } catch (e: Throwable) { fail("مفيش إذن المايك"); return }
        if (rec.state != AudioRecord.STATE_INITIALIZED) { fail("المايك مش متاح"); return }

        val vk = Shared.vosk
        val useEn = vk.installed("en")
        wakeCode = if (useEn) "en" else if (vk.installed("ar")) "ar" else { fail("نزّلي English من اللغات لكلمة النداء"); return }
        val dir = vk.modelDir(wakeCode) ?: run { fail("موديل كلمة النداء مش موجود"); return }
        try {
            val m = VoskModels.get(wakeCode, dir)
            wake = if (useEn) Recognizer(m, sr.toFloat(), "[\"nico\",\"niko\",\"neeko\",\"nicko\",\"neko\",\"nikko\",\"[unk]\"]") else Recognizer(m, sr.toFloat())
        } catch (e: Throwable) { fail("فشل تحميل موديل النداء"); return }

        val buf = ShortArray(1600)
        var recording = false; var noise = 200.0; var lastLoud = 0L; var lastBat = 0L; var batLow = false
        while (running) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastBat > 30000) { lastBat = now; val b = batteryLow(); if (b != batLow) { batLow = b; updateNotif(if (b) "متوقف مؤقتاً: البطارية أقل من 15%" else "سامعك… قولي \"نيكو\"") } }
            if (externalPause || batLow) {
                if (recording) { try { rec.stop() } catch (_: Throwable) {}; recording = false; n = 0; speaking = false }
                Thread.sleep(500); continue
            }
            if (!recording) { try { rec.startRecording(); recording = true } catch (_: Throwable) { Thread.sleep(500); continue } }
            val k = rec.read(buf, 0, buf.size)
            if (k <= 0) { Thread.sleep(20); continue }
            if (busy) { n = 0; speaking = false; continue }

            var sum = 0.0; for (i in 0 until k) sum += buf[i].toDouble() * buf[i]
            val rms = sqrt(sum / k)
            val loud = rms > maxOf(450.0, noise * 2.8)
            if (!speaking && !loud) noise = noise * 0.98 + rms * 0.02
            if (loud) lastLoud = now
            val active = loud || (speaking && now - lastLoud < 800)
            if (active) {
                if (!speaking) { speaking = true; n = 0; wakeText.setLength(0); wake?.reset(); if (cmdMode && now >= cmdUntil) cmdMode = false }
                if (n + k <= utt.size) { System.arraycopy(buf, 0, utt, n, k); n += k }
                if (!cmdMode) { try { if (wake!!.acceptWaveForm(buf, k)) wakeText.append(' ').append(txt(wake!!.result)) } catch (_: Throwable) {} }
                if (n >= utt.size - 1600) endUtterance()
            } else if (speaking) endUtterance()
        }
        try { rec.stop() } catch (_: Throwable) {}
        rec.release(); try { wake?.close() } catch (_: Throwable) {}
    }

    private fun isWakeTok(tok: String): Boolean {
        val t = Skills.norm(tok).trim()
        if (t.length < 3) return false
        return t in WAKE_EN || t in WAKE_AR || Mix.lev(t, "nico") <= 1 || Mix.lev(t, "نيكو") <= 1
    }
    private fun isWake(text: String) = text.lowercase().replace("[unk]", " ").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.take(2).any { isWakeTok(it) }
    private fun stripWake(t: String): String {
        val ts = t.trim().split(Regex("\\s+")).toMutableList()
        if (ts.isNotEmpty() && ts[0].lowercase() in setOf("يا", "ي", "hey", "hi", "ok", "okay", "ya", "ehi", "ciao")) ts.removeAt(0)
        if (ts.isNotEmpty() && isWakeTok(ts[0])) ts.removeAt(0)
        return ts.joinToString(" ")
    }

    private fun endUtterance() {
        speaking = false
        if (n < sr / 3) { n = 0; return }
        val pcm = utt.copyOf(n); n = 0
        if (cmdMode && SystemClock.elapsedRealtime() < cmdUntil) { cmdMode = false; dispatch(pcm, false); return }
        cmdMode = false
        try { wakeText.append(' ').append(txt(wake!!.finalResult)); wake!!.reset() } catch (_: Throwable) {}
        val heard = isWake(wakeText.toString()); wakeText.setLength(0)
        if (heard) dispatch(pcm, true)
    }

    private fun dispatch(pcm: ShortArray, strip: Boolean) {
        busy = true
        exec.execute { try { process(pcm, strip) } catch (_: Throwable) {} finally { busy = false } }
    }

    private class Cand(val text: String, val conf: Double)

    private fun decodeOne(code: String, pcm: ShortArray): Cand? {
        val dir = Shared.vosk.modelDir(code) ?: return null
        var r: Recognizer? = null
        return try {
            r = Recognizer(VoskModels.get(code, dir), sr.toFloat()); r.setWords(true)
            r.acceptWaveForm(pcm, pcm.size)
            val j = JSONObject(r.finalResult); val text = j.optString("text")
            val a = j.optJSONArray("result"); var c = 0.0
            if (a != null && a.length() > 0) { for (i in 0 until a.length()) c += a.getJSONObject(i).optDouble("conf", 0.0); c /= a.length() }
            Cand(text, c)
        } catch (_: Throwable) { null } finally { try { r?.close() } catch (_: Throwable) {} }
    }

    private fun process(pcm: ShortArray, strip: Boolean) {
        orb(WaterOrbView.State.THINKING, Emotion.THINK)
        val codes = Shared.vosk.installedLangs().map { it.code }
        val futs = codes.map { c -> exec.submit(Callable { decodeOne(c, pcm) }) }
        val cands = futs.mapNotNull { try { it.get(30, TimeUnit.SECONDS) } catch (_: Throwable) { null } }
            .filter { it.text.isNotBlank() }.sortedByDescending { it.conf }

        // بصمة الصوت
        val people = Shared.people
        var speaker: Person? = null
        if (people.list.any { it.voice != null } && Voiceprint.ready()) speaker = Voiceprint.identify(Voiceprint.embed(pcm, pcm.size), people.list)
        if (prefs.getBoolean("ownerOnly", false)) {
            val o = people.owner()
            if (o?.voice != null && speaker?.id != o.id) { speak("الصوت ده مش صوتك، مش هنفذ."); return }
        }

        val texts = cands.map { if (strip) stripWake(it.text) else it.text }.filter { it.isNotBlank() }
        if (texts.isEmpty()) {
            if (strip) {
                try { tone?.startTone(ToneGenerator.TONE_PROP_BEEP, 120) } catch (_: Throwable) {}
                orb(WaterOrbView.State.LISTENING, Emotion.SURPRISED)
                speak(speaker?.name?.let { "أيوه يا $it؟" } ?: "أيوه؟")
                cmdMode = true; cmdUntil = SystemClock.elapsedRealtime() + 8000
            }
            return
        }
        runner.handle(texts, speaker, { speak(it) }, { speakCall(it) })
        if (prefs.getBoolean("ramsave", false)) main.postDelayed({ if (!busy) VoskModels.dropExcept(wakeCode) }, 90000)
    }

    override fun onDestroy() {
        running = false; hideOverlay()
        try { unregisterReceiver(callRx) } catch (_: Throwable) {}
        try { worker?.join(1500) } catch (_: Throwable) {}
        tts?.shutdown(); try { tone?.release() } catch (_: Throwable) {}
        exec.shutdownNow()
        super.onDestroy()
    }
}
