package com.nico.assistant

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.telecom.TelecomManager
import android.telephony.SmsManager

/**
 * التعامل مع المكالمات الداخلة بالصوت.
 * "افتح المكالمة" = رد. "افتح المكالمة وقولهم X" = رد وشغّل X على السماعة (الطرف التاني بيسمعها من المايك) وبعدين يقفل.
 * "ارفض وابعتلهم X" = رفض + SMS. لو X فاضي بيتاخد الرد الافتراضي من الإعدادات.
 */
object Calls {
    @Volatile var ringing = false
    @Volatile var active = false
    @Volatile var number: String? = null
    const val DEFAULT_REPLY = "بنتك بتقولك مش فاضية دلوقتي وهتكلمك بعدين"

    private fun has(ctx: Context, p: String) = ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun tm(ctx: Context) = ctx.getSystemService(Context.TELECOM_SERVICE) as TelecomManager

    fun contactName(ctx: Context, num: String?): String? {
        if (num.isNullOrBlank() || !has(ctx, android.Manifest.permission.READ_CONTACTS)) return null
        try {
            ctx.contentResolver.query(Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI, Uri.encode(num)),
                arrayOf(ContactsContract.PhoneLookup.DISPLAY_NAME), null, null, null)?.use { if (it.moveToFirst()) return it.getString(0) }
        } catch (_: Exception) {}
        return null
    }

    private fun answer(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 26 || !has(ctx, android.Manifest.permission.ANSWER_PHONE_CALLS)) return false
        return try { tm(ctx).acceptRingingCall(); true } catch (_: Exception) { false }
    }
    private fun end(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT < 28 || !has(ctx, android.Manifest.permission.ANSWER_PHONE_CALLS)) return false
        return try { tm(ctx).endCall() } catch (_: Exception) { false }
    }

    private fun sms(ctx: Context, num: String?, msg: String): Boolean {
        if (num.isNullOrBlank() || !has(ctx, android.Manifest.permission.SEND_SMS)) return false
        return try {
            val s = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java) else @Suppress("DEPRECATION") SmsManager.getDefault()
            s.sendMultipartTextMessage(num, null, s.divideMessage(msg), null, null); true
        } catch (_: Exception) { false }
    }

    private val sayWord = "(?:قولهم|قوللهم|قوليلهم|قول لهم|قولي لهم|قولها|قوله|قولوا)"
    private val rxSay = Regex("(?:افتح|رد|ارد|جاوب|اجاوب|اقبل)\\s*(?:علي|على)?\\s*(?:المكالمه|الاتصال|الخط|التليفون|الفون)?\\s*(?:و|ثم|وبعدين)?\\s*$sayWord")
    private val rxSms = Regex("(?:ابعتلهم|ابعت لهم|ابعتله|ابعتلها|ابعت رساله|رد برساله|بعتلهم)")
    private val rxAnswer = Regex("^(?:افتح|رد|ارد|جاوب|اجاوب|اقبل|رد علي|رد على)\\s*(?:علي|على)?\\s*(?:المكالمه|الاتصال|الخط|التليفون|الفون)?$")
    private val rxReject = Regex("^(?:ارفض|سكر|اقفل|انهي)\\s*(?:المكالمه|الاتصال|الخط|التليفون)?$|ارفض المكالمه")
    private val rxEnd = Regex("(?:اقفل|انهي|سكر)\\s*(?:المكالمه|الخط)")

    private fun msgFrom(raw: String, prefs: SharedPreferences, words: String): String {
        val m = Regex("(?:$words)\\s*(.*)$").find(raw)?.groupValues?.get(1)?.trim().orEmpty()
        return m.ifBlank { prefs.getString("call_reply", DEFAULT_REPLY) ?: DEFAULT_REPLY }
    }

    /** بيرجع رد نصي لو الأمر كان عن مكالمة، وإلا null. speakCall بينطق الرسالة على السماعة. */
    fun handle(ctx: Context, raw: String, prefs: SharedPreferences, speakCall: (String) -> Unit): String? {
        if (!ringing && !active) return null
        val q = Skills.norm(raw)
        if (ringing && rxSay.containsMatchIn(q)) {
            val msg = msgFrom(raw, prefs, sayWord.removePrefix("(?:").removeSuffix(")"))
            if (!answer(ctx)) return "محتاج إذن \"الرد على المكالمات\" من الأذونات."
            for (i in 0 until 25) { if (active) break; Thread.sleep(200) }
            try { (ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager).isSpeakerphoneOn = true } catch (_: Exception) {}
            speakCall(msg); Thread.sleep(400)
            if (prefs.getBoolean("hangup", true)) end(ctx)
            return "رديت وقلتلهم الرسالة."
        }
        if (ringing && rxSms.containsMatchIn(q)) {
            val msg = msgFrom(raw, prefs, "ابعتلهم|ابعت لهم|ابعتله|ابعتلها|ابعت رساله|رد برساله|بعتلهم")
            val num = number
            end(ctx)
            return if (sms(ctx, num, msg)) "رفضت المكالمة وبعتلهم الرسالة." else "رفضت المكالمة، بس معرفتش أبعت الرسالة (إذن الرسائل أو الرقم مش متاح)."
        }
        if (ringing && rxAnswer.containsMatchIn(q)) return if (answer(ctx)) "رديت." else "محتاج إذن \"الرد على المكالمات\" من الأذونات."
        if (ringing && rxReject.containsMatchIn(q)) return if (end(ctx)) "رفضت المكالمة." else "معرفتش أرفضها."
        if (active && rxEnd.containsMatchIn(q)) return if (end(ctx)) "قفلت المكالمة." else "معرفتش أقفلها."
        return null
    }
}
