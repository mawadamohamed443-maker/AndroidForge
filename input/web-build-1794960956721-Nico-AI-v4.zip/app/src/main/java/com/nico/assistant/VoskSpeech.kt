package com.nico.assistant

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** كاش موديلات Vosk مشترك (التطبيق + خدمة الخلفية) عشان ما نحمّلش نفس الموديل مرتين. */
object VoskModels {
    private val m = HashMap<String, Model>()
    @Synchronized fun get(code: String, dir: File): Model = m.getOrPut(code) { Model(dir.absolutePath) }
    @Synchronized fun drop(code: String) { m.remove(code)?.let { try { it.close() } catch (_: Throwable) {} } }
    @Synchronized fun dropExcept(keep: String) {
        val it = m.entries.iterator()
        while (it.hasNext()) { val e = it.next(); if (e.key != keep) { try { e.value.close() } catch (_: Throwable) {}; it.remove() } }
    }
}

/** تعرف صوتي أوفلاين متعدد اللغات: كل لغة بتتنزل مرة واحدة (نت أول مرة بس) وبعدها بتشتغل من غير نت. */
class VoskSpeech(private val ctx: Context) {
    private var model: Model? = null
    private var svc: SpeechService? = null
    private val prefs = ctx.getSharedPreferences("nico", Context.MODE_PRIVATE)
    var listening = false; private set

    var lang: String
        get() = prefs.getString("lang", "ar") ?: "ar"
        set(v) { prefs.edit().putString("lang", v).apply() }

    fun dirFor(code: String) = File(ctx.filesDir, "vosk/$code")
    private fun valid(d: File) = File(d, "am").isDirectory && File(d, "conf").isDirectory
    private fun hasAsset(): Boolean = try { ctx.assets.list("model-ar")?.isNotEmpty() == true } catch (_: Exception) { false }
    fun installed(code: String) = valid(dirFor(code)) || (code == "ar" && hasAsset())
    fun available() = installed(lang)
    fun installedLangs(): List<Lang> = Langs.all.filter { installed(it.code) }

    private fun copyAsset(path: String, out: File) {
        val kids = ctx.assets.list(path) ?: emptyArray()
        if (kids.isEmpty()) {
            out.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> out.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
        } else kids.forEach { copyAsset("$path/$it", File(out, it)) }
    }

    /** فولدر الموديل الجاهز (بينسخ العربي من assets لو لزم) أو null. */
    @Synchronized
    fun modelDir(code: String): File? {
        val d = dirFor(code)
        if (!valid(d)) {
            if (code == "ar" && hasAsset()) { d.deleteRecursively(); copyAsset("model-ar", d) }
            if (!valid(d)) return null
        }
        return d
    }

    @Synchronized
    fun load(): String? = try {
        val d = modelDir(lang) ?: return "اللغة دي مش منزلة. نزّليها من زر اللغات."
        model = VoskModels.get(lang, d); null
    } catch (e: Throwable) { model = null; "فشل تحميل موديل الصوت: ${e.message}" }

    private class Counting(i: InputStream, val onBytes: (Long) -> Unit) : FilterInputStream(i) {
        var n = 0L
        override fun read(): Int { val r = super.read(); if (r >= 0) { n++; onBytes(n) }; return r }
        override fun read(b: ByteArray, off: Int, len: Int): Int { val r = super.read(b, off, len); if (r > 0) { n += r; onBytes(n) }; return r }
    }

    /** بيفك zip لفولدر الكود (لغة أو "spk"). check بيحدد الفولدر الصحيح جوه الـ zip. */
    fun installStream(code: String, input: InputStream, progress: (String) -> Unit, check: ((File) -> Boolean)? = null): String? {
        val ok: (File) -> Boolean = check ?: { valid(it) }
        VoskModels.drop(code); if (code == lang) { stop(); model = null }
        val tmp = File(ctx.filesDir, "vosk-tmp-$code")
        return try {
            tmp.deleteRecursively(); tmp.mkdirs()
            val root = tmp.canonicalPath + File.separator
            var n = 0
            ZipInputStream(input.buffered()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val f = File(tmp, e.name)
                    if (!f.canonicalPath.startsWith(root)) continue // حماية zip-slip
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { o -> z.copyTo(o, 1 shl 20) }
                        if (++n % 15 == 0) progress("بفك الموديل… $n ملف")
                    }
                }
            }
            val src = tmp.walkTopDown().firstOrNull { it.isDirectory && ok(it) } ?: return "الملف ده مش موديل صحيح."
            val dst = dirFor(code); dst.deleteRecursively(); dst.parentFile?.mkdirs()
            if (!src.renameTo(dst)) src.copyRecursively(dst, true)
            null
        } catch (e: Throwable) { "فشل التثبيت: ${e.message}" }
        finally { tmp.deleteRecursively() }
    }

    fun downloadUrl(code: String, url: String, mb: Int, label: String, progress: (String) -> Unit, check: ((File) -> Boolean)? = null): String? {
        var c: HttpURLConnection? = null
        return try {
            c = (URL(url).openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true }
            if (c.responseCode != 200) return "السيرفر رد بكود ${c.responseCode}. جربي بعدين."
            val total = c.contentLengthLong.takeIf { it > 0 } ?: (mb * 1_000_000L)
            var last = 0L
            val cin = Counting(c.inputStream) { n ->
                val now = System.currentTimeMillis()
                if (now - last > 400) { last = now; progress("بنزّل $label… ${(n * 100 / total).coerceAtMost(99)}%") }
            }
            installStream(code, cin, progress, check)
        } catch (e: java.io.IOException) { "مفيش اتصال بالنت أو الاتصال اتقطع. التنزيل بيحتاج نت أول مرة بس." }
        catch (e: Throwable) { "فشل التنزيل: ${e.message}" }
        finally { c?.disconnect() }
    }

    fun download(l: Lang, progress: (String) -> Unit) = downloadUrl(l.code, Langs.url(l), l.mb, l.label, progress)
    fun downloadSpk(progress: (String) -> Unit) =
        downloadUrl("spk", Langs.spkUrl(), Langs.SPK_MB, "موديل بصمة الصوت", progress) { File(it, "final.ext.raw").exists() }

    fun delete(code: String) { VoskModels.drop(code); if (code == lang) { stop(); model = null }; dirFor(code).deleteRecursively() }

    fun start(onPartial: (String) -> Unit, onFinal: (String) -> Unit, onError: (String) -> Unit) {
        val m = model ?: return onError("الموديل مش محمّل.")
        try {
            stop()
            svc = SpeechService(Recognizer(m, 16000f), 16000f)
            listening = true
            svc!!.startListening(object : org.vosk.android.RecognitionListener {
                override fun onPartialResult(h: String?) {
                    val t = try { JSONObject(h ?: "{}").optString("partial") } catch (_: Exception) { "" }
                    if (t.isNotBlank()) onPartial(t)
                }
                override fun onResult(h: String?) {
                    val t = try { JSONObject(h ?: "{}").optString("text") } catch (_: Exception) { "" }
                    if (t.isNotBlank()) { stop(); onFinal(t) }
                }
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) { stop(); onError(e?.message ?: "خطأ في الميكروفون") }
                override fun onTimeout() { stop(); onFinal("") }
            }, 12000)
        } catch (e: Throwable) { listening = false; onError(e.message ?: "تعذر تشغيل الميكروفون") }
    }

    fun stop() { listening = false; try { svc?.stop(); svc?.shutdown() } catch (_: Throwable) {}; svc = null }
    fun release() { stop(); model = null }
}
