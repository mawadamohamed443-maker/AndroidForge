package com.nico.assistant

import android.content.Context
import kotlin.random.Random

/** تنفيذ أوامر الصوت في الخلفية (من غير واجهة): مكالمات ← ذاكرة ← أوامر متعددة ← واتساب/تطبيقات ← مخ نيكو ← وكيل ← ذكاء. */
class CommandRunner(private val ctx: Context) {
    private val prefs = ctx.getSharedPreferences("nico", Context.MODE_PRIVATE)
    private val failRx = Regex("^(?:ملقتش|مقدرتش|معرفتش|محتاج|فشل|مفيش|تعذر|حصل خطأ)")
    private fun brain() = NicoBrain(NicoAccessibilityService.inst ?: ctx)
    private fun tryBrain(b: NicoBrain, t: String): String? = try { b.handle(t) } catch (_: Exception) { null }
    private fun agentReady() = prefs.getBoolean("agent", true) && NicoAccessibilityService.inst != null && Shared.llm.installed

    private fun ack(t: String, r: String, speaker: Person?): String {
        if (!prefs.getBoolean("ack", true) || !Skills.isCommand(t)) return Persona.flavor(r)
        val who = speaker?.name?.let { " يا $it" } ?: ""
        return Persona.flavor(listOf("عملته$who", "تمام$who، عملته", "خلصت$who", "اتعمل$who").random(Random(System.nanoTime())))
    }

    private fun runAgent(b: NicoBrain, goal: String): String =
        Shared.agent.run(goal, prefs.getBoolean("sens", false),
            screen = { Actions.onMain { NicoAccessibilityService.inst?.readScreen(1200) } ?: "" },
            pkg = { Actions.onMain { NicoAccessibilityService.inst?.currentPackage() } ?: "" },
            exec = { a, v -> Actions.exec(b, a, v) },
            log = { s -> Shared.store.addLine("نيكو: $s") })

    fun handle(texts: List<String>, speaker: Person?, say: (String) -> Unit, speakCall: (String) -> Unit) {
        val store = Shared.store
        val first = texts.first()
        store.addLine("أنتِ: 🎙 $first")
        fun emit(r: String) { store.addLine("نيكو: $r"); say(r) }

        Persona.onUser(first)?.let { emit(it); return }
        for (t in texts) Calls.handle(ctx, t, prefs, speakCall)?.let { emit(it); return }
        for (t in texts) Skills.handle(t, store, ctx)?.let { Shared.llm.memory = store.memoryText(); emit(it); return }

        val b = brain()
        for (t in texts) {
            val steps = Skills.split(t)
            if (steps.size > 1) { plan(b, steps, speaker) { emit(it) }; return }
            val r = Mix.whatsapp(ctx, t, speaker) ?: Mix.tryOpen(ctx, t) ?: tryBrain(b, t)
            if (r != null && !failRx.containsMatchIn(r)) { emit(if (r.isEmpty()) "عملته" else ack(t, r, speaker)); return }
        }
        if (Skills.isCommand(first) && agentReady()) { emit(runAgent(b, first)); return }
        if (Shared.llm.installed) { Shared.llm.memory = store.memoryText(); Shared.llm.persona = Persona.hint(); emit(Shared.llm.ask(first)); return }
        emit("معرفتش قصدك. ثبّتي موديل الذكاء من التطبيق عشان أجاوب على أي سؤال.")
    }

    private fun plan(b: NicoBrain, steps: List<String>, speaker: Person?, emit: (String) -> Unit) {
        for (s in steps) {
            val r = Mix.whatsapp(ctx, s, speaker) ?: Mix.tryOpen(ctx, s) ?: tryBrain(b, s)
            if (r == null || failRx.containsMatchIn(r)) {
                if (agentReady()) runAgent(b, s).let { Shared.store.addLine("نيكو: $it") } else { emit("معرفتش أنفذ: $s"); return }
            }
            Thread.sleep(2500)
        }
        emit(ack(steps.first(), "خلصت كل الخطوات", speaker))
    }
}
