package com.nico.assistant

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var brain: NicoBrain
    private val llm get() = Shared.llm
    private val vosk get() = Shared.vosk
    private val store get() = Shared.store
    private val agent get() = Shared.agent
    private val people get() = Shared.people
    private var pendingPerson: Person? = null
    private lateinit var orb: WaterOrbView
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private val prefs by lazy { getSharedPreferences("nico", MODE_PRIVATE) }
    private val h = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS,
        Manifest.permission.ANSWER_PHONE_CALLS, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG,
        Manifest.permission.SEND_SMS, "android.permission.POST_NOTIFICATIONS")
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> val p = pendingPerson; if (uri != null && p != null) savePhoto(p, uri) }

    private val pickLlm = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) installLlm(uri) }
    private val pickVosk = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) importArabic(uri) }

    private val curLang get() = Langs.byCode(vosk.lang)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        Shared.init(this); brain = NicoBrain(this)
        orb = findViewById(R.id.orb); log = findViewById(R.id.log); status = findViewById(R.id.status)
        scroll = findViewById(R.id.scroll); input = findViewById(R.id.input)

        // سجل المحادثة المحفوظ + إكمال الذكاء من حيث وقف
        store.lines.takeLast(40).forEach { log.append(it + "\n\n") }
        llm.seed(store.pairs()); llm.memory = store.memoryText()
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }

        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                applyTts()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.SPEAKING } }
                    override fun onDone(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.IDLE } }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.IDLE } }
                })
            }
        }
        requestPermissions(perms, 1)

        fun btn(id: Int, f: () -> Unit) = findViewById<Button>(id).setOnClickListener { f() }
        btn(R.id.btnPerm) { requestPermissions(perms, 1) }
        btn(R.id.btnAcc) { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        btn(R.id.btnLlm) { llmMenu() }
        btn(R.id.btnVoice) { voiceMenu() }
        btn(R.id.btnLang) { langMenu() }
        btn(R.id.btnMem) { memoryMenu() }
        btn(R.id.btnSet) { settingsMenu() }
        btn(R.id.btnPeople) { peopleMenu() }
        btn(R.id.btnListen) { setAlwaysOn(!prefs.getBoolean("always", false)) }
        btn(R.id.btnClear) { confirm("مسح المحادثة كلها؟") { clearChat() } }
        btn(R.id.btnMic) { listen() }
        btn(R.id.btnSend) { send() }
        orb.setOnClickListener { listen() }
        input.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        if (prefs.getBoolean("always", false) && hasMic()) ListenService.start(this)
        if (store.lines.isEmpty()) add("نيكو: أهلا! اضغطي على الكرة واتكلمي، أو اكتبي أمر.")
    }

    override fun onResume() {
        super.onResume()
        log.text = ""; store.lines.takeLast(40).forEach { log.append(it + "\n\n") }
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        findViewById<Button>(R.id.btnListen).text = if (prefs.getBoolean("always", false)) "👂 الاستماع: شغّال" else "👂 استماع دائم"
    }
    override fun onPause() { super.onPause(); ListenService.externalPause = false }

    // ---------- أدوات عامة ----------
    private fun add(t: String) { store.addLine(t); log.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }
    private fun say(t: String) {
        if (!prefs.getBoolean("speak", true)) return
        val e = Persona.emotionFor(t); orb.feel(e); tts?.let { Voices.prosody(it, e, prefs) }
        orb.state = WaterOrbView.State.SPEAKING; tts?.speak(t.take(1500), TextToSpeech.QUEUE_FLUSH, null, "nico")
    }
    private fun reply(t: String) { add("نيكو: $t"); say(t) }
    private fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("أيوه") { _, _ -> ok() }.setNegativeButton("لا", null).show()
    }
    private fun open(action: String) {
        try { startActivity(Intent(action)) } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }
    private fun <T> onMain(f: () -> T): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return f()
        var r: T? = null; val l = CountDownLatch(1)
        runOnUiThread { try { r = f() } catch (_: Throwable) {}; l.countDown() }
        l.await(6, TimeUnit.SECONDS); return r
    }
    private fun clearChat() { store.clearHistory(); llm.clearHistory(); log.text = ""; add("نيكو: مسحت المحادثة.") }

    private fun applyTts() {
        val l = curLang
        tts?.let { Voices.apply(it, l, prefs); Voices.prosody(it, Emotion.NEUTRAL, prefs) }
        val r = tts?.isLanguageAvailable(Locale.forLanguageTag(l.tag)) ?: TextToSpeech.LANG_NOT_SUPPORTED
        if (r < 0 && l.code != "ar") add("نيكو: صوت النطق للغة ${l.label} مش منزل. افتحي اللغات ← بيانات النطق.")
    }

    // ---------- المعالجة: ذاكرة ← أوامر متعددة ← أمر واحد ← وكيل ← ذكاء ----------
    private fun send() { val t = input.text.toString().trim(); if (t.isNotEmpty()) { input.setText(""); process(t) } }

    private fun process(t: String) {
        ListenService.externalPause = false
        add("أنتِ: $t")
        Persona.onUser(t)?.let { orb.feel(Persona.mood, 8000); reply(it); return }
        if (Regex("نكته|نكت").containsMatchIn(Skills.norm(t))) orb.feel(Emotion.LAUGH) else if (Regex("شكرا|بحبك").containsMatchIn(Skills.norm(t))) orb.feel(Emotion.SHY)
        Skills.handle(t, store, this)?.let { llm.memory = store.memoryText(); reply(it); return }
        val steps = Skills.split(t)
        if (steps.size > 1) { add("نيكو: فهمت ${steps.size} خطوات، هنفذهم واحدة واحدة."); runPlan(steps, 0); return }
        runSingle(t) {}
    }

    private fun tryBrain(t0: String): String? {
        val t = Mix.normalize(t0)
        Mix.whatsapp(this, t, null)?.let { return it }
        Mix.tryOpen(this, t)?.let { return it }
        return try { brain.handle(t) } catch (e: Exception) { "حصل خطأ وأنا بنفذ الأمر: ${e.javaClass.simpleName}" }
    }
    private fun agentReady() = prefs.getBoolean("agent", true) && NicoAccessibilityService.inst != null && llm.installed

    private fun runSingle(t: String, done: () -> Unit) {
        val r = tryBrain(t)
        if (r != null) { if (r.isNotEmpty()) reply(Persona.flavor(r)); done(); return }
        if (Skills.isCommand(t)) {
            if (agentReady()) { runAgent(t, done); return }
            if (NicoAccessibilityService.inst == null && llm.installed) add("نيكو: عشان أنفذ أوامر زي دي لازم تفعلي \"التحكم الكامل\".")
        }
        askLlm(t, done)
    }

    private fun askLlm(t: String, done: () -> Unit) {
        if (!llm.installed) { reply("معرفتش قصدك. علشان أجاوب على أي سؤال أوفلاين، ثبتي موديل الذكاء من زر \"الذكاء\"."); done(); return }
        status.text = "بفكر..."; orb.state = WaterOrbView.State.THINKING
        llm.memory = store.memoryText(); llm.persona = Persona.hint()
        thread {
            val a = llm.ask(t)
            runOnUiThread { if (!isFinishing) { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; reply(a); done() } }
        }
    }

    private fun runPlan(steps: List<String>, i: Int) {
        if (i >= steps.size) { reply("خلصت كل الخطوات."); return }
        val next = { h.postDelayed({ runPlan(steps, i + 1) }, 2500) }
        val s = steps[i]
        add("نيكو: [${i + 1}/${steps.size}] $s")
        val r = tryBrain(s)
        if (r != null) { if (r.isNotEmpty()) add("نيكو: $r"); next(); return }
        if (agentReady()) runAgent(s) { next() } else { add("نيكو: معرفتش أنفذ الخطوة دي."); next() }
    }

    private fun execAction(a: String, v: String): String = onMain {
        val acc = NicoAccessibilityService.inst
        when (a) {
            "open" -> brain.handle("افتح $v")?.ifBlank { null } ?: "فتحت $v"
            "click" -> if (acc?.clickText(v) == true) "ضغطت على \"$v\"" else "ملقيتش \"$v\" على الشاشة"
            "type" -> if (acc?.typeText(v) == true) "كتبت \"$v\"" else "ملقيتش خانة كتابة"
            "scroll" -> if (acc?.scroll(v != "up") == true) "سكرولت" else "معرفتش أسكرول"
            "back" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_BACK); "رجعت" }
            "home" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_HOME); "روحت للرئيسية" }
            else -> "أمر غير معروف: $a"
        }
    } ?: "التنفيذ اتأخر"

    private fun runAgent(goal: String, done: () -> Unit) {
        status.text = "بنفذ..."; orb.state = WaterOrbView.State.THINKING
        llm.memory = store.memoryText()
        thread {
            val res = agent.run(goal, prefs.getBoolean("sens", false),
                screen = { onMain { NicoAccessibilityService.inst?.readScreen(1200) } ?: "" },
                pkg = { onMain { NicoAccessibilityService.inst?.currentPackage() } ?: "" },
                exec = { a, v -> execAction(a, v) },
                log = { s -> runOnUiThread { add("نيكو: $s") } })
            runOnUiThread { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; reply(res); done() }
        }
    }

    // ---------- الصوت ----------
    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun listenVosk() {
        if (vosk.listening) { vosk.stop(); orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"; return }
        tts?.stop(); orb.state = WaterOrbView.State.LISTENING; status.text = "بجهّز الاستماع..."
        thread {
            val err = vosk.load()
            runOnUiThread {
                if (err != null) { orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"; add("نيكو: $err"); return@runOnUiThread }
                status.text = "بسمعك..."
                vosk.start(
                    onPartial = { t -> runOnUiThread { orb.pulse(0.8f); status.text = t } },
                    onFinal = { t -> runOnUiThread { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; if (t.isNotBlank()) process(t) } },
                    onError = { m -> runOnUiThread { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; add("نيكو: $m") } }
                )
            }
        }
    }

    private fun listen() {
        if (ListenService.running) { ListenService.externalPause = true; h.postDelayed({ ListenService.externalPause = false }, 15000) }
        if (!hasMic()) { requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1); add("نيكو: اسمحي بإذن المايك الأول وبعدين اضغطي تاني."); return }
        if (vosk.available()) { listenVosk(); return }
        // احتياطي: التعرف المدمج في جوجل (للعربي لو موديل نيكو المدمج مش مثبت)
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { add("نيكو: نزّلي لغة من زر اللغات 🌐 عشان أسمعك أوفلاين."); return }
        tts?.stop(); sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "بسمعك..."; orb.state = WaterOrbView.State.LISTENING }
                override fun onRmsChanged(v: Float) { orb.pulse((v / 10f).coerceIn(0f, 1f)) }
                override fun onResults(r: Bundle?) {
                    status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
                }
                override fun onError(e: Int) {
                    status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                    if (e == 12 || e == 13) add("نيكو: اللغة مش منزلة أوفلاين. نزّليها من زر اللغات 🌐 (مرة واحدة).")
                    else add("نيكو: معرفتش أسمعك (كود $e)، جربي تاني.")
                }
                override fun onBeginningOfSpeech() {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, curLang.tag)
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true))
        }
    }

    // ---------- اللغات ----------
    private fun langMenu() {
        val ls = Langs.all
        val items = ls.map { l ->
            val st = when { vosk.installed(l.code) && vosk.lang == l.code -> "✅ شغّالة"; vosk.installed(l.code) -> "✔ منزّلة"; else -> "⬇ تنزيل ${l.mb}MB" }
            "${l.label}  —  $st"
        } + listOf("🔊 بيانات النطق (صوت اللغة)", "📦 استيراد العربي من ملف zip", "🗑 حذف لغة")
        AlertDialog.Builder(this).setTitle("اللغات 🌐  كل اللغات المنزلة شغالة مع بعض في الاستماع (النت للتنزيل أول مرة بس)").setItems(items.toTypedArray()) { _, i ->
            when {
                i < ls.size -> pickLang(ls[i])
                i == ls.size -> open("android.speech.tts.engine.INSTALL_TTS_DATA")
                i == ls.size + 1 -> { add("نيكو: اختاري ملف vosk-model-ar-mgb2-0.4.zip."); pickVosk.launch(arrayOf("*/*")) }
                else -> deleteLangMenu()
            }
        }.show()
    }

    private fun pickLang(l: Lang) {
        if (vosk.installed(l.code)) { setLang(l); return }
        confirm("هنزّل ${l.label} (${l.mb}MB) من الإنترنت مرة واحدة بس، وبعدها بتشتغل من غير نت. نكمل؟") { downloadLang(l) }
    }

    private fun setLang(l: Lang) {
        vosk.release(); vosk.lang = l.code; llm.replyLang = l; applyTts()
        status.text = "نيكو"; add("نيكو: اللغة دلوقتي: ${l.label}.")
    }

    private fun downloadLang(l: Lang, setActive: Boolean = true, after: () -> Unit = {}) {
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        orb.state = WaterOrbView.State.THINKING; status.text = "بنزّل ${l.label}…"
        thread {
            val err = vosk.download(l) { m -> runOnUiThread { status.text = m } }
            runOnUiThread {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"
                if (err == null) { add("نيكو: ${l.label} اتنزلت وهتشتغل من غير نت."); if (setActive) setLang(l); after() } else add("نيكو: $err")
            }
        }
    }

    private fun importArabic(uri: Uri) {
        status.text = "بفك الموديل..."
        thread {
            val err = try { contentResolver.openInputStream(uri)?.use { vosk.installStream("ar", it, { m -> runOnUiThread { status.text = m } }) } ?: "مقدرتش أفتح الملف." } catch (e: Exception) { "فشل: ${e.message}" }
            runOnUiThread { status.text = "نيكو"; add(if (err == null) "نيكو: العربي المدمج جاهز ✅" else "نيكو: $err") }
        }
    }

    private fun deleteLangMenu() {
        val ls = Langs.all.filter { it.code != "ar" && vosk.installed(it.code) }
        if (ls.isEmpty()) { add("نيكو: مفيش لغات إضافية منزلة. (العربي ثابتة ومبتتمسحش)"); return }
        AlertDialog.Builder(this).setTitle("حذف لغة").setItems(ls.map { it.label }.toTypedArray()) { _, i ->
            val l = ls[i]; val wasCur = vosk.lang == l.code
            vosk.delete(l.code); add("نيكو: اتمسحت ${l.label}.")
            if (wasCur) setLang(Langs.byCode("ar"))
        }.show()
    }

    private fun voiceMenu() {
        val items = arrayOf("🔊 تحميل صوت النطق", "⚙ إعدادات النطق", "🎤 احتياطي: عربي جوجل أوفلاين")
        AlertDialog.Builder(this).setTitle("النطق والصوت").setItems(items) { _, i ->
            when (i) {
                0 -> open("android.speech.tts.engine.INSTALL_TTS_DATA")
                1 -> open("com.android.settings.TTS_SETTINGS")
                else -> { add("نيكو: في الشاشة اللي هتفتح اختاري Google ثم اللغات وحمّلي العربية للاستخدام بدون نت."); open("android.settings.VOICE_INPUT_SETTINGS") }
            }
        }.show()
    }

    // ---------- الذاكرة والإعدادات ----------
    private fun memoryMenu() {
        if (store.memories.isEmpty()) { AlertDialog.Builder(this).setTitle("الذاكرة 🧠").setMessage("فاضية. قولي لنيكو: \"افتكر إن ...\" وهيحفظها. وتقدري تمسحيها من هنا أو بـ \"انسى ...\".").setPositiveButton("تمام", null).show(); return }
        AlertDialog.Builder(this).setTitle("اللي نيكو فاكره عنك (اضغطي على واحدة لمسحها)")
            .setItems(store.memories.toTypedArray()) { _, i -> store.removeMemory(i); llm.memory = store.memoryText(); memoryMenu() }
            .setNeutralButton("مسح الكل") { _, _ -> confirm("مسح كل الذاكرة؟") { store.clearMemory(); llm.memory = "" } }
            .setPositiveButton("إغلاق", null).show()
    }

    private fun askText(title: String, def: String, onOk: (String) -> Unit) {
        val e = EditText(this); e.setText(def)
        AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("حفظ") { _, _ -> onOk(e.text.toString().trim()) }.setNegativeButton("إلغاء", null).show()
    }

    private fun voicePickMenu() {
        val l = curLang; val vs = tts?.let { Voices.forLang(it, l) } ?: emptyList()
        if (vs.isEmpty()) { add("نيكو: مفيش أصوات للغة ${l.label}. نزّلي بيانات النطق من اللغات."); return }
        val names = vs.map { "${it.name}  ${if (it.isNetworkConnectionRequired) "(نت)" else "(أوفلاين)"}  جودة ${it.quality}" }
        AlertDialog.Builder(this).setTitle("صوت النطق (جودة أعلى = أطبيعي أكتر)").setItems(names.toTypedArray()) { _, i ->
            prefs.edit().putString("voice_${l.code}", vs[i].name).apply(); applyTts(); say("ده صوتي الجديد، عجبك؟")
        }.show()
    }

    private fun settingsMenu() {
        fun on(k: String, d: Boolean) = prefs.getBoolean(k, d)
        fun onoff(k: String, d: Boolean) = if (on(k, d)) "شغّال" else "واقف"
        val items = arrayOf(
            "🔊 النطق التلقائي: ${onoff("speak", true)}",
            "⏩ سرعة النطق: ${arrayOf("بطيء", "عادي", "سريع")[prefs.getInt("rate", 1).coerceIn(0, 2)]}",
            "🗣 اختيار صوت النطق (طبيعي أكتر)",
            "🤖 الوكيل الذكي (ينفذ أي أمر بالشاشة): ${onoff("agent", true)}",
            "⚠ خطوات حساسة للوكيل (إرسال/حذف/دفع): ${if (on("sens", false)) "مسموحة" else "ممنوعة"}",
            "📏 طول الرد: ${arrayOf("مختصر", "متوسط", "مفصّل")[prefs.getInt("style", 1).coerceIn(0, 2)]}",
            "✅ قول \"عملته\" بعد التنفيذ: ${onoff("ack", true)}",
            "📞 الرد الافتراضي على المكالمات: ${(prefs.getString("call_reply", Calls.DEFAULT_REPLY) ?: "").take(28)}…",
            "📞 قفل المكالمة بعد الرسالة: ${onoff("hangup", true)}",
            "📞 نطق اسم المتصل: ${onoff("announce", true)}",
            "🔒 ينفذ لصوتي أنا بس (بصمة المالك): ${onoff("ownerOnly", false)}",
            "🔋 إيقاف الاستماع لو البطارية أقل من 15%: ${onoff("lowbat", true)}",
            "💾 توفير الرام (تفريغ الموديلات بعد 90ث): ${onoff("ramsave", false)}",
            "🫧 الكرة العائمة فوق التطبيقات: ${onoff("float", true)}",
            "🪟 السماح بالعرض فوق التطبيقات (لفتح التطبيقات من الخلفية)",
            "🔋 استثناء نيكو من توفير البطارية (عشان الخدمة ما تتقفلش)"
        )
        AlertDialog.Builder(this).setTitle("الإعدادات ⚙").setItems(items) { _, i ->
            var reopen = true
            when (i) {
                0 -> prefs.edit().putBoolean("speak", !on("speak", true)).apply()
                1 -> { prefs.edit().putInt("rate", (prefs.getInt("rate", 1) + 1) % 3).apply(); applyTts() }
                2 -> { voicePickMenu(); reopen = false }
                3 -> prefs.edit().putBoolean("agent", !on("agent", true)).apply()
                4 -> prefs.edit().putBoolean("sens", !on("sens", false)).apply()
                5 -> { val st = (prefs.getInt("style", 1) + 1) % 3; prefs.edit().putInt("style", st).apply(); llm.style = st }
                6 -> prefs.edit().putBoolean("ack", !on("ack", true)).apply()
                7 -> { reopen = false; askText("الرد على المكالمات (بتتقال لو قولتله: افتح المكالمة وقولهم)", prefs.getString("call_reply", Calls.DEFAULT_REPLY) ?: Calls.DEFAULT_REPLY) { v -> if (v.isNotBlank()) prefs.edit().putString("call_reply", v).apply(); settingsMenu() } }
                8 -> prefs.edit().putBoolean("hangup", !on("hangup", true)).apply()
                9 -> prefs.edit().putBoolean("announce", !on("announce", true)).apply()
                10 -> {
                    if (!on("ownerOnly", false) && people.owner()?.voice == null) { add("نيكو: سجّلي بصمة صوتك الأول: الأشخاص ← شخص جديد ← \"أنا المالك\"."); reopen = true }
                    else prefs.edit().putBoolean("ownerOnly", !on("ownerOnly", false)).apply()
                }
                11 -> prefs.edit().putBoolean("lowbat", !on("lowbat", true)).apply()
                12 -> prefs.edit().putBoolean("ramsave", !on("ramsave", false)).apply()
                13 -> prefs.edit().putBoolean("float", !on("float", true)).apply()
                14 -> { reopen = false; try { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } catch (_: Exception) {} }
                15 -> { reopen = false; try { startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))) } catch (_: Exception) { open(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) } }
            }
            if (reopen) settingsMenu()
        }.setPositiveButton("إغلاق", null).show()
    }

    // ---------- الاستماع الدائم ----------
    private fun setAlwaysOn(on: Boolean) {
        if (!on) { prefs.edit().putBoolean("always", false).apply(); ListenService.stop(this); onResume(); add("نيكو: وقفت الاستماع الدائم."); return }
        if (!hasMic()) { requestPermissions(perms, 1); add("نيكو: اسمحي بإذن المايك الأول وبعدين فعّلي الاستماع."); return }
        if (!vosk.installed("en")) {
            val en = Langs.byCode("en")
            confirm("كلمة النداء \"نيكو\" بتشتغل أخف على البطارية مع English (${en.mb}MB، نت مرة واحدة). أنزّلها؟") { downloadLang(en, false) { startListen() } }
            return
        }
        startListen()
    }
    private fun startListen() {
        prefs.edit().putBoolean("always", true).apply(); ListenService.start(this); onResume()
        add("نيكو: الاستماع الدائم شغّال. قولي \"نيكو\" وبعدها أي أمر، بأي لغة منزلة.")
    }

    // ---------- الأشخاص وبصمة الصوت ----------
    private fun savePhoto(p: Person, uri: Uri) {
        thread {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return@thread
                val sq = Bitmap.createScaledBitmap(bmp, 256, 256, true)
                val f = File(filesDir, "people/${p.id}.jpg"); f.parentFile?.mkdirs()
                f.outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                p.photo = f.absolutePath; people.save()
                runOnUiThread { add("نيكو: اتحفظت صورة ${p.name}."); peopleMenu() }
            } catch (e: Exception) { runOnUiThread { add("نيكو: معرفتش أحفظ الصورة.") } }
        }
    }

    private fun peopleMenu() {
        val list = people.list
        val lv = ListView(this)
        val ad = object : ArrayAdapter<Person>(this, 0, list) {
            override fun getView(pos: Int, cv: View?, parent: android.view.ViewGroup): View {
                val p = getItem(pos)!!
                val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(24, 16, 24, 16); gravity = Gravity.CENTER_VERTICAL }
                val img = ImageView(context).apply { layoutParams = LinearLayout.LayoutParams(120, 120) }
                val bm = if (p.photo.isNotBlank()) BitmapFactory.decodeFile(p.photo) else null
                if (bm != null) img.setImageBitmap(bm) else img.setImageResource(android.R.drawable.ic_menu_myplaces)
                val tv = TextView(context).apply {
                    text = p.name + (if (p.owner) "  ⭐ المالك" else "") + "\n" + (if (p.voice != null) "🎙 بصمة " else "") + (if (p.phone.isNotBlank()) "📱 رقم" else "")
                    textSize = 17f; setPadding(24, 0, 0, 0)
                }
                row.addView(img); row.addView(tv); return row
            }
        }
        lv.adapter = ad
        val dlg = AlertDialog.Builder(this).setTitle("الأشخاص 👥 (${list.size})").setView(lv)
            .setPositiveButton("➕ شخص جديد") { _, _ -> askText("اسم الشخص", "") { n -> if (n.isNotBlank()) personMenu(people.add(n)) } }
            .setNegativeButton("إغلاق", null).create()
        lv.setOnItemClickListener { _, _, i, _ -> dlg.dismiss(); personMenu(list[i]) }
        dlg.show()
    }

    private fun personMenu(p: Person) {
        val items = arrayOf("🎙 تسجيل بصمة الصوت (3 جمل)", "🖼 اختيار صورة", "📱 رقم الواتساب/الموبايل", "✏ تغيير الاسم", "⭐ ${if (p.owner) "إلغاء" else "تعيين"} كمالك (صاحب الموبايل)", "🗑 حذف الشخص")
        AlertDialog.Builder(this).setTitle(p.name).setItems(items) { _, i ->
            when (i) {
                0 -> recordVoiceprint(p)
                1 -> { pendingPerson = p; pickPhoto.launch(arrayOf("image/*")) }
                2 -> askText("رقم ${p.name} (مثال 01012345678)", p.phone) { v -> p.phone = v; people.save(); add("نيكو: اتحفظ الرقم. دلوقتي قولي: نيكو افتح شات ${p.name} واتساب."); peopleMenu() }
                3 -> askText("الاسم", p.name) { v -> if (v.isNotBlank()) { p.name = v; people.save() }; peopleMenu() }
                4 -> { val was = p.owner; people.list.forEach { it.owner = false }; p.owner = !was; people.save(); peopleMenu() }
                else -> confirm("حذف ${p.name}؟") { people.remove(p); peopleMenu() }
            }
        }.setNegativeButton("رجوع") { _, _ -> peopleMenu() }.show()
    }

    private fun captureSeconds(sec: Int): ShortArray {
        val sr = 16000; val out = ShortArray(sr * sec)
        val min = AudioRecord.getMinBufferSize(sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val rec = AudioRecord(MediaRecorder.AudioSource.VOICE_RECOGNITION, sr, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000))
        var n = 0
        try { rec.startRecording(); while (n < out.size) { val k = rec.read(out, n, minOf(1600, out.size - n)); if (k <= 0) break; n += k } } finally { try { rec.stop() } catch (_: Throwable) {}; rec.release() }
        return out.copyOf(n)
    }

    private fun recordVoiceprint(p: Person) {
        if (!hasMic()) { requestPermissions(perms, 1); return }
        if (!Voiceprint.ready()) {
            confirm("محتاج موديل بصمة الصوت (${Langs.SPK_MB}MB) من النت مرة واحدة. أنزّله؟") {
                status.text = "بنزّل موديل بصمة الصوت…"
                thread { val err = vosk.downloadSpk { m -> runOnUiThread { status.text = m } }
                    runOnUiThread { status.text = "نيكو"; if (err == null) recordVoiceprint(p) else add("نيكو: $err") } }
            }; return
        }
        if (vosk.installedLangs().isEmpty()) { add("نيكو: نزّلي لغة واحدة على الأقل من اللغات الأول."); return }
        if (ListenService.running) ListenService.externalPause = true
        val prompts = listOf("قول: أنا اسمي ${p.name} وده صوتي", "قول: نيكو افتح الكاميرا وبعدين اتصل بماما", "اتكلم أي كلام عادي لحد ما يخلص")
        thread {
            Thread.sleep(800)
            val vecs = ArrayList<FloatArray>()
            for ((i, pr) in prompts.withIndex()) {
                runOnUiThread { orb.state = WaterOrbView.State.LISTENING; orb.pulse(0.8f); status.text = "(${i + 1}/3) $pr" }
                val pcm = try { captureSeconds(5) } catch (e: Throwable) { ShortArray(0) }
                Voiceprint.embed(pcm, pcm.size)?.let { vecs.add(it) }
            }
            val avg = Voiceprint.average(vecs)
            runOnUiThread {
                ListenService.externalPause = false; orb.state = WaterOrbView.State.IDLE; status.text = "نيكو"
                if (avg != null && vecs.size >= 2) { p.voice = avg; people.save(); add("نيكو: حفظت بصمة صوت ${p.name} ✅"); orb.feel(Emotion.HAPPY) }
                else add("نيكو: البصمة ماتسجلتش (الصوت مش واضح، جربي في مكان هادي).")
                peopleMenu()
            }
        }
    }

    // ---------- موديل الذكاء ----------
    private fun llmMenu() {
        val items = arrayOf(
            if (llm.installed) "🔁 استبدال موديل الذكاء (.task / .litertlm)" else "➕ تثبيت موديل الذكاء (.task / .litertlm)",
            "🗑 حذف موديل الذكاء"
        )
        AlertDialog.Builder(this).setTitle("الذكاء الأوفلاين").setItems(items) { _, i ->
            if (i == 0) pickLlm.launch(arrayOf("*/*"))
            else { llm.release(); llm.modelFile.delete(); add("نيكو: اتمسح موديل الذكاء.") }
        }.show()
    }

    private fun installLlm(uri: Uri) {
        var name = "model.task"
        try { contentResolver.query(uri, null, null, null, null)?.use { if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = it.getString(i) ?: name } } } catch (_: Exception) {}
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext != "task" && ext != "litertlm") { add("نيكو: لازم الملف يكون .task أو .litertlm (موديل MediaPipe)."); return }
        status.text = "بنسخ موديل الذكاء..."
        thread {
            llm.release()
            val dst = llm.targetFor(ext)
            val tmp = File(dst.parentFile, "copy.tmp")
            val ok = try {
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o ->
                        val buf = ByteArray(1 shl 20); var total = 0L
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); total += n
                            if (total % (50L shl 20) < (1L shl 20)) runOnUiThread { status.text = "بنسخ… ${total / 1_000_000} MB" }
                        }
                    }
                    tmp.renameTo(dst)
                } ?: false
            } catch (e: Exception) { tmp.delete(); false }
            if (ok) llm.setTemplateFrom(name)
            val err = if (ok) llm.load() else "النسخ فشل (مساحة التخزين كفاية؟)."
            runOnUiThread { status.text = "نيكو"; add(if (err == null) "نيكو: موديل الذكاء جاهز ✅ اسأليني أي حاجة." else "نيكو: $err") }
        }
    }

    override fun onDestroy() { vosk.release(); sr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
