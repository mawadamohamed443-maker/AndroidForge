package com.nico.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.vosk.Recognizer
import org.vosk.Model
import java.io.File
import kotlin.math.sqrt

class Person(val id: String, var name: String, var phone: String = "", var photo: String = "", var voice: FloatArray? = null, var owner: Boolean = false)

/** الأشخاص: اسم + صورة + رقم (لواتساب) + بصمة صوت. بيتخزنوا محلياً بس. */
class People(private val ctx: Context) {
    private val f = File(ctx.filesDir, "people.json")
    val list: MutableList<Person> = load()

    private fun load(): MutableList<Person> = try {
        val a = JSONArray(f.readText()); val out = ArrayList<Person>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val v = o.optJSONArray("voice")?.let { arr -> FloatArray(arr.length()) { arr.getDouble(it).toFloat() } }
            out.add(Person(o.getString("id"), o.getString("name"), o.optString("phone"), o.optString("photo"), v, o.optBoolean("owner")))
        }
        out
    } catch (_: Exception) { mutableListOf() }

    fun save() {
        val a = JSONArray()
        list.forEach { p ->
            val o = JSONObject().put("id", p.id).put("name", p.name).put("phone", p.phone).put("photo", p.photo).put("owner", p.owner)
            p.voice?.let { v -> o.put("voice", JSONArray(v.map { it.toDouble() })) }
            a.put(o)
        }
        try { f.writeText(a.toString()) } catch (_: Exception) {}
    }

    fun add(name: String): Person { val p = Person(System.currentTimeMillis().toString(), name); list.add(p); save(); return p }
    fun remove(p: Person) { list.remove(p); try { File(p.photo).delete() } catch (_: Exception) {}; save() }
    fun owner(): Person? = list.firstOrNull { it.owner }

    fun byName(spoken: String): Person? {
        val q = Skills.norm(spoken).trim(); if (q.isBlank()) return null
        list.firstOrNull { Skills.norm(it.name) == q }?.let { return it }
        list.firstOrNull { val n = Skills.norm(it.name); n.contains(q) || q.contains(n) }?.let { return it }
        return list.firstOrNull { Mix.lev(Skills.norm(it.name), q) <= 1 && q.length >= 3 }
    }
}

/** بصمة الصوت (Vosk speaker model). مقارنة بمسافة cosine. */
object Voiceprint {
    var threshold = 0.45
    private var spk: Any? = null
    fun ready() = File(Shared.vosk.dirFor("spk"), "final.ext.raw").exists()

    @Synchronized private fun model(): Any? {
        if (spk == null && ready()) spk = try {
            Class.forName("org.vosk.SpeakerModel").getConstructor(String::class.java).newInstance(Shared.vosk.dirFor("spk").absolutePath)
        } catch (_: Throwable) { null }
        return spk
    }

    /** بيطلّع متجه البصمة من صوت 16kHz mono، أو null. (Reflection عشان نسخ Vosk المختلفة) */
    fun embed(pcm: ShortArray, n: Int): FloatArray? {
        val sm = model() ?: return null
        val code = listOf("en", "ar").firstOrNull { Shared.vosk.installed(it) } ?: Shared.vosk.installedLangs().firstOrNull()?.code ?: return null
        val dir = Shared.vosk.modelDir(code) ?: return null
        var r: Recognizer? = null
        return try {
            val ctor = Recognizer::class.java.getConstructor(Model::class.java, java.lang.Float.TYPE, Class.forName("org.vosk.SpeakerModel"))
            val rec = ctor.newInstance(VoskModels.get(code, dir), 16000f, sm) as Recognizer
            r = rec
            rec.acceptWaveForm(pcm, n)
            val a = JSONObject(rec.finalResult).optJSONArray("spk") ?: return null
            FloatArray(a.length()) { a.getDouble(it).toFloat() }
        } catch (_: Throwable) { null } finally { try { r?.close() } catch (_: Throwable) {} }
    }

    fun dist(a: FloatArray, b: FloatArray): Double {
        var d = 0.0; var na = 0.0; var nb = 0.0
        for (i in 0 until minOf(a.size, b.size)) { d += a[i] * b[i]; na += a[i] * a[i]; nb += b[i] * b[i] }
        return if (na == 0.0 || nb == 0.0) 1.0 else 1.0 - d / (sqrt(na) * sqrt(nb))
    }

    fun identify(vec: FloatArray?, people: List<Person>): Person? {
        if (vec == null) return null
        val best = people.filter { it.voice != null }.map { it to dist(vec, it.voice!!) }.minByOrNull { it.second } ?: return null
        return if (best.second < threshold) best.first else null
    }

    fun average(vs: List<FloatArray>): FloatArray? {
        if (vs.isEmpty()) return null
        val out = FloatArray(vs[0].size); vs.forEach { v -> for (i in out.indices) out[i] += v[i] / vs.size }; return out
    }
}
