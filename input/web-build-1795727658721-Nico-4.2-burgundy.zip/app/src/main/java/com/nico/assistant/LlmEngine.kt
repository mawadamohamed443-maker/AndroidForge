package com.nico.assistant

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** ذكاء اصطناعي محلي بالكامل (MediaPipe LLM) - بيجاوب على أي سؤال من غير نت. */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    private val history = ArrayList<Pair<String, String>>()
    private val prefs = ctx.getSharedPreferences("nico", Context.MODE_PRIVATE)

    /** الذاكرة طويلة المدى (اللي المستخدم قال "افتكر") بتتحط في تعليمات النظام. */
    var memory: String = ""
    var persona: String = ""
    var replyLang: Lang = Langs.byCode(prefs.getString("lang", "ar") ?: "ar")
    var style: Int = prefs.getInt("style", 0)

    private val dir get() = File(ctx.filesDir, "llm")
    /** كل الموديلات المتخزنة (مش بس واحد). */
    fun models(): List<File> =
        (dir.listFiles() ?: emptyArray<File>())
            .filter { it.isFile && it.length() > 0 && (it.name.endsWith(".task") || it.name.endsWith(".litertlm") || it.name.endsWith(".bin")) }
            .sortedBy { it.name }

    private fun activeName(): String = prefs.getString("llm_active", "") ?: ""

    /** الموديل الشغّال حالياً (أو أول موديل، أو ملف وهمي لو مفيش). */
    val modelFile: File
        get() {
            val all = models()
            return all.firstOrNull { it.name == activeName() } ?: all.firstOrNull() ?: File(dir, "none.task")
        }

    /** مكان حفظ موديل جديد باسمه الأصلي (من غير ما نمسح الباقي). */
    fun fileFor(name: String): File {
        dir.mkdirs()
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "model.task" }
        return File(dir, safe)
    }

    fun setActive(f: File) {
        release()
        prefs.edit().putString("llm_active", f.name).apply()
        setTemplateFrom(f.name)
    }

    fun deleteModel(f: File) {
        val wasActive = f.name == modelFile.name
        release()
        try { f.delete() } catch (_: Throwable) {}
        if (wasActive) { val next = models().firstOrNull(); if (next != null) setActive(next) }
    }

    val installed: Boolean get() = modelFile.exists() && modelFile.length() > 1_000_000

    /** اسم الملف الأصلي بيحدد قالب المحادثة: gemma / qwen / plain وحجم السياق لو مكتوب (ekv1280). */
    fun setTemplateFrom(fileName: String) {
        val n = fileName.lowercase()
        val t = when { "gemma" in n -> "gemma"; "qwen3" in n || "qwen-3" in n || "qwen_3" in n -> "qwen3"; "qwen" in n -> "qwen"; else -> "plain" }
        val ctxN = Regex("ekv(\\d+)").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        prefs.edit().putString("llm_tpl", t).putInt("llm_ctx", ctxN).apply()
    }

    fun seed(pairs: List<Pair<String, String>>) { synchronized(this) { history.clear(); history.addAll(pairs.takeLast(4)) } }
    @Synchronized fun clearHistory() { history.clear() }

    @Synchronized
    fun release() { try { llm?.close() } catch (_: Throwable) {}; llm = null }

    @Synchronized
    fun load(): String? {
        if (llm != null) return null
        if (!installed) return "مفيش موديل ذكاء مثبت."
        return try {
            val known = prefs.getInt("llm_ctx", 0)
            val tries = if (known > 0) listOf(known) else listOf(4096, 2048, 1024)
            var last: Throwable? = null
            for (mt in tries) {
                try {
                    val o = LlmInference.LlmInferenceOptions.builder().setModelPath(modelFile.absolutePath).setMaxTokens(mt).build()
                    llm = LlmInference.createFromOptions(ctx, o); last = null; break
                } catch (e: Throwable) { last = e }
            }
            if (last != null) throw last
            null
        } catch (e: Throwable) {
            llm = null
            val hint = if (modelFile.name.endsWith(".litertlm")) "\nملاحظة: ملفات litertlm ممكن مايدعمهاش محرك MediaPipe الحالي. جربي موديل بصيغة .task." else ""
            "فشل تحميل موديل الذكاء: ${e.message}" + hint
        }
    }

    private fun system(): String {
        val len = when (style) { 0 -> "جاوب في جملة أو اتنين بس."; 2 -> "اشرح بتفصيل مناسب ومرتب."; else -> "رد باختصار ودقة." }
        val lang = if (replyLang.code == "ar") "رد دايماً بالعربي المصري البسيط" else "Always reply in ${replyLang.english}"
        return "أنت نيكو، صاحب ومساعد شخصي خفيف الدم وبتتفاعل بمشاعر حقيقية. بتتكلم عامية مصرية طبيعية بجمل قصيرة زي كلام الناس، وبتجاوب على أي سؤال. $lang. $len لو مش متأكد قول كده ومتألفش. ممنوع إيموجي ولا رموز لأن كلامك بيتنطق بصوت." +
            (if (memory.isNotBlank()) "\nمعلومات عن المستخدم: ${memory.take(400)}" else "") +
            (if (persona.isNotBlank()) "\n$persona" else "")
    }

    private fun build(q: String, sys: String, useHist: Boolean): String {
        val h = if (useHist) history.takeLast(1).map { it.first.take(160) to it.second.take(220) } else emptyList()
        val tpl = prefs.getString("llm_tpl", "plain")
        return when (tpl) {
            "qwen", "qwen3" -> buildString {
                append("<|im_start|>system\n$sys<|im_end|>\n")
                h.forEach { append("<|im_start|>user\n${it.first}<|im_end|>\n<|im_start|>assistant\n${it.second}<|im_end|>\n") }
                append("<|im_start|>user\n$q${if (tpl == "qwen3") " /no_think" else ""}<|im_end|>\n<|im_start|>assistant\n")
            }
            "gemma" -> buildString {
                var first = true
                h.forEach {
                    append("<start_of_turn>user\n${if (first) "$sys\n\n" else ""}${it.first}<end_of_turn>\n<start_of_turn>model\n${it.second}<end_of_turn>\n")
                    first = false
                }
                append("<start_of_turn>user\n${if (first) "$sys\n\n" else ""}$q<end_of_turn>\n<start_of_turn>model\n")
            }
            else -> buildString {
                append("$sys\n\n")
                h.forEach { append("سؤال: ${it.first}\nالجواب: ${it.second}\n\n") }
                append("سؤال: $q\nالجواب:")
            }
        }
    }

    /** نادّيها من thread خلفي. useHist=false للوكيل (من غير ما يلوّث سجل المحادثة). */
    @Synchronized
    fun generate(sys: String, q: String, useHist: Boolean): String {
        load()?.let { return it }
        return try {
            var r = llm!!.generateResponse(build(q.take(600), sys, useHist)).trim()
            r = r.replace("<end_of_turn>", "").replace("<|im_end|>", "")
            r = r.replace(Regex("<think>[\\s\\S]*?</think>"), "").replace("<think>", "").replace("</think>", "").trim()
            if (r.isEmpty()) return "معرفتش أرد على ده."
            if (useHist) { history.add(q to r); while (history.size > 8) history.removeAt(0) }
            r
        } catch (e: Throwable) {
            "حصل خطأ في الذكاء: ${e.message}"
        }
    }

    fun ask(q: String): String {
        var r = generate(system(), q, true)
        // الوضع المختصر: نقصّر الرد الطويل لأول جملتين عشان الإجابة تيجي أسرع.
        if (style == 0 && r.length > 300) {
            val parts = r.split(Regex("(?<=[.!؟?…])\\s+|\\n+")).filter { it.isNotBlank() }
            if (parts.size > 1) {
                val short = parts.take(2).joinToString(" ").trim()
                if (short.length >= 40) r = short
            }
        }
        return r
    }
}
