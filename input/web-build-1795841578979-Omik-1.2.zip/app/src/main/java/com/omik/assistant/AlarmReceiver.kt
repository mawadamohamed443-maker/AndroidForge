package com.omik.assistant

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getIntExtra("id", 0)
        val title = i.getStringExtra("title") ?: "أوميك"
        var text = i.getStringExtra("text") ?: ""
        text = when {
            text == "birthday_check" -> {
                val bdays = PeopleStore(c).birthdaysToday()
                if (bdays.isEmpty()) return
                ReminderManager.scheduleDaily(c)
                val names = bdays.joinToString(" و ") { it.name }
                "النهارده عيد ميلاد $names 🎂 متنسيش تهنيها: ${ContentBanks.birthdayWishes.random()}"
            }
            text == "morning_adhkar" -> {
                ReminderManager.scheduleDaily(c)
                "صباح الخير يا دودو ☀ اذكار الصباح: ${ContentBanks.morningAdhkar.random()}"
            }
            text == "evening_adhkar" -> {
                ReminderManager.scheduleDaily(c)
                "مساء الخير يا دودو 🌙 اذكار المساء: ${ContentBanks.eveningAdhkar.random()}"
            }
            text == "prayer" -> title
            text.startsWith("study_") -> title
            else -> text
        }
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("omik_reminders", "تذكيرات أوميك", NotificationManager.IMPORTANCE_HIGH))
        }
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(c, "omik_reminders") else Notification.Builder(c)
        b.setSmallIcon(R.drawable.ic_stat)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setContentIntent(open)
        nm.notify(id, b.build())
    }
}
