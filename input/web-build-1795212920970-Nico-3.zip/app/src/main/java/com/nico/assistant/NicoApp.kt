package com.nico.assistant

import android.app.Application
import android.os.Build
import android.util.Log
import java.io.File

/** بيسجّل أي انهيار في ملف عشان شاشة الحماية تعرضه (بدل ما التطبيق يقفل من غير ما نعرف السبب). */
class NicoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            try {
                File(filesDir, "crash.txt").writeText(
                    "Nico 3.0 | " + Build.MANUFACTURER + " " + Build.MODEL + " | Android " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ")\n" +
                        "thread=" + t.name + "\n\n" + Log.getStackTraceString(e))
            } catch (_: Throwable) {}
            prev?.uncaughtException(t, e)
        }
    }
}
