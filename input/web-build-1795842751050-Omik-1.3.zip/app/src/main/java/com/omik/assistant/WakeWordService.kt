package com.omik.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class WakeWordService : Service() {

    companion object {
        fun start(c: Context) {
            val i = Intent(c, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i) else c.startService(i)
        }
        fun stop(c: Context) { c.stopService(Intent(c, WakeWordService::class.java)) }
    }

    private var rec: SpeechRecognizer? = null
    private var tts: TtsManager? = null
    private var running = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("omik_wake", "كلمة النداء", NotificationManager.IMPORTANCE_MIN))
        }
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "omik_wake") else Notification.Builder(this)
        val notif = b.setSmallIcon(R.drawable.ic_stat).setContentTitle("أوميك سامعك 👂")
            .setContentText("قولي \"${Prefs.wakeWord}\" وأنا هرد").setContentIntent(open).build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(3, notif, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(3, notif, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(3, notif)
        }
        tts = TtsManager(this)
        running = true
        startListening()
    }

    private fun startListening() {
        if (!running) return
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(this)
            rec?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { restart() }
                override fun onError(error: Int) { restartDelayed() }
                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    check(list?.firstOrNull())
                    restart()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    check(list?.firstOrNull())
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
            i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            rec?.startListening(i)
        } catch (e: Exception) { restartDelayed() }
    }

    private fun check(text: String?) {
        if (text == null) return
        val n = TextUtil.norm(text)
        val wake = TextUtil.norm(Prefs.wakeWord)
        if (wake.isNotEmpty() && n.contains(wake)) {
            tts?.speak("اهلا يا دودو، انا سامعك 💙")
            val i = Intent(this, MainActivity::class.java)
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            i.putExtra("voice", true)
            startActivity(i)
        }
    }

    private fun restart() {
        android.os.Handler(mainLooper).postDelayed({ startListening() }, 400)
    }
    private fun restartDelayed() {
        android.os.Handler(mainLooper).postDelayed({ startListening() }, 1500)
    }

    override fun onDestroy() {
        running = false
        try { rec?.destroy() } catch (e: Exception) {}
        tts?.shutdown()
        super.onDestroy()
    }
}
