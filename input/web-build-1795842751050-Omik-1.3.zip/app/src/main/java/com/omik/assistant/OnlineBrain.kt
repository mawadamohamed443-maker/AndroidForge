package com.omik.assistant

import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object OnlineBrain {

    interface Sink {
        fun onChunk(fullTextSoFar: String)
        fun onDone(fullText: String)
        fun onFail()
    }

    private const val SYSTEM_PROMPT = "انت اسمك اوميك، مساعد شخصي مصري بيتكلم بالعاميه المصرية الحلوة، صوتك راجل طبيعي وودود. صاحبتك اسمها مودة وبتناديها يا دودو او يا قمر احيانا. هي طالبه في تانيه بكالوريا مسار هندسه وبتذاكر عربي وانجليزي وتاريخ وبرمجه. رد بسرعه واختصار وبالعامي، ومتتكلمش في حاجه تضرها، ولو سألتك سؤال طبي قولها اسال دكتور. متتكلمش بالانجليزي الا لو هي كلمتك انجليزي."

    fun ask(prompt: String, sink: Sink) {
        Thread {
            try {
                if (Prefs.apiUrl.isNotEmpty() && Prefs.apiKey.isNotEmpty()) {
                    askOpenAi(prompt, sink)
                } else {
                    askPollinations(prompt, sink)
                }
            } catch (e: Exception) {
                sink.onFail()
            }
        }.start()
    }

    private fun askPollinations(prompt: String, sink: Sink) {
        val full = "$SYSTEM_PROMPT\n\nالسؤال: $prompt"
        val url = URL("https://text.pollinations.ai/" + URLEncoder.encode(full, "UTF-8"))
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.requestMethod = "GET"
        try {
            val reader = BufferedReader(InputStreamReader(conn.inputStream, Charsets.UTF_8))
            val sb = StringBuilder()
            val buf = CharArray(64)
            var lastEmit = 0L
            while (true) {
                val n = reader.read(buf)
                if (n < 0) break
                sb.append(buf, 0, n)
                val now = System.currentTimeMillis()
                if (now - lastEmit > 120) {
                    lastEmit = now
                    sink.onChunk(sb.toString())
                }
            }
            reader.close()
            val result = sb.toString().trim()
            if (result.isEmpty()) sink.onFail() else { sink.onChunk(result); sink.onDone(result) }
        } finally {
            conn.disconnect()
        }
    }

    private fun askOpenAi(prompt: String, sink: Sink) {
        val url = URL(Prefs.apiUrl)
        val conn = url.openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 60000
        conn.requestMethod = "POST"
        conn.setRequestProperty("Content-Type", "application/json")
        conn.setRequestProperty("Authorization", "Bearer ${Prefs.apiKey}")
        conn.doOutput = true
        val model = if (Prefs.apiModel.isNotEmpty()) Prefs.apiModel else "gpt-4o-mini"
        val body = """{"model":"$model","messages":[{"role":"system","content":"$SYSTEM_PROMPT"},{"role":"user","content":${org.json.JSONObject.quote(prompt)}}]}"""
        OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val text = stream.bufferedReader(Charsets.UTF_8).readText()
        conn.disconnect()
        if (code !in 200..299) { sink.onFail(); return }
        val content = org.json.JSONObject(text)
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
        sink.onChunk(content)
        sink.onDone(content)
    }
}
