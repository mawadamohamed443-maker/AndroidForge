package com.omik.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.Toast

class MainActivity : Activity() {

    lateinit var orb: OmikOrbView
    private lateinit var chatList: ListView
    private lateinit var input: EditText
    private lateinit var adapter: ChatAdapter
    private lateinit var tts: TtsManager
    private var stt: SttManager? = null
    private lateinit var brain: Brain
    private val handler = Handler(Looper.getMainLooper())
    private var listening = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Prefs.init(this)
        orb = findViewById(R.id.orb)
        chatList = findViewById(R.id.chat)
        input = findViewById(R.id.input)
        adapter = ChatAdapter(layoutInflater)
        chatList.adapter = adapter
        tts = TtsManager(this)
        brain = Brain(this)
        applyTheme()

        findViewById<ImageButton>(R.id.btnSend).setOnClickListener { sendText() }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener { toggleListen() }
        findViewById<ImageButton>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        findViewById<ImageButton>(R.id.btnPeople).setOnClickListener {
            startActivity(Intent(this, PeopleActivity::class.java))
        }
        input.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEND) { sendText(); true } else false
        }
        orb.setOnClickListener {
            Prefs.muted = !Prefs.muted
            if (Prefs.muted) { tts.stop(); toast("كتمت صوتي 🔇 دوسي علي الكرة تاني عشان ارجع اتكلم") }
            else toast("رجعت اتكلم 🔊")
        }

        if (Build.VERSION.SDK_INT >= 23) {
            val need = mutableListOf(Manifest.permission.RECORD_AUDIO)
            if (Build.VERSION.SDK_INT >= 33) need.add(Manifest.permission.POST_NOTIFICATIONS)
            if (Build.VERSION.SDK_INT >= 26) need.add(Manifest.permission.READ_PHONE_STATE)
            requestPermissions(need.toTypedArray(), 1)
        }
        if (Prefs.wakeEnabled) WakeWordService.start(this)

        // birthday greeting
        val bdays = PeopleStore(this).birthdaysToday()
        if (bdays.isNotEmpty()) {
            handler.postDelayed({
                val names = bdays.joinToString(" و ") { it.name }
                addOmikMsg("يا دودو!! النهارده عيد ميلاد $names 🎂🎉")
                speak("يا دودو، النهارده عيد ميلاد $names! متنسيش تهنيها")
            }, 1500)
        }
        if (intent?.getBooleanExtra("voice", false) == true) {
            handler.postDelayed({ toggleListen() }, 800)
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        if (intent?.getBooleanExtra("voice", false) == true) {
            handler.postDelayed({ toggleListen() }, 500)
        }
    }

    fun applyTheme() {
        val root = findViewById<LinearLayout>(R.id.root)
        val black = when (Prefs.theme) {
            "night" -> true
            else -> Prefs.bgBlack
        }
        root.setBackgroundColor(if (black) Color.BLACK else Color.WHITE)
        val textColor = if (black) Color.WHITE else Color.BLACK
        findViewById<android.widget.TextView>(R.id.title).setTextColor(textColor)
        input.setTextColor(if (black) Color.WHITE else Color.BLACK)
        val orbColor = when (Prefs.theme) {
            "night" -> 0xFF1A237E.toInt()
            "sea" -> 0xFF00ACC1.toInt()
            "ramadan" -> 0xFF6A1B9A.toInt()
            else -> Prefs.orbColor
        }
        orb.setColor(orbColor)
        val size = (Prefs.orbSizeDp * resources.displayMetrics.density).toInt()
        val lp = orb.layoutParams
        lp.width = size; lp.height = size
        orb.layoutParams = lp
        orb.setDim(Prefs.isQuietNow())
    }

    fun orbHappy() { orb.setMood(60f, 4000); orb.setState(OmikOrbView.State.SPEAKING) }

    private fun sendText() {
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        handleUserText(text)
    }

    private fun toggleListen() {
        if (listening) {
            stt?.stop(); listening = false
            orb.setState(OmikOrbView.State.IDLE)
            return
        }
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        listening = true
        tts.stop()
        orb.setState(OmikOrbView.State.LISTENING)
        stt = SttManager(this,
            onFinal = { text ->
                runOnUiThread {
                    listening = false
                    if (text != null) handleUserText(text)
                    else { orb.setState(OmikOrbView.State.IDLE); addOmikMsg("مسمعتكش كويس يا دودو، قولي تاني 👂") }
                }
            },
            onRms = { rms -> runOnUiThread { orb.setVoiceLevel(rms) } },
            onPartial = { partial -> runOnUiThread { input.setText(partial); input.setSelection(partial.length) } }
        )
        stt?.start()
    }

    private fun handleUserText(text: String) {
        adapter.add(ChatMsg(text, true))
        scrollChat()
        orb.setState(OmikOrbView.State.THINKING)
        val sb = StringBuilder()
        var first = true
        brain.respond(text, object : Brain.ReplySink {
            override fun onChunk(textSoFar: String) {
                runOnUiThread {
                    sb.clear(); sb.append(textSoFar)
                    if (first) { adapter.add(ChatMsg(textSoFar, false)); first = false }
                    else adapter.updateLast(textSoFar)
                    scrollChat()
                }
            }
            override fun onDone(full: String) {
                runOnUiThread {
                    if (first) { adapter.add(ChatMsg(full, false)); first = false }
                    else adapter.updateLast(full)
                    scrollChat()
                    orb.setState(OmikOrbView.State.SPEAKING)
                    speak(full)
                }
            }
            override fun onFail() {
                runOnUiThread {
                    val msg = "حصلت مشكله في الرد، جربي تاني يا دودو 🥲"
                    if (first) adapter.add(ChatMsg(msg, false)) else adapter.updateLast(msg)
                    scrollChat()
                    orb.setState(OmikOrbView.State.IDLE)
                }
            }
        })
    }

    private fun speak(text: String) {
        if (Prefs.muted) { orb.setState(OmikOrbView.State.IDLE); return }
        tts.onDone = { runOnUiThread { orb.setState(OmikOrbView.State.IDLE) } }
        tts.speak(text)
    }

    private fun addOmikMsg(text: String) { adapter.add(ChatMsg(text, false)); scrollChat() }
    private fun scrollChat() { chatList.post { chatList.setSelection(adapter.count - 1) } }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun exportChat(): String = exportChatFile(this, adapter.items)

    fun pickPdf() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "application/pdf"
        try { startActivityForResult(i, 9) } catch (e: Exception) { addOmikMsg("مش قادر افتح اختيار الملفات") }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 9 && resultCode == RESULT_OK && data?.data != null) {
            addOmikMsg("بقرا الملف... 📄")
            Thread {
                val text = PdfTool.extractText(this, data.data!!, 4000)
                runOnUiThread {
                    if (text.isBlank()) {
                        addOmikMsg("مش قادر اقرا الملف ده، يمكن محمي او صور مش نص 🥲")
                    } else {
                        val shown = if (text.length > 1200) text.take(1200) + "..." else text
                        addOmikMsg("خلاص يا دودو، ده اللي في الملف 📄:\n$shown")
                        speak("قريت الملف يا دودو. " + text.take(400))
                    }
                }
            }.start()
        }
    }

    override fun onResume() {
        super.onResume()
        applyTheme()
        brain.endFocus()
    }

    override fun onDestroy() {
        stt?.destroy()
        tts.shutdown()
        super.onDestroy()
    }
}
