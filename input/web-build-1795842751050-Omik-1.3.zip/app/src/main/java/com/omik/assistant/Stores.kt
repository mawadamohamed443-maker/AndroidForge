package com.omik.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private fun readJsonFile(f: File): JSONArray {
    return try { if (f.exists()) JSONArray(f.readText(Charsets.UTF_8)) else JSONArray() } catch (e: Exception) { JSONArray() }
}
private fun writeJsonFile(f: File, a: JSONArray) { f.writeText(a.toString(), Charsets.UTF_8) }

class PeopleStore(private val c: Context) {
    private val file get() = File(c.filesDir, "people.json")
    fun all(): MutableList<Person> {
        val arr = readJsonFile(file); val out = mutableListOf<Person>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Person(o.optString("id"), o.optString("name"), o.optString("phone"),
                o.optString("relation"), o.optString("birthday"), o.optString("photo"), o.optString("voice")))
        }
        return out
    }
    fun save(list: List<Person>) {
        val arr = JSONArray()
        for (p in list) {
            val o = JSONObject()
            o.put("id", p.id); o.put("name", p.name); o.put("phone", p.phone)
            o.put("relation", p.relation); o.put("birthday", p.birthday)
            o.put("photo", p.photo); o.put("voice", p.voice)
            arr.put(o)
        }
        writeJsonFile(file, arr)
    }
    fun upsert(p: Person) {
        val list = all()
        if (p.id.isEmpty()) p.id = System.currentTimeMillis().toString()
        val idx = list.indexOfFirst { it.id == p.id }
        if (idx >= 0) list[idx] = p else list.add(p)
        save(list)
    }
    fun delete(id: String) { save(all().filter { it.id != id }) }
    fun findByName(name: String): Person? {
        val n = TextUtil.norm(name)
        if (n.isEmpty()) return null
        return all().firstOrNull { TextUtil.norm(it.name).contains(n) || n.contains(TextUtil.norm(it.name)) }
    }
    fun birthdaysToday(): List<Person> {
        val cal = java.util.Calendar.getInstance()
        val d = cal.get(java.util.Calendar.DAY_OF_MONTH); val m = cal.get(java.util.Calendar.MONTH) + 1
        return all().filter {
            try {
                val parts = it.birthday.trim().split("/", "-", ".")
                parts.size >= 2 && parts[0].trim().toInt() == d && parts[1].trim().toInt() == m
            } catch (e: Exception) { false }
        }
    }
    fun nextBirthday(p: Person): Int {
        return try {
            val parts = p.birthday.trim().split("/", "-", ".")
            val d = parts[0].trim().toInt(); val m = parts[1].trim().toInt()
            val now = java.util.Calendar.getInstance()
            var b = java.util.Calendar.getInstance()
            b.set(java.util.Calendar.MONTH, m - 1); b.set(java.util.Calendar.DAY_OF_MONTH, d)
            b.set(java.util.Calendar.HOUR_OF_DAY, 0); b.set(java.util.Calendar.MINUTE, 0)
            b.set(java.util.Calendar.SECOND, 0); b.set(java.util.Calendar.MILLISECOND, 0)
            if (b.timeInMillis < now.timeInMillis) { b = java.util.Calendar.getInstance(); b.add(java.util.Calendar.YEAR, 1); b.set(java.util.Calendar.MONTH, m - 1); b.set(java.util.Calendar.DAY_OF_MONTH, d) }
            ((b.timeInMillis - now.timeInMillis) / (24L * 3600 * 1000)).toInt()
        } catch (e: Exception) { -1 }
    }
}

class ReminderStore(private val c: Context) {
    private val file get() = File(c.filesDir, "reminders.json")
    fun all(): MutableList<Reminder> {
        val arr = readJsonFile(file); val out = mutableListOf<Reminder>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Reminder(o.optInt("id"), o.optString("text"), o.optLong("time")))
        }
        return out
    }
    fun save(list: List<Reminder>) {
        val arr = JSONArray()
        for (r in list) { val o = JSONObject(); o.put("id", r.id); o.put("text", r.text); o.put("time", r.time); arr.put(o) }
        writeJsonFile(file, arr)
    }
    fun add(r: Reminder) { val l = all(); if (r.id == 0) r.id = (System.currentTimeMillis() % 2000000000).toInt(); l.add(r); save(l) }
    fun remove(id: Int) { save(all().filter { it.id != id }) }
    fun clear() { save(emptyList()) }
}

class NoteStore(private val c: Context, private val name: String) {
    private val file get() = File(c.filesDir, "$name.json")
    fun all(): MutableList<NoteItem> {
        val arr = readJsonFile(file); val out = mutableListOf<NoteItem>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(NoteItem(o.optLong("id"), o.optString("text"), o.optString("date")))
        }
        return out
    }
    fun add(text: String) {
        val l = all()
        val df = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.US)
        l.add(NoteItem(System.currentTimeMillis(), text, df.format(java.util.Date())))
        val arr = JSONArray()
        for (n in l) { val o = JSONObject(); o.put("id", n.id); o.put("text", n.text); o.put("date", n.date); arr.put(o) }
        writeJsonFile(file, arr)
    }
}

class MemoryStore(private val c: Context) {
    private val file get() = File(c.filesDir, "memory.json")
    fun all(): List<String> {
        val arr = readJsonFile(file); val out = mutableListOf<String>()
        for (i in 0 until arr.length()) out.add(arr.optString(i))
        return out
    }
    fun add(fact: String) {
        val arr = readJsonFile(file); arr.put(fact); writeJsonFile(file, arr)
    }
}

class StudyStore(private val c: Context) {
    private val file get() = File(c.filesDir, "study.json")
    fun all(): MutableList<StudySlot> {
        val arr = readJsonFile(file); val out = mutableListOf<StudySlot>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(StudySlot(o.optInt("id"), o.optString("subject"), o.optInt("day"), o.optInt("hour"), o.optInt("minute")))
        }
        return out
    }
    fun save(list: List<StudySlot>) {
        val arr = JSONArray()
        for (s in list) {
            val o = JSONObject(); o.put("id", s.id); o.put("subject", s.subject)
            o.put("day", s.dayOfWeek); o.put("hour", s.hour); o.put("minute", s.minute); arr.put(o)
        }
        writeJsonFile(file, arr)
    }
    fun add(s: StudySlot) { val l = all(); if (s.id == 0) s.id = (System.currentTimeMillis() % 2000000000).toInt(); l.add(s); save(l) }
    fun remove(id: Int) { save(all().filter { it.id != id }) }
}
