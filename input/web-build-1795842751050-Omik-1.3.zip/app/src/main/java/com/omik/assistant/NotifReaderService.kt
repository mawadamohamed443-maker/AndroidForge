package com.omik.assistant

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifReaderService : NotificationListenerService() {
    companion object {
        var tts: TtsManager? = null
    }
    override fun onListenerConnected() {
        if (tts == null) tts = TtsManager(applicationContext)
    }
    override fun onNotificationPosted(sbn: StatusBarNotification) {
        if (!Prefs.notifReadEnabled) return
        val pkg = sbn.packageName ?: return
        val isMsgApp = pkg.contains("whatsapp") || pkg.contains("telegram") || pkg.contains("messenger") || pkg.contains("sms") || pkg.contains("messaging")
        if (!isMsgApp) return
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: return
        val text = extras.getCharSequence("android.text")?.toString() ?: return
        if (text.isBlank() || title.isBlank()) return
        if (text.contains("messages") || text.contains("رسائل") || text.contains("new message")) return
        tts?.speak("$title بعتلك: $text")
    }
}
