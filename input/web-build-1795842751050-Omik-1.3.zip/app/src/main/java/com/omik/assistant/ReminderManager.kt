package com.omik.assistant

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

object ReminderManager {
    const val ACTION_ALARM = "com.omik.assistant.ALARM"

    private fun pi(c: Context, id: Int, title: String, text: String): PendingIntent {
        val i = Intent(c, AlarmReceiver::class.java)
        i.action = ACTION_ALARM
        i.putExtra("id", id)
        i.putExtra("title", title)
        i.putExtra("text", text)
        return PendingIntent.getBroadcast(c, id, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    fun schedule(c: Context, id: Int, time: Long, title: String, text: String) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val p = pi(c, id, title, text)
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, p)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, p)
            }
        } catch (e: Exception) {
            try { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, time, p) } catch (e2: Exception) {}
        }
    }

    fun cancel(c: Context, id: Int) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        try { am.cancel(pi(c, id, "", "")) } catch (e: Exception) {}
    }

    fun rescheduleAll(c: Context) {
        val store = ReminderStore(c)
        for (r in store.all()) {
            if (r.time > System.currentTimeMillis()) {
                schedule(c, r.id, r.time, "أوميك بيفكرك ⏰", r.text)
            }
        }
        scheduleDaily(c)
    }

    fun scheduleDaily(c: Context) {
        // birthdays check at 10:00
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.HOUR_OF_DAY, 10); cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        if (cal.timeInMillis < System.currentTimeMillis()) cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
        schedule(c, 777001, cal.timeInMillis, "أوميك", "birthday_check")
        // adhkar
        if (Prefs.adhkarEnabled) {
            val m = java.util.Calendar.getInstance()
            m.set(java.util.Calendar.HOUR_OF_DAY, 7); m.set(java.util.Calendar.MINUTE, 30); m.set(java.util.Calendar.SECOND, 0)
            if (m.timeInMillis < System.currentTimeMillis()) m.add(java.util.Calendar.DAY_OF_YEAR, 1)
            schedule(c, 777002, m.timeInMillis, "أذكار الصباح ☀", "morning_adhkar")
            val e = java.util.Calendar.getInstance()
            e.set(java.util.Calendar.HOUR_OF_DAY, 18); e.set(java.util.Calendar.MINUTE, 30); e.set(java.util.Calendar.SECOND, 0)
            if (e.timeInMillis < System.currentTimeMillis()) e.add(java.util.Calendar.DAY_OF_YEAR, 1)
            schedule(c, 777003, e.timeInMillis, "أذكار المساء 🌙", "evening_adhkar")
        }
        // prayer reminders
        if (Prefs.prayerRemindEnabled) {
            val loc = PrayerTimes.location(c)
            val d = PrayerTimes.compute(loc.first, loc.second)
            val times = listOf(d.fajr, d.dhuhr, d.asr, d.maghrib, d.isha)
            val names = listOf("الفجر", "الظهر", "العصر", "المغرب", "العشاء")
            val cal2 = java.util.Calendar.getInstance()
            for (i in times.indices) {
                val t = java.util.Calendar.getInstance()
                val h = times[i].toInt(); val m2 = ((times[i] - h) * 60).toInt()
                t.set(java.util.Calendar.HOUR_OF_DAY, h); t.set(java.util.Calendar.MINUTE, m2); t.set(java.util.Calendar.SECOND, 0)
                if (t.timeInMillis > cal2.timeInMillis) {
                    schedule(c, 778000 + i, t.timeInMillis, "حان الان وقت صلاه ${names[i]} 🕌", "prayer")
                }
            }
        }
        // study slots
        val ss = StudyStore(c)
        val dayMap = mapOf(1 to java.util.Calendar.SATURDAY, 2 to java.util.Calendar.SUNDAY, 3 to java.util.Calendar.MONDAY,
            4 to java.util.Calendar.TUESDAY, 5 to java.util.Calendar.WEDNESDAY, 6 to java.util.Calendar.THURSDAY, 7 to java.util.Calendar.FRIDAY)
        for (s in ss.all()) {
            val t = java.util.Calendar.getInstance()
            t.set(java.util.Calendar.DAY_OF_WEEK, dayMap[s.dayOfWeek] ?: java.util.Calendar.SATURDAY)
            t.set(java.util.Calendar.HOUR_OF_DAY, s.hour); t.set(java.util.Calendar.MINUTE, s.minute); t.set(java.util.Calendar.SECOND, 0)
            while (t.timeInMillis < System.currentTimeMillis()) t.add(java.util.Calendar.DAY_OF_YEAR, 7)
            schedule(c, 779000 + s.id % 9000, t.timeInMillis, "وقت حصه ${s.subject} 📚", "study_${s.id}")
        }
    }
}
