package com.omik.assistant

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipFile

// imports model zips (LLM .gguf/.task/.litertlm, Vosk folder) from device storage into app files
object ModelManager {

    // returns user-facing status message
    fun importZip(c: Context, uri: Uri, kind: String): String {
        return try {
            val cacheZip = File(c.cacheDir, "import_$kind.zip")
            c.contentResolver.openInputStream(uri)?.use { inp ->
                FileOutputStream(cacheZip).use { out -> inp.copyTo(out) }
            } ?: return "مش قادر افتح الملف ده 🥲"
            val r = importFile(c, cacheZip, kind)
            cacheZip.delete()
            r
        } catch (e: Throwable) {
            "حصلت مشكلة في الاستيراد: ${e.message ?: "غير معروف"}"
        }
    }

    fun importFile(c: Context, zipFile: File, kind: String): String {
        return try {
            val dest = File(c.filesDir, kind)
            dest.deleteRecursively()
            dest.mkdirs()
            ZipFile(zipFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val e = entries.nextElement()
                    val out = File(dest, e.name)
                    if (e.isDirectory) { out.mkdirs(); continue }
                    out.parentFile?.mkdirs()
                    zip.getInputStream(e).use { inp ->
                        FileOutputStream(out).use { o -> inp.copyTo(o) }
                    }
                }
            }
            if (kind == "llm") {
                val model = findFile(dest, listOf(".gguf", ".task", ".litertlm"))
                    ?: return "الملف اتفك بس ملقيتش جواه موديل (.gguf او .task او .litertlm) 🥲"
                Prefs.llmModelPath = model.absolutePath
                Prefs.llmModelType = if (model.name.endsWith(".gguf")) "gguf" else "litert"
                LlmEngine.unload()
                "تمام يا دودو! موديل الذكاء اتربط ✅ (${model.name})"
            } else {
                val root = findVoskRoot(dest)
                    ?: return "الملف اتفك بس مش باين موديل Vosk جواه 🥲"
                Prefs.voskModelPath = root.absolutePath
                "تمام يا دودو! موديل الصوت Vosk اتربط ✅"
            }
        } catch (e: Throwable) {
            "حصلت مشكلة في الاستيراد: ${e.message ?: "غير معروف"}"
        }
    }

    private fun findFile(dir: File, exts: List<String>): File? {
        dir.walkTopDown().forEach { f -> if (f.isFile && exts.any { f.name.endsWith(it) }) return f }
        return null
    }

    private fun findVoskRoot(dir: File): File? {
        // a vosk model dir contains am/ + conf/ or ivector/ etc; find deepest dir containing "conf"
        dir.walkTopDown().forEach { f ->
            if (f.isDirectory && File(f, "conf").isDirectory) return f
        }
        // fallback: first single child dir
        val kids = dir.listFiles()?.filter { it.isDirectory } ?: emptyList()
        return kids.firstOrNull()
    }

    // downloads a model zip from url into cache then imports; calls cb(msg) on ui-safe thread runner
    fun downloadAndImport(c: Context, url: String, kind: String, cb: (String) -> Unit) {
        Thread {
            try {
                val out = File(c.cacheDir, "dl_$kind.zip")
                java.net.URL(url).openStream().use { inp ->
                    FileOutputStream(out).use { o -> inp.copyTo(o) }
                }
                val msg = importFile(c, out, kind)
                out.delete()
                cb(msg)
            } catch (e: Throwable) {
                cb("التحميل فشل: ${e.message ?: "شيكي النت"}")
            }
        }.start()
    }
}
