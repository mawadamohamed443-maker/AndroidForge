package com.omik.assistant

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.TextView

object ChatStore { val items = mutableListOf<ChatMsg>() }

class ChatAdapter(private val inflater: LayoutInflater) : BaseAdapter() {
    val items get() = ChatStore.items

    override fun getCount(): Int = items.size
    override fun getItem(position: Int): Any = items[position]
    override fun getItemId(position: Int): Long = position.toLong()
    override fun getViewTypeCount(): Int = 2
    override fun getItemViewType(position: Int): Int = if (items[position].isUser) 1 else 0

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val type = getItemViewType(position)
        val v = convertView ?: inflater.inflate(
            if (type == 1) R.layout.item_chat_user else R.layout.item_chat_omik, parent, false)
        v.findViewById<TextView>(R.id.msg).text = items[position].text
        return v
    }

    fun add(m: ChatMsg) { items.add(m); notifyDataSetChanged() }
    fun updateLast(text: String) {
        if (items.isNotEmpty()) { items[items.size - 1].text = text; notifyDataSetChanged() }
    }
}
