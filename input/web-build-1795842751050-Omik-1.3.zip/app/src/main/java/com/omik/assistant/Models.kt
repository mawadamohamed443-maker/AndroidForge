package com.omik.assistant

data class Person(
    var id: String = "",
    var name: String = "",
    var phone: String = "",
    var relation: String = "",
    var birthday: String = "",
    var photo: String = "",
    var voice: String = ""
)

data class Reminder(var id: Int = 0, var text: String = "", var time: Long = 0L)
data class NoteItem(var id: Long = 0L, var text: String = "", var date: String = "")
data class StudySlot(var id: Int = 0, var subject: String = "", var dayOfWeek: Int = 1, var hour: Int = 16, var minute: Int = 0)
data class ChatMsg(var text: String, var isUser: Boolean)
