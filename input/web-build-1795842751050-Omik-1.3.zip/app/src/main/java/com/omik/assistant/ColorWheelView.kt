package com.omik.assistant

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

class ColorWheelView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    var onColor: ((Int) -> Unit)? = null
    private var bitmap: Bitmap? = null
    private var selX = -1f; private var selY = -1f
    private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 4f; color = Color.WHITE
    }

    private fun build(w: Int, h: Int) {
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val cx = w / 2f; val cy = h / 2f; val r = min(cx, cy)
        for (y in 0 until h) {
            for (x in 0 until w) {
                val dx = x - cx; val dy = y - cy
                val d = sqrt(dx * dx + dy * dy)
                if (d <= r) {
                    val hue = ((Math.toDegrees(atan2(dy, dx).toDouble()) + 360) % 360).toFloat()
                    val sat = (d / r).coerceIn(0f, 1f)
                    bmp.setPixel(x, y, Color.HSVToColor(floatArrayOf(hue, sat, 1f)))
                }
            }
        }
        bitmap = bmp
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) { build(w / 2, h / 2) }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        bitmap?.let { canvas.drawBitmap(it, null, android.graphics.Rect(0, 0, width, height), null) }
        if (selX >= 0) canvas.drawCircle(selX, selY, 12f, marker)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                val cx = width / 2f; val cy = height / 2f
                val dx = event.x - cx; val dy = event.y - cy
                val d = sqrt(dx * dx + dy * dy)
                val r = min(cx, cy)
                if (d <= r) {
                    selX = event.x; selY = event.y
                    val hue = ((Math.toDegrees(atan2(dy, dx).toDouble()) + 360) % 360).toFloat()
                    val sat = (d / r).coerceIn(0f, 1f)
                    onColor?.invoke(Color.HSVToColor(floatArrayOf(hue, sat, 1f)))
                    invalidate()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
