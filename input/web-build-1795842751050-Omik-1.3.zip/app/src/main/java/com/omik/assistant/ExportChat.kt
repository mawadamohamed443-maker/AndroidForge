package com.omik.assistant

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore

fun exportChatFile(c: Context, items: List<ChatMsg>): String {
    if (items.isEmpty()) return "الشات فاضي لسه يا دودو 💬"
    val sb = StringBuilder()
    sb.append("<html dir='rtl'><head><meta charset='utf-8'><style>body{font-family:sans-serif;padding:20px;background:#111;color:#eee}.u{color:#6C8CFF}.o{color:#eee}.m{background:#1E1E1E;border-radius:12px;padding:10px;margin:8px 0}</style></head><body>")
    sb.append("<h2>شات أوميك 💙</h2>")
    for (m in items) {
        val who = if (m.isUser) "أنتي" else "أوميك"
        sb.append("<div class='m'><b class='${if (m.isUser) "u" else "o"}'>$who:</b> ${m.text.replace("\n", "<br>")}</div>")
    }
    sb.append("</body></html>")
    return try {
        val name = "omik-chat-${System.currentTimeMillis()}.html"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues()
            values.put(MediaStore.Downloads.DISPLAY_NAME, name)
            values.put(MediaStore.Downloads.MIME_TYPE, "text/html")
            val uri = c.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            c.contentResolver.openOutputStream(uri!!)?.use { it.write(sb.toString().toByteArray(Charsets.UTF_8)) }
        } else {
            @Suppress("DEPRECATION")
            val f = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), name)
            f.writeText(sb.toString(), Charsets.UTF_8)
        }
        "صدرت الشات في ملف HTML في الداونلود 📄 افتحيه من المتصفح واعملي حفظ PDF"
    } catch (e: Exception) { "مش قادر اصدر الشات، تأكدي من إذن التخزين" }
}
