package com.omik.assistant

import android.content.Context
import android.net.Uri

object PdfTool {
    fun extractText(c: Context, uri: Uri, maxChars: Int): String {
        return try {
            c.contentResolver.openInputStream(uri)?.use { ins ->
                com.tom_roush.pdfbox.pdmodel.PDDocument.load(ins).use { doc ->
                    com.tom_roush.pdfbox.text.PDFTextStripper().getText(doc).take(maxChars)
                }
            } ?: ""
        } catch (e: Exception) { "" }
    }
}
