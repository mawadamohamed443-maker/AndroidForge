package com.omik.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView

class PeopleActivity : Activity() {
    private lateinit var store: PeopleStore
    private lateinit var list: ListView
    private var people = mutableListOf<Person>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_people)
        store = PeopleStore(this)
        list = findViewById(R.id.list)
        reload()
        list.setOnItemClickListener { _, _, pos, _ ->
            val i = Intent(this, PersonEditActivity::class.java)
            i.putExtra("id", people[pos].id)
            startActivity(i)
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val p = people[pos]
            android.app.AlertDialog.Builder(this)
                .setTitle("حذف ${p.name}؟")
                .setPositiveButton("احذف") { _, _ -> store.delete(p.id); reload() }
                .setNegativeButton("لأ", null)
                .show()
            true
        }
    }

    override fun onResume() { super.onResume(); reload() }

    private fun reload() {
        people = store.all()
        list.adapter = object : BaseAdapter() {
            override fun getCount() = people.size
            override fun getItem(p: Int) = people[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(pos: Int, cv: View?, parent: ViewGroup): View {
                val v = cv ?: layoutInflater.inflate(R.layout.item_person, parent, false)
                val p = people[pos]
                v.findViewById<TextView>(R.id.name).text = p.name
                v.findViewById<TextView>(R.id.info).text =
                    listOf(p.relation, p.phone, if (p.birthday.isNotEmpty()) "🎂 ${p.birthday}" else "")
                        .filter { it.isNotEmpty() }.joinToString(" • ")
                val iv = v.findViewById<ImageView>(R.id.photo)
                if (p.photo.isNotEmpty()) {
                    try { iv.setImageBitmap(BitmapFactory.decodeFile(p.photo)) } catch (e: Exception) {}
                }
                return v
            }
        }
        findViewById<Button>(R.id.btnAdd).setOnClickListener {
            startActivity(Intent(this, PersonEditActivity::class.java))
        }
    }
}
