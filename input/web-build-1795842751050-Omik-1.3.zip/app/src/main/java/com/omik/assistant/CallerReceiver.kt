package com.omik.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.telephony.TelephonyManager

class CallerReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (!Prefs.callerAnnounceEnabled) return
        if (i.action != TelephonyManager.ACTION_PHONE_STATE_CHANGED) return
        val state = i.getStringExtra(TelephonyManager.EXTRA_STATE)
        if (state == TelephonyManager.EXTRA_STATE_RINGING) {
            val num = i.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER) ?: ""
            val svc = Intent(c, CallerAnnounceService::class.java)
            svc.putExtra("number", num)
            try {
                if (android.os.Build.VERSION.SDK_INT >= 26) c.startForegroundService(svc) else c.startService(svc)
            } catch (e: Exception) {}
        }
    }
}
