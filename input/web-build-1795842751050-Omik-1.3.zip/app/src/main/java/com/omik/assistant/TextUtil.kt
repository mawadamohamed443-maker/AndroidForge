package com.omik.assistant

object TextUtil {
    fun norm(s: String): String {
        var t = s.lowercase()
        t = t.replace(Regex("[\\u064B-\\u0652\\u0670\\u0640]"), "")
        t = t.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ٱ', 'ا')
        t = t.replace('ة', 'ه').replace('ى', 'ي')
        t = t.replace('٠', '0').replace('١', '1').replace('٢', '2').replace('٣', '3').replace('٤', '4')
        t = t.replace('٥', '5').replace('٦', '6').replace('٧', '7').replace('٨', '8').replace('٩', '9')
        t = t.replace(Regex("\\s+"), " ").trim()
        return t
    }
    fun stripForSpeech(s: String): String {
        return s.replace(Regex("[^\\p{L}\\p{N}\\p{P}\\p{Z}]"), " ").replace(Regex("\\s+"), " ").trim()
    }
    fun isMostlyLatin(s: String): Boolean {
        var latin = 0; var arabic = 0
        for (ch in s) {
            if (ch in 'a'..'z' || ch in 'A'..'Z') latin++
            if (ch in '\u0600'..'\u06FF') arabic++
        }
        return latin > arabic && latin > 2
    }
    fun egyptDigits(n: Int): String = n.toString()
}
