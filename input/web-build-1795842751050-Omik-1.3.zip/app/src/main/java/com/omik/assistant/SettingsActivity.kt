package com.omik.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridLayout
import android.widget.RadioButton
import android.widget.SeekBar
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView

class SettingsActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        Prefs.init(this)

        // background
        val bgBlack = findViewById<RadioButton>(R.id.bgBlack)
        val bgWhite = findViewById<RadioButton>(R.id.bgWhite)
        if (Prefs.bgBlack) bgBlack.isChecked = true else bgWhite.isChecked = true
        bgBlack.setOnClickListener { Prefs.bgBlack = true }
        bgWhite.setOnClickListener { Prefs.bgBlack = false }

        // orb size
        val sizeSeek = findViewById<SeekBar>(R.id.orbSize)
        sizeSeek.progress = Prefs.orbSizeDp - 100
        sizeSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Prefs.orbSizeDp = p + 100 }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // color wheel
        val wheel = findViewById<ColorWheelView>(R.id.colorWheel)
        val hex = findViewById<EditText>(R.id.hexInput)
        hex.setText(String.format("#%06X", 0xFFFFFF and Prefs.orbColor))
        wheel.onColor = { c ->
            Prefs.orbColor = c
            hex.setText(String.format("#%06X", 0xFFFFFF and c))
        }
        hex.setOnEditorActionListener { v, _, _ ->
            try {
                val c = Color.parseColor(hex.text.toString().trim())
                Prefs.orbColor = c
            } catch (e: Exception) { }
            true
        }
        // preset colors
        val presets = intArrayOf(
            0xFF0B2FD6.toInt(), 0xFF1E88E5.toInt(), 0xFF00ACC1.toInt(), 0xFF00897B.toInt(),
            0xFF43A047.toInt(), 0xFF7CB342.toInt(), 0xFFC0CA33.toInt(), 0xFFFDD835.toInt(),
            0xFFFFB300.toInt(), 0xFFFB8C00.toInt(), 0xFFF4511E.toInt(), 0xFFE53935.toInt(),
            0xFFD81B60.toInt(), 0xFF8E24AA.toInt(), 0xFF5E35B1.toInt(), 0xFF3949AB.toInt(),
            0xFF6D4C41.toInt(), 0xFF757575.toInt(), 0xFF546E7A.toInt(), 0xFFFFFFFF.toInt(),
            0xFF000000.toInt(), 0xFF00E5FF.toInt(), 0xFF76FF03.toInt(), 0xFFFF4081.toInt()
        )
        val grid = findViewById<GridLayout>(R.id.presetGrid)
        for (c in presets) {
            val b = Button(this)
            val d = GradientDrawable()
            d.shape = GradientDrawable.OVAL
            d.setColor(c)
            d.setStroke(3, Color.WHITE)
            b.background = d
            val size = (40 * resources.displayMetrics.density).toInt()
            val lp = GridLayout.LayoutParams()
            lp.width = size; lp.height = size
            lp.setMargins(8, 8, 8, 8)
            b.layoutParams = lp
            b.setOnClickListener {
                Prefs.orbColor = c
                hex.setText(String.format("#%06X", 0xFFFFFF and c))
            }
            grid.addView(b)
        }

        // themes
        val themeDefault = findViewById<RadioButton>(R.id.themeDefault)
        val themeNight = findViewById<RadioButton>(R.id.themeNight)
        val themeSea = findViewById<RadioButton>(R.id.themeSea)
        val themeRamadan = findViewById<RadioButton>(R.id.themeRamadan)
        when (Prefs.theme) {
            "night" -> themeNight.isChecked = true
            "sea" -> themeSea.isChecked = true
            "ramadan" -> themeRamadan.isChecked = true
            else -> themeDefault.isChecked = true
        }
        themeDefault.setOnClickListener { Prefs.theme = "default" }
        themeNight.setOnClickListener { Prefs.theme = "night" }
        themeSea.setOnClickListener { Prefs.theme = "sea" }
        themeRamadan.setOnClickListener { Prefs.theme = "ramadan" }

        // voice
        val spinner = findViewById<Spinner>(R.id.voiceSpinner)
        val tts = TtsManager(this)
        val names = mutableListOf("تلقائي")
        val voiceNames = mutableListOf("")
        try {
            val t = TtsManager(this)
            Thread {
                Thread.sleep(1200)
                runOnUiThread {
                    for (n in t.arabicVoices()) { names.add(n); voiceNames.add(n) }
                    spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
                    val cur = voiceNames.indexOf(Prefs.voiceName)
                    if (cur >= 0) spinner.setSelection(cur)
                    t.shutdown()
                }
            }.start()
        } catch (e: Exception) { }
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
        spinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: android.widget.AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (pos < voiceNames.size) Prefs.voiceName = voiceNames[pos]
            }
            override fun onNothingSelected(p: android.widget.AdapterView<*>?) {}
        }

        val rateSeek = findViewById<SeekBar>(R.id.rateSeek)
        rateSeek.progress = ((Prefs.ttsRate - 0.5f) * 100).toInt()
        rateSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Prefs.ttsRate = 0.5f + p / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val pitchSeek = findViewById<SeekBar>(R.id.pitchSeek)
        pitchSeek.progress = ((Prefs.ttsPitch - 0.5f) * 100).toInt()
        pitchSeek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) { Prefs.ttsPitch = 0.5f + p / 100f }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })

        // model
        val modeOnline = findViewById<RadioButton>(R.id.modeOnline)
        val modeOffline = findViewById<RadioButton>(R.id.modeOffline)
        if (Prefs.onlineMode) modeOnline.isChecked = true else modeOffline.isChecked = true
        modeOnline.setOnClickListener { Prefs.onlineMode = true }
        modeOffline.setOnClickListener { Prefs.onlineMode = false }
        findViewById<EditText>(R.id.apiUrl).setText(Prefs.apiUrl)
        findViewById<EditText>(R.id.apiKey).setText(Prefs.apiKey)
        findViewById<EditText>(R.id.apiModel).setText(Prefs.apiModel)
        findViewById<EditText>(R.id.apiUrl).setOnFocusChangeListener { v, _ -> Prefs.apiUrl = (v as EditText).text.toString().trim() }
        findViewById<EditText>(R.id.apiKey).setOnFocusChangeListener { v, _ -> Prefs.apiKey = (v as EditText).text.toString().trim() }
        findViewById<EditText>(R.id.apiModel).setOnFocusChangeListener { v, _ -> Prefs.apiModel = (v as EditText).text.toString().trim() }

        // wake word
        val wakeSwitch = findViewById<Switch>(R.id.wakeSwitch)
        wakeSwitch.isChecked = Prefs.wakeEnabled
        wakeSwitch.setOnCheckedChangeListener { _, on ->
            Prefs.wakeEnabled = on
            if (on) WakeWordService.start(this) else WakeWordService.stop(this)
        }
        val wakeWordEt = findViewById<EditText>(R.id.wakeWord)
        wakeWordEt.setText(Prefs.wakeWord)
        wakeWordEt.setOnFocusChangeListener { v, _ ->
            val w = (v as EditText).text.toString().trim()
            if (w.isNotEmpty()) Prefs.wakeWord = w
        }

        // quiet mode
        val quietSwitch = findViewById<Switch>(R.id.quietSwitch)
        quietSwitch.isChecked = Prefs.quietEnabled
        quietSwitch.setOnCheckedChangeListener { _, on -> Prefs.quietEnabled = on }
        findViewById<EditText>(R.id.quietFrom).setText(Prefs.quietFrom)
        findViewById<EditText>(R.id.quietTo).setText(Prefs.quietTo)
        findViewById<EditText>(R.id.quietFrom).setOnFocusChangeListener { v, _ -> Prefs.quietFrom = (v as EditText).text.toString().trim() }
        findViewById<EditText>(R.id.quietTo).setOnFocusChangeListener { v, _ -> Prefs.quietTo = (v as EditText).text.toString().trim() }

        // notification reading
        val notifSwitch = findViewById<Switch>(R.id.notifSwitch)
        notifSwitch.isChecked = Prefs.notifReadEnabled
        notifSwitch.setOnCheckedChangeListener { _, on -> Prefs.notifReadEnabled = on }
        findViewById<Button>(R.id.btnNotifAccess).setOnClickListener {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        // caller announce
        val callerSwitch = findViewById<Switch>(R.id.callerSwitch)
        callerSwitch.isChecked = Prefs.callerAnnounceEnabled
        callerSwitch.setOnCheckedChangeListener { _, on -> Prefs.callerAnnounceEnabled = on }
        // prayer
        val prayerSwitch = findViewById<Switch>(R.id.prayerSwitch)
        prayerSwitch.isChecked = Prefs.prayerRemindEnabled
        prayerSwitch.setOnCheckedChangeListener { _, on ->
            Prefs.prayerRemindEnabled = on
            ReminderManager.scheduleDaily(this)
        }
        // adhkar
        val adhkarSwitch = findViewById<Switch>(R.id.adhkarSwitch)
        adhkarSwitch.isChecked = Prefs.adhkarEnabled
        adhkarSwitch.setOnCheckedChangeListener { _, on ->
            Prefs.adhkarEnabled = on
            ReminderManager.scheduleDaily(this)
        }
        // model imports
        findViewById<Button>(R.id.btnImportLlm).setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, 7)
        }
        findViewById<Button>(R.id.btnDownloadVosk).setOnClickListener {
            android.widget.Toast.makeText(this, "بنزّل موديل الصوت (158 ميجا)... ممكن ياخد دقايق", android.widget.Toast.LENGTH_LONG).show()
            ModelManager.downloadAndImport(this, "https://alphacephei.com/vosk/models/vosk-model-small-ar-tn-0.1-linto.zip", "vosk") { msg ->
                runOnUiThread {
                    android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
                    refreshModelStatus()
                }
            }
        }
        findViewById<Button>(R.id.btnImportVosk).setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
            i.addCategory(Intent.CATEGORY_OPENABLE)
            i.type = "*/*"
            startActivityForResult(i, 8)
        }
        // assistant default
        findViewById<Button>(R.id.btnAssistant).setOnClickListener {
            try {
                startActivity(Intent(Settings.ACTION_VOICE_INPUT_SETTINGS))
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
            }
        }
        // accessibility
        findViewById<Button>(R.id.btnAccessibility).setOnClickListener {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        // export chat shortcut: goes back to main
        findViewById<Button>(R.id.btnExport).setOnClickListener {
            val msg = exportChatFile(this, ChatStore.items)
            android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data?.data == null) return
        val kind = if (requestCode == 7) "llm" else if (requestCode == 8) "vosk" else return
        android.widget.Toast.makeText(this, "بستورد الموديل... ثانية واحدة", android.widget.Toast.LENGTH_LONG).show()
        Thread {
            val msg = ModelManager.importZip(this, data.data!!, kind)
            runOnUiThread {
                android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_LONG).show()
                refreshModelStatus()
            }
        }.start()
    }

    private fun refreshModelStatus() {
        findViewById<TextView>(R.id.llmStatus).text =
            if (Prefs.llmModelPath.isNotEmpty() && java.io.File(Prefs.llmModelPath).exists())
                "✅ موديل الذكاء متسجل: " + java.io.File(Prefs.llmModelPath).name
            else "⚠ مفيش موديل ذكاء أوفلاين. لو عندك ملف GGUF استورديه من الزرار فوق"
        findViewById<TextView>(R.id.voskStatus).text =
            if (Prefs.voskModelPath.isNotEmpty() && java.io.File(Prefs.voskModelPath).exists())
                "✅ موديل الصوت Vosk متسجل، الفهم الصوتي شغال أوفلاين"
            else "⚠ مفيش موديل صوت. الصوت شغال أونلاين بس، لو عندك Vosk zip استورديه"
    }

    override fun onResume() {
        super.onResume()
        val notifOn = try {
            Settings.Secure.getString(contentResolver, "enabled_notification_listeners")?.contains(packageName) == true
        } catch (e: Exception) { false }
        findViewById<TextView>(R.id.notifStatus).text =
            if (notifOn) "✅ قراءة الإشعارات متفعله" else "⚠ محتاج تفعيل قراءة الإشعارات من الزرار فوق"
        findViewById<TextView>(R.id.accessStatus).text =
            if (OmikAccessibilityService.isEnabled()) "✅ التحكم باللمس شغال" else "⚠ التحكم باللمس مش متفعل"
        refreshModelStatus()
    }
}
