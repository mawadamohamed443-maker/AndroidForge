package com.omik.assistant

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.provider.Settings

object DeviceCommands {

    fun openApp(c: Context, query: String): String {
        val pm = c.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = try { pm.queryIntentActivities(intent, 0) } catch (e: Exception) { emptyList() }
        val q = TextUtil.norm(query)
        val match = apps.firstOrNull {
            val label = TextUtil.norm(it.loadLabel(pm).toString())
            label.contains(q) || q.contains(label)
        }
        return if (match != null) {
            val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                c.startActivity(launch)
                "فتحت ${match.loadLabel(pm)} ✅"
            } else "مش قادر افتح ${match.loadLabel(pm)}"
        } else "مش لاقي تطبيق اسمه \"$query\" عندك. جربي تقولي اسمه بالانجليزي؟"
    }

    fun callPerson(a: Activity, p: Person): String {
        if (p.phone.isEmpty()) return "مفيش رقم محفوظ لـ ${p.name}. ضيفي الرقم من قسم الأشخاص."
        val num = p.phone.replace(Regex("[^0-9+]"), "")
        return try {
            if (Build.VERSION.SDK_INT < 23 || a.checkSelfPermission(Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED) {
                val i = Intent(Intent.ACTION_CALL, Uri.parse("tel:$num"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                a.startActivity(i)
                "برن علي ${p.name} دلوقتي 📞"
            } else {
                val i = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$num"))
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                a.startActivity(i)
                "جهزتليك الاتصال بـ ${p.name}، دوسي اتصال 📞"
            }
        } catch (e: Exception) { "مش قادر اتصل، جربي من التليفون العادي" }
    }

    fun openWhatsApp(c: Context, p: Person): String {
        if (p.phone.isEmpty()) return "مفيش رقم محفوظ لـ ${p.name}."
        var num = p.phone.replace(Regex("[^0-9]"), "")
        if (num.startsWith("00")) num = num.substring(2)
        if (num.startsWith("0") && num.length == 11) num = "2$num"
        return try {
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$num"))
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            "فتحت شات ${p.name} في واتساب 💬"
        } catch (e: Exception) { "واتساب مش متسطب عندك علي الموبايل" }
    }

    fun toggleTorch(c: Context, on: Boolean): String {
        return try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList[0], on)
            if (on) "نورت الكشاف 🔦" else "طفيت الكشاف"
        } catch (e: Exception) { "مش قادر اوصل للكشاف دلوقتي" }
    }

    fun volume(c: Context, dir: Int): String {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        return when (dir) {
            1 -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); "عليت الصوت 🔊" }
            -1 -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); "وطيت الصوت 🔉" }
            else -> { am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI); "كتمت الصوت 🔇" }
        }
    }

    fun openWifiPanel(a: Activity): String {
        return try {
            if (Build.VERSION.SDK_INT >= 29) a.startActivity(Intent(Settings.Panel.ACTION_WIFI))
            else a.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            "فتحتلك إعدادات الواي فاي، شغليه من هنا 📶"
        } catch (e: Exception) { "مش قادر افتح إعدادات الواي فاي" }
    }

    fun openBluetoothPanel(a: Activity): String {
        return try {
            a.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            "فتحتلك إعدادات البلوتوث 🅱"
        } catch (e: Exception) { "مش قادر افتح إعدادات البلوتوث" }
    }
}
