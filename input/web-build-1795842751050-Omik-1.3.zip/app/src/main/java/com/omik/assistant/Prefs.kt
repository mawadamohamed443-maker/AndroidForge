package com.omik.assistant

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private lateinit var sp: SharedPreferences
    fun init(c: Context) { sp = c.getSharedPreferences("omik_prefs", Context.MODE_PRIVATE) }

    var bgBlack: Boolean get() = sp.getBoolean("bg_black", true); set(v) = sp.edit().putBoolean("bg_black", v).apply()
    var orbSizeDp: Int get() = sp.getInt("orb_size", 220); set(v) = sp.edit().putInt("orb_size", v).apply()
    var orbColor: Int get() = sp.getInt("orb_color", 0xFF0B2FD6.toInt()); set(v) = sp.edit().putInt("orb_color", v).apply()
    var theme: String get() = sp.getString("theme", "default") ?: "default"; set(v) = sp.edit().putString("theme", v).apply()

    var voiceName: String get() = sp.getString("voice_name", "") ?: ""; set(v) = sp.edit().putString("voice_name", v).apply()
    var ttsRate: Float get() = sp.getFloat("tts_rate", 1.05f); set(v) = sp.edit().putFloat("tts_rate", v).apply()
    var ttsPitch: Float get() = sp.getFloat("tts_pitch", 0.95f); set(v) = sp.edit().putFloat("tts_pitch", v).apply()
    var muted: Boolean get() = sp.getBoolean("muted", false); set(v) = sp.edit().putBoolean("muted", v).apply()

    var onlineMode: Boolean get() = sp.getBoolean("online_mode", true); set(v) = sp.edit().putBoolean("online_mode", v).apply()
    var apiUrl: String get() = sp.getString("api_url", "") ?: ""; set(v) = sp.edit().putString("api_url", v).apply()
    var apiKey: String get() = sp.getString("api_key", "") ?: ""; set(v) = sp.edit().putString("api_key", v).apply()
    var apiModel: String get() = sp.getString("api_model", "") ?: ""; set(v) = sp.edit().putString("api_model", v).apply()

    var wakeEnabled: Boolean get() = sp.getBoolean("wake_enabled", false); set(v) = sp.edit().putBoolean("wake_enabled", v).apply()
    var wakeWord: String get() = sp.getString("wake_word", "اوميك") ?: "اوميك"; set(v) = sp.edit().putString("wake_word", v).apply()

    var quietEnabled: Boolean get() = sp.getBoolean("quiet_enabled", false); set(v) = sp.edit().putBoolean("quiet_enabled", v).apply()
    var quietFrom: String get() = sp.getString("quiet_from", "23:00") ?: "23:00"; set(v) = sp.edit().putString("quiet_from", v).apply()
    var quietTo: String get() = sp.getString("quiet_to", "07:00") ?: "07:00"; set(v) = sp.edit().putString("quiet_to", v).apply()

    var notifReadEnabled: Boolean get() = sp.getBoolean("notif_read", false); set(v) = sp.edit().putBoolean("notif_read", v).apply()
    var callerAnnounceEnabled: Boolean get() = sp.getBoolean("caller_announce", false); set(v) = sp.edit().putBoolean("caller_announce", v).apply()
    var prayerRemindEnabled: Boolean get() = sp.getBoolean("prayer_remind", false); set(v) = sp.edit().putBoolean("prayer_remind", v).apply()
    var adhkarEnabled: Boolean get() = sp.getBoolean("adhkar", false); set(v) = sp.edit().putBoolean("adhkar", v).apply()

    var quizPoints: Int get() = sp.getInt("quiz_points", 0); set(v) = sp.edit().putInt("quiz_points", v).apply()
    var quizSubject: String get() = sp.getString("quiz_subject", "") ?: ""; set(v) = sp.edit().putString("quiz_subject", v).apply()
    var quizIndex: Int get() = sp.getInt("quiz_index", -1); set(v) = sp.edit().putInt("quiz_index", v).apply()
    var quizWaiting: Boolean get() = sp.getBoolean("quiz_waiting", false); set(v) = sp.edit().putBoolean("quiz_waiting", v).apply()
    var challengeStreak: Int get() = sp.getInt("challenge_streak", 0); set(v) = sp.edit().putInt("challenge_streak", v).apply()
    var challengeLastDay: String get() = sp.getString("challenge_last", "") ?: ""; set(v) = sp.edit().putString("challenge_last", v).apply()

    var llmModelPath: String get() = sp.getString("llm_path", "") ?: ""; set(v) = sp.edit().putString("llm_path", v).apply()
    var llmModelType: String get() = sp.getString("llm_type", "") ?: ""; set(v) = sp.edit().putString("llm_type", v).apply()
    var voskModelPath: String get() = sp.getString("vosk_path", "") ?: ""; set(v) = sp.edit().putString("vosk_path", v).apply()

    var translateMode: Boolean get() = sp.getBoolean("translate_mode", false); set(v) = sp.edit().putBoolean("translate_mode", v).apply()
    var focusEndsAt: Long get() = sp.getLong("focus_ends", 0L); set(v) = sp.edit().putLong("focus_ends", v).apply()

    fun isQuietNow(): Boolean {
        if (!quietEnabled) return false
        return try {
            val now = java.util.Calendar.getInstance()
            val cur = now.get(java.util.Calendar.HOUR_OF_DAY) * 60 + now.get(java.util.Calendar.MINUTE)
            val f = quietFrom.split(":"); val t = quietTo.split(":")
            val from = f[0].toInt() * 60 + f[1].toInt()
            val to = t[0].toInt() * 60 + t[1].toInt()
            if (from <= to) cur in from..to else cur >= from || cur <= to
        } catch (e: Exception) { false }
    }
}
