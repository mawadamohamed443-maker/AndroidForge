package com.omik.assistant

import android.content.Intent
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tan

class Brain(private val ui: MainActivity) {

    interface ReplySink {
        fun onChunk(textSoFar: String)
        fun onDone(full: String)
        fun onFail()
    }

    private val c get() = ui
    private val people by lazy { PeopleStore(c) }
    private val reminders by lazy { ReminderStore(c) }
    private val notes by lazy { NoteStore(c, "notes") }
    private val journal by lazy { NoteStore(c, "journal") }
    private val health by lazy { NoteStore(c, "health") }
    private val memory by lazy { MemoryStore(c) }
    private val study by lazy { StudyStore(c) }

    fun respond(raw: String, sink: ReplySink) {
        val t = TextUtil.norm(raw)
        // pending quiz answer
        if (Prefs.quizWaiting) {
            val a = checkQuizAnswer(t)
            if (a != null) { instant(sink, a); return }
        }
        if (Prefs.translateMode && !t.startsWith("اقفل الترجمه") && !t.contains("اقفل الترجمه")) {
            translateText(raw, sink); return
        }
        val off = offline(t, raw)
        if (off != null) { instant(sink, off); return }
        if (TextUtil.isMostlyLatin(raw) && !Prefs.onlineMode) {
            instant(sink, "I'm offline now ya Dodo, turn on online mode from settings and I'll answer in English too 💙"); return
        }
        if (Prefs.onlineMode) {
            OnlineBrain.ask(raw, object : OnlineBrain.Sink {
                override fun onChunk(fullTextSoFar: String) = sink.onChunk(fullTextSoFar)
                override fun onDone(fullText: String) = sink.onDone(fullText)
                override fun onFail() = askLocalOrFallback(raw, sink)
            })
        } else {
            askLocalOrFallback(raw, sink)
        }
    }

    private fun instant(sink: ReplySink, text: String) {
        sink.onChunk(text); sink.onDone(text)
    }

    private fun askLocalOrFallback(raw: String, sink: ReplySink) {
        if (LlmEngine.available(c)) {
            sink.onChunk("ثانية واحدة بفكر أوفلاين... ⏳")
            LlmEngine.ask(c, raw, object : LlmEngine.Sink {
                override fun onChunk(fullTextSoFar: String) = sink.onChunk(fullTextSoFar)
                override fun onDone(fullText: String) = sink.onDone(fullText)
                override fun onFail() = instant(sink, offlineFallback(TextUtil.norm(raw)))
            })
        } else {
            instant(sink, offlineFallback(TextUtil.norm(raw)))
        }
    }

    private fun offlineFallback(t: String): String {
        return if (Prefs.onlineMode)
            "النت واقف دلوقتي يا دودو 🥲 جربي تاني بعد شويه، او شغلي الوضع الأوفلاين من الإعدادات واسأليني حاجه اعرفها."
        else
            "مش عارف اجاوب علي ده وانا أوفلاين يا دودو. جربي: سابقني، علمني برمجه، فكرني بحاجه، احسبلي، مواقيت الصلاه، او قولي 'تعرف تعمل ايه'. ولو شغلتي الأونلاين هجاوب علي اي حاجه 💙"
    }

    private fun offline(t: String, raw: String): String? {
        // greetings
        if (t.matches(Regex("^(السلام عليكم|عليكم السلام|اهلا|اهلين|هاي|هلو|صباح الخير|مساء الخير|ازيك|عامل ايه|عاملين ايه|صباح الفل|مساء الفل).*"))) {
            ui.orbHappy()
            return pick("اهلا يا دودو 💙 عامله ايه النهارده؟", "ازيك يا قمر 🌸 قوليلي محتاجه ايه", "نورتيني يا دودو، انا تحت امرك")
        }
        if (t.contains("شكرا") || t.contains("متشكره") || t.contains("تسلم")) {
            ui.orbHappy()
            return pick("العفو يا قمر 💙", "ولا يهمك، دا واجبي", "تسلميلي يا دودو")
        }
        if (t.contains("اسمك") || t.contains("مين انت") || t.contains("انت مين")) {
            return "انا ${Prefs.wakeWord}، مساعدك الشخصي المصري. برد بسرعه، بذاكر معاكي، وبنفذ اوامرك 💙"
        }
        if (t.contains("تعرف تعمل ايه") || t.contains("ساعدني") || t == "هيلب" || t == "مساعده") {
            return "اعرف اعمل حاجات كتير يا دودو:\n• كلميني صوت وافهمك وارد عليكي\n• افتح تطبيقات: افتح يوتيوب\n• كلم حد: رن علي ماما، افتح شات احمد\n• فكرني الساعه 7 اني اذاكر\n• سابقني وتحدي النهارده\n• علمني برمجه واحكيلي حكايه\n• مواقيت الصلاه واذكار الصباح والمساء\n• سجل ملاحظه، سجل يومياتي، سجل عرض للدكتور\n• احسبلي 15 في 4، حولي 5 كيلو لميل، ترجم hello\n• ابدا تركيز 25 دقيقه\n• ضيف حصه عربي يوم السبت الساعه 5\n• عيد ميلاد ماما، وضع الترجمه، صدر الشات، اقرا pdf\nوجوا الإعدادات: الوان الكرة وعجلة الالوان والثيمات والاصوات 💙"
        }
        // time & date
        if (t.contains("الساعه كام") || t.contains("الوقت كام")) {
            val cal = Calendar.getInstance()
            var h = cal.get(Calendar.HOUR); if (h == 0) h = 12
            val m = cal.get(Calendar.MINUTE)
            val ampm = if (cal.get(Calendar.AM_PM) == Calendar.AM) "صباحا" else "مساء"
            return "الساعه دلوقتي $h:${String.format("%02d", m)} $ampm ⏰"
        }
        if (t.contains("النهارده كام") || t.contains("التاريخ كام") || t.contains("احنا يوم ايه")) {
            val cal = Calendar.getInstance()
            val days = arrayOf("الاحد", "الاتنين", "التلات", "الاربع", "الخميس", "الجمعه", "السبت")
            val months = arrayOf("يناير", "فبراير", "مارس", "ابريل", "مايو", "يونيو", "يوليو", "اغسطس", "سبتمبر", "اكتوبر", "نوفمبر", "ديسمبر")
            return "النهارده ${days[cal.get(Calendar.DAY_OF_WEEK) - 1]} ${cal.get(Calendar.DAY_OF_MONTH)} ${months[cal.get(Calendar.MONTH)]} 📅"
        }
        // calculator
        calc(raw)?.let { return it }
        // translate single
        if (t.startsWith("ترجم ")) {
            val word = t.removePrefix("ترجم ").trim()
            val ar = ContentBanks.dictArEn[word]
            val en = ContentBanks.dictEnAr[word]
            return when {
                ar != null -> "$word بالانجليزي يعني $ar ✅"
                en != null -> "$word بالعربي يعني $en ✅"
                else -> null
            }
        }
        if (t.contains("وضع الترجمه") || t.contains("ترجمه حيه")) {
            Prefs.translateMode = true
            return "شغلت وضع الترجمه الحيه 🌍 قولي اي حاجه واهترجمها علطول. لما تخلصي قولي اقفل الترجمه"
        }
        if (t.contains("اقفل الترجمه")) {
            Prefs.translateMode = false
            return "قفلت وضع الترجمه 👍"
        }
        // device commands
        if (t.startsWith("افتح شات") || t.startsWith("كلم شات") || (t.contains("واتس") && t.contains("افتح"))) {
            val name = t.removePrefix("افتح شات").removePrefix("كلم شات").removePrefix("افتح واتساب").trim()
            val p = people.findByName(name)
            return if (p != null) DeviceCommands.openWhatsApp(c, p)
            else "مش لاقي حد اسمه \"$name\" في الأشخاص. ضيفيه الاول من قسم الأشخاص 👥"
        }
        if (t.startsWith("افتح ") || t.startsWith("شغل ")) {
            val app = t.removePrefix("افتح ").removePrefix("شغل ").trim()
            return DeviceCommands.openApp(c, app)
        }
        if (t.startsWith("رن علي") || t.startsWith("كلم ") || t.startsWith("اتصل ب") || t.startsWith("اتصل ")) {
            val name = t.removePrefix("رن علي").removePrefix("كلم").removePrefix("اتصل ب").removePrefix("اتصل").trim()
            val p = people.findByName(name)
            return if (p != null) DeviceCommands.callPerson(ui, p)
            else "مش لاقي حد اسمه \"$name\" في الأشخاص. ضيفيه الاول 👥"
        }
        if (t.contains("كشاف") || t.contains("الفلاش") || t == "نور") {
            val on = !(t.contains("طفي") || t.contains("اقفل") || t.contains("اقفلي"))
            return DeviceCommands.toggleTorch(c, on)
        }
        if (t.contains("واي فاي") || t.contains("الواي فاي")) return DeviceCommands.openWifiPanel(ui)
        if (t.contains("بلوتوث")) return DeviceCommands.openBluetoothPanel(ui)
        if (t.contains("علي الصوت") || t.contains("عليا الصوت")) return DeviceCommands.volume(c, 1)
        if (t.contains("وطي الصوت") || t.contains("وطيا الصوت")) return DeviceCommands.volume(c, -1)
        if (t.contains("اكتم الصوت") || t.contains("كتم الصوت")) return DeviceCommands.volume(c, 0)
        // accessibility
        if (t.contains("اقرا الشاشه") || t.contains("اقري الشاشه")) {
            val a = OmikAccessibilityService.instance
            return if (a == null) "شغلي خدمه التحكم الاول من الإعدادات ⚙ وبعدين هقرا الشاشه علطول"
            else "اللي علي الشاشه: " + a.readScreen()
        }
        if (t == "ارجع" || t == "ارجعي" || t.contains("زرار الرجوع")) {
            val a = OmikAccessibilityService.instance
            return if (a != null && a.back()) "رجعت ✅" else "شغلي التحكم من الإعدادات الاول"
        }
        if (t.contains("الرئيسيه") || t.contains("الهوم") || t == "البيت") {
            val a = OmikAccessibilityService.instance
            return if (a != null && a.home()) "في البيت 🏠" else "شغلي التحكم من الإعدادات الاول"
        }
        if (t.contains("التطبيقات المفتوحه") || t.contains("الاخيره")) {
            val a = OmikAccessibilityService.instance
            return if (a != null && a.recents()) "فتحت التطبيقات الاخيره ✅" else "شغلي التحكم من الإعدادات الاول"
        }
        if (t.contains("انزل تحت") || t.contains("انزلي تحت")) {
            val a = OmikAccessibilityService.instance
            return if (a != null && a.scroll(true)) "نزلت ⬇" else "شغلي التحكم من الإعدادات الاول"
        }
        if (t.contains("اطلع فوق") || t.contains("اطلعي فوق")) {
            val a = OmikAccessibilityService.instance
            return if (a != null && a.scroll(false)) "طلعت ⬆" else "شغلي التحكم من الإعدادات الاول"
        }
        // reminders
        if (t.startsWith("فكرني")) return addReminder(t)
        if (t.contains("عرض التذكيرات") || t.contains("التذكيرات") || t.contains("فكرني ب ايه")) {
            val list = reminders.all().filter { it.time > System.currentTimeMillis() }
            if (list.isEmpty()) return "مفيش تذكيرات يا دودو. قولي: فكرني الساعه 7 اني اذاكر ⏰"
            val df = java.text.SimpleDateFormat("EEEE h:mm a", java.util.Locale("ar"))
            return "تذكيراتك:\n" + list.sortedBy { it.time }.joinToString("\n") { "• ${it.text} — ${df.format(java.util.Date(it.time))}" }
        }
        if (t.contains("امسح التذكيرات") || t.contains("الغي التذكيرات")) {
            for (r in reminders.all()) ReminderManager.cancel(c, r.id)
            reminders.clear()
            return "مسحت كل التذكيرات ✅"
        }
        // birthday
        if (t.startsWith("عيد ميلاد ")) {
            val name = t.removePrefix("عيد ميلاد ").trim()
            val p = people.findByName(name)
            if (p == null) return "مش لاقي حد اسمه \"$name\" في الأشخاص"
            if (p.birthday.isEmpty()) return "مفيش عيد ميلاد محفوظ لـ ${p.name}. ضيفيه من قسم الأشخاص 🎂"
            val days = people.birthdaysToday()
            return if (days.any { it.id == p.id }) {
                ui.orbHappy()
                "النهارده عيد ميلاد ${p.name}!! 🎂🎉 ابعتلها: ${ContentBanks.birthdayWishes.random()}"
            } else {
                val left = people.nextBirthday(p)
                if (left >= 0) "عيد ميلاد ${p.name} يوم ${p.birthday}، فاضل عليه $left يوم 🎂 واقترح تكتبيلها: ${ContentBanks.birthdayWishes.random()}"
                else "عيد ميلاد ${p.name} يوم ${p.birthday} 🎂"
            }
        }
        if (t.contains("اعياد الميلاد")) {
            val list = people.all().filter { it.birthday.isNotEmpty() }
            if (list.isEmpty()) return "مفيش اعياد ميلاد محفوظه. ضيفي ناس من قسم الأشخاص 🎂"
            return "اعياد الميلاد المحفوظه:\n" + list.joinToString("\n") { "• ${it.name}: ${it.birthday}" }
        }
        // notes
        if (t.startsWith("سجل ملاحظه") || t.startsWith("سجلي ملاحظه")) {
            val note = raw.substringAfter("ملاحظة").substringAfter("ملاحظه").trim()
            if (note.isEmpty()) return "قولي الملاحظه بعد كلمه ملاحظه 📝"
            notes.add(note)
            return "سجلت الملاحظه 📝: $note"
        }
        if (t.contains("عرض الملاحظات") || t.contains("الملاحظات")) {
            val list = notes.all()
            if (list.isEmpty()) return "مفيش ملاحظات. قولي: سجل ملاحظه والي بعدها 📝"
            return "ملاحظاتك:\n" + list.takeLast(10).joinToString("\n") { "• ${it.text}" }
        }
        // journal
        if (t.startsWith("سجل يومياتي") || t.startsWith("سجلي يومياتي")) {
            val entry = raw.substringAfter("يومياتي").trim()
            if (entry.isEmpty()) return "احكيلي يومك واهو اكتبه 📖"
            journal.add(entry)
            return "كتبت يومياتك 📖 هتفضل محفوظه عندي دايما"
        }
        if (t.contains("اقرا يومياتي") || t.contains("يومياتي")) {
            val list = journal.all()
            if (list.isEmpty()) return "لسه مفيش يوميات. قولي: سجل يومياتي واحكيلي يومك 📖"
            return "اخر يومياتك:\n" + list.takeLast(3).joinToString("\n\n") { "📅 ${it.date}\n${it.text}" }
        }
        // health log
        if (t.startsWith("سجل عرض") || t.startsWith("سجلي عرض")) {
            val s = raw.substringAfter("عرض").trim()
            if (s.isEmpty()) return "قولي العرض اللي حاسه بيه عشان اسجله للدكتور 🩺"
            health.add(s)
            return "سجلتو يا دودو 🩺 هيبقي قدامك في قائمه الأعراض لما تروحي للدكتور. وطمني عليكي!"
        }
        if (t.contains("اعراضي") || t.contains("قائمه الاعراض")) {
            val list = health.all()
            if (list.isEmpty()) return "مفيش اعراض مسجله. ربنا يديم عليكي الصحه 💙"
            return "الأعراض اللي سجلتيها للدكتور:\n" + list.takeLast(10).joinToString("\n") { "• ${it.date}: ${it.text}" } + "\n\nمتنسيش تقوليها للدكتور 🩺"
        }
        // memory
        if (t.startsWith("افتكر ان") || t.startsWith("افتكري ان") || t.startsWith("خزن ") || t.startsWith("ذاكر ان")) {
            val fact = raw.substringAfter("ان").removePrefix("خزن").trim()
            if (fact.isEmpty()) return "قولي الحاجه اللي افتكرها بعد كلمه ان 🧠"
            memory.add(fact)
            return "تمام، افتكرت ان $fact 🧠"
        }
        if (t.contains("ايه اللي تعرفه عني") || t.contains("افتكر ايه عني")) {
            val list = memory.all()
            if (list.isEmpty()) return "لسه معرفش عنك حاجه. قوليلي: افتكر اني بحب الكشري مثلا 🧠"
            return "اللي اعرفه عنك يا دودو:\n" + list.joinToString("\n") { "• $it" }
        }
        // study schedule
        if (t.startsWith("ضيف حصه") || t.startsWith("ضيفي حصه")) {
            return addStudySlot(t)
        }
        if (t.contains("عرض جدولي") || t.contains("جدول المذاكره")) {
            val list = study.all()
            if (list.isEmpty()) return "مفيش جدول مذاكره. قولي: ضيف حصه عربي يوم السبت الساعه 5 📚"
            val days = arrayOf("", "السبت", "الاحد", "الاتنين", "التلات", "الاربع", "الخميس", "الجمعه")
            return "جدول مذاكرتك 📚:\n" + list.sortedWith(compareBy({ it.dayOfWeek }, { it.hour })).joinToString("\n") {
                "• ${it.subject} — ${days.getOrElse(it.dayOfWeek) { "?" }} الساعه ${it.hour}:${String.format("%02d", it.minute)}"
            }
        }
        // quiz
        if (t.startsWith("سابقني") || t.contains("مسابقه")) {
            val subject = ContentBanks.quiz.keys.firstOrNull { t.contains(it) } ?: "عامه"
            return startQuiz(subject)
        }
        if (t.contains("نقاطي")) return "نقاطك في المسابقه: ${Prefs.quizPoints} نقطه 🏆 وسلسله التحدي اليومي: ${Prefs.challengeStreak} يوم 🔥"
        if (t.contains("تحدي النهارده") || t.contains("التحدي اليومي")) return dailyChallenge()
        // story
        if (t.contains("احكيلي") || t.contains("حكايه") || t.contains("قصه")) {
            return ContentBanks.stories.random() + "\n\nتصبحي علي خير يا دودو 🌙💙"
        }
        // dhikr
        if (t.contains("اذكار الصباح")) return "اذكار الصباح ☀:\n" + ContentBanks.morningAdhkar.joinToString("\n\n") { "• $it" }
        if (t.contains("اذكار المساء")) return "اذكار المساء 🌙:\n" + ContentBanks.eveningAdhkar.joinToString("\n\n") { "• $it" }
        if (t.contains("ذكر") || t.contains("معلومه النهارده") || t.contains("حاجه حلوه")) {
            val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
            return "ذكر النهارده 💙:\n" + ContentBanks.dailyCards[day % ContentBanks.dailyCards.size]
        }
        // teach kotlin
        if (t.contains("علمني برمجه") || t.contains("علمني كوتلن") || t.contains("دروس برمجه")) {
            return "دروس كوتلن اللي اقدر اشرحهالك 📱:\n" + ContentBanks.lessons.mapIndexed { i, l -> "${i + 1}. ${l.first}" }.joinToString("\n") + "\n\nقولي: اشرحلي الدرس الاول مثلا"
        }
        if (t.startsWith("اشرحلي الدرس") || t.startsWith("اشرح الدرس")) {
            val num = Regex("\\d+").find(t)?.value?.toIntOrNull() ?: 1
            val lesson = ContentBanks.lessons.getOrNull(num - 1)
            return lesson?.second ?: "مفيش درس بالرقم ده، عندي 6 دروس 📱"
        }
        if (t.startsWith("اشرح الكود")) {
            val code = raw.substringAfter("الكود").trim()
            if (code.isEmpty()) return "ابعتي الكود بعد كلمه الكود وهشرحهولك 💻"
            val found = ContentBanks.kotlinExplainPatterns.filter { code.contains(it.first) }
            return if (found.isEmpty()) "الكود ده محتاج شرح اذكي مني، شغلي الأونلاين وهشرحه سطر سطر 💻"
            else "شرح الكود 💻:\n" + found.joinToString("\n") { "• ${it.first.trim()} ← ${it.second}" }
        }
        // themes
        if (t.startsWith("ثيم ") || t.contains("شغل ثيم")) {
            val theme = when {
                t.contains("ليل") -> "night"
                t.contains("بحر") -> "sea"
                t.contains("رمضان") -> "ramadan"
                else -> "default"
            }
            Prefs.theme = theme
            ui.applyTheme()
            return when (theme) {
                "night" -> "شغلت ثيم الليل 🌙"
                "sea" -> "شغلت ثيم البحر 🌊"
                "ramadan" -> "شغلت ثيم رمضان 🌙✨ رمضان كريم!"
                else -> "رجعت للثيم العادي 💙"
            }
        }
        // focus mode
        if (t.startsWith("ابدا تركيز") || t.contains("بومودورو") || t.contains("وقت مذاكره")) {
            val mins = Regex("\\d+").find(t)?.value?.toIntOrNull() ?: 25
            return startFocus(mins)
        }
        if (t.contains("وقف التركيز") || t.contains("اقفل التركيز")) {
            ReminderManager.cancel(c, 776001)
            Prefs.focusEndsAt = 0
            return "وقفت التركيز. برافو عليكي يا دودو 💪"
        }
        // prayer
        if (t.contains("مواقيت الصلاه") || t.contains("مواقيت الصلاه النهارده") || t == "الصلاه") {
            val loc = PrayerTimes.location(c)
            return PrayerTimes.todayText(loc.first, loc.second)
        }
        if (t.contains("الصلاه الجايه") || t.contains("الاذان الجاي")) {
            val loc = PrayerTimes.location(c)
            val np = PrayerTimes.nextPrayer(loc.first, loc.second)
            return "الصلاه الجايه ${np.first} الساعه ${PrayerTimes.fmt(np.second)} 🕌"
        }
        if (t.contains("القبله")) {
            val loc = PrayerTimes.location(c)
            val lat1 = Math.toRadians(loc.first); val lat2 = Math.toRadians(21.4225)
            val dlng = Math.toRadians(39.8262 - loc.second)
            val y = sin(dlng)
            val x = cos(lat1) * tan(lat2) - sin(lat1) * cos(dlng)
            val brg = (Math.toDegrees(atan2(y, x)) + 360) % 360
            return "القبله علي اتجاه ${brg.roundToInt()} درجه من الشمال 🕋 (من موقعك التقريبي)"
        }
        if (t.contains("فكرني بالاذان") || t.contains("شغل تنبيه الصلاه")) {
            Prefs.prayerRemindEnabled = true
            ReminderManager.scheduleDaily(c)
            return "شغلت تنبيه مواقيت الصلاه 🕌 هفكرك قبل كل صلاه"
        }
        // people
        if (t.contains("مين في الاشخاص") || t.contains("عرض الاشخاص")) {
            val list = people.all()
            if (list.isEmpty()) return "لسه مضفتيش حد. دوسي علي زرار الأشخاص فوق وضيفي ناسك 👥"
            return "الأشخاص اللي عندك:\n" + list.joinToString("\n") { "• ${it.name} (${it.relation})" }
        }
        if (t.contains("اكلم مين") || t.contains("اقترحلي حد")) {
            val list = people.all()
            if (list.isEmpty()) return "ضيفي ناسك الاول من قسم الأشخاص 👥"
            val p = list.random()
            return "ليه متكلميش ${p.name}؟ ${p.relation} واكيد هتفرح بيكي 💙 قولي: رن علي ${p.name}"
        }
        // wake word
        if (t.startsWith("غير اسمك ل") || t.startsWith("غيري اسمك ل")) {
            val name = raw.substringAfter(" ل ").trim()
            if (name.isEmpty()) return "قولي الاسم الجديد بعد كلمه ل"
            Prefs.wakeWord = name
            return "تمام! من دلوقتي اسمي $name 🎉 وهرد لما تناديني بيه"
        }
        // pdf reading
        if (t.contains("اقرا pdf") || t.contains("اقرا بي دي اف") || t.contains("اقرا الملف")) {
            ui.pickPdf()
            return "اختاري ملف الـ PDF وهقراهولك 📄"
        }
        // export
        if (t.contains("صدر الشات") || t.contains("تصدير الشات")) {
            return ui.exportChat()
        }
        return null
    }

    private fun pick(vararg s: String) = s.random()

    private fun addReminder(t: String): String {
        val now = Calendar.getInstance()
        var trigger = -1L
        var text = t.removePrefix("فكرني").removePrefix("فكريني").trim()
        // بعد X دقايق / ساعات
        val relMin = Regex("بعد\\s+(\\d+)\\s*(دقيقه|دقايق|د)").find(t)
        val relHour = Regex("بعد\\s+(\\d+)\\s*(ساعه|ساعات)").find(t)
        val atHour = Regex("الساعه\\s+(\\d+)").find(t)
        when {
            relMin != null -> {
                trigger = now.timeInMillis + relMin.groupValues[1].toLong() * 60000
                text = text.replace(relMin.value, "").trim()
            }
            relHour != null -> {
                trigger = now.timeInMillis + relHour.groupValues[1].toLong() * 3600000
                text = text.replace(relHour.value, "").trim()
            }
            atHour != null -> {
                var h = atHour.groupValues[1].toInt()
                if ((t.contains("بالليل") || t.contains("مساء") || t.contains("العصر") || t.contains("المغرب")) && h < 12) h += 12
                if (t.contains("الفجر") && h == 12) h = 0
                val target = Calendar.getInstance()
                target.set(Calendar.HOUR_OF_DAY, h); target.set(Calendar.MINUTE, 0); target.set(Calendar.SECOND, 0)
                if (t.contains("و نص")) target.set(Calendar.MINUTE, 30)
                if (target.timeInMillis <= now.timeInMillis) target.add(Calendar.DAY_OF_YEAR, 1)
                trigger = target.timeInMillis
                text = text.replace(atHour.value, "").replace(Regex("(و نص|صبح|الصبح|بالليل|مساء|العصر|المغرب)"), "").trim()
            }
        }
        text = text.removePrefix("اني").removePrefix("ان").removePrefix("ب").trim()
        if (trigger < 0) return "قولي الوقت كمان يا دودو، مثال: فكرني الساعه 7 بالليل اني اذاكر ⏰"
        if (text.isEmpty()) text = "تذكير"
        val r = Reminder(0, text, trigger)
        reminders.add(r)
        ReminderManager.schedule(c, r.id, r.time, "أوميك بيفكرك ⏰", r.text)
        val df = java.text.SimpleDateFormat("EEEE h:mm a", java.util.Locale("ar"))
        return "حاضر يا دودو، هفكرك ${df.format(java.util.Date(r.time))} انك $text ✅"
    }

    private fun addStudySlot(t: String): String {
        val subjects = listOf("عربي", "انجليزي", "تاريخ", "برمجه")
        val subject = subjects.firstOrNull { t.contains(it) } ?: t.split(" ").getOrElse(2) { "مذاكره" }
        val days = mapOf("السبت" to 1, "الاحد" to 2, "الاتنين" to 3, "التلات" to 4, "الاربع" to 5, "الخميس" to 6, "الجمعه" to 7)
        val day = days.entries.firstOrNull { t.contains(it.key) }?.value ?: 1
        var hour = Regex("الساعه\\s+(\\d+)").find(t)?.groupValues?.get(1)?.toIntOrNull() ?: 17
        if ((t.contains("بالليل") || t.contains("مساء") || t.contains("العصر")) && hour < 12) hour += 12
        val slot = StudySlot(0, subject, day, hour, 0)
        study.add(slot)
        ReminderManager.scheduleDaily(c)
        val dayNames = arrayOf("", "السبت", "الاحد", "الاتنين", "التلات", "الاربع", "الخميس", "الجمعه")
        return "ضفت حصه $subject يوم ${dayNames[day]} الساعه $hour 📚 هفكرك بيها كل اسبوع"
    }

    private fun startQuiz(subject: String): String {
        Prefs.quizSubject = subject
        Prefs.quizIndex = 0
        Prefs.quizWaiting = true
        val q = ContentBanks.quiz[subject]?.firstOrNull()
        return if (q == null) "مفيش اسئله في الماده دي" else
            "يلا بينا نسابق في $subject! 🏆 (عندك ${Prefs.quizPoints} نقطه)\n\nالسؤال الاول: ${q.first}"
    }

    private fun checkQuizAnswer(t: String): String? {
        val subject = Prefs.quizSubject
        val questions = ContentBanks.quiz[subject] ?: return null
        val idx = Prefs.quizIndex
        val q = questions.getOrNull(idx)
        if (q == null) { Prefs.quizWaiting = false; return null }
        val answer = t.removePrefix("اجابتي").removePrefix("الاجابه").trim()
        val correct = q.second.any { TextUtil.norm(it) == answer || answer.contains(TextUtil.norm(it)) || TextUtil.norm(it).contains(answer) && answer.length > 2 }
        val sb = StringBuilder()
        if (correct) {
            Prefs.quizPoints = Prefs.quizPoints + 10
            sb.append("صح يا بطل! 🎉 +10 نقطه\n")
        } else {
            sb.append("للاسف غلط 😅 الاجابه الصح: ${q.second.first()}\n")
        }
        val next = idx + 1
        if (next >= questions.size || next >= 5) {
            Prefs.quizWaiting = false
            sb.append("\nخلصت الجوله! نقاطك بقت ${Prefs.quizPoints} 🏆 قولي سابقني لو عايزه تكملي")
        } else {
            Prefs.quizIndex = next
            sb.append("\nالسؤال ${next + 1}: ${questions[next].first}")
        }
        return sb.toString()
    }

    private fun dailyChallenge(): String {
        val today = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        if (Prefs.challengeLastDay == today) return "خلصتي تحدي النهارده ✅ سلسلتك: ${Prefs.challengeStreak} يوم 🔥 تعالي بكره"
        val day = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val subjects = ContentBanks.quiz.keys.toList()
        val subject = subjects[day % subjects.size]
        Prefs.quizSubject = subject
        Prefs.quizIndex = day % (ContentBanks.quiz[subject]?.size ?: 1)
        Prefs.quizWaiting = true
        val q = ContentBanks.quiz[subject]!![Prefs.quizIndex]
        return "تحدي النهارده 🔥 ($subject):\n${q.first}"
    }

    private fun startFocus(mins: Int): String {
        Prefs.focusEndsAt = System.currentTimeMillis() + mins * 60000L
        ReminderManager.schedule(c, 776001, Prefs.focusEndsAt, "خلصت حصه التركيز! 🎉", "خدي بريك 5 دقايق يا بطلة")
        try {
            val nm = c.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= 23 && nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_PRIORITY)
                return "بدات حصه تركيز $mins دقيقه 🍅 كتمت الإشعارات، ركزي وانا معاكي!"
            }
        } catch (e: Exception) { }
        return "بدات حصه تركيز $mins دقيقه 🍅 هفكرك لما تخلص. (عشان اكتم الإشعارات كمان فعيلي إذن عدم الإزعاج من الإعدادات)"
    }

    fun endFocus() {
        if (Prefs.focusEndsAt > 0 && System.currentTimeMillis() < Prefs.focusEndsAt) return
        try {
            val nm = c.getSystemService(android.content.Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
            if (android.os.Build.VERSION.SDK_INT >= 23 && nm.isNotificationPolicyAccessGranted) {
                nm.setInterruptionFilter(android.app.NotificationManager.INTERRUPTION_FILTER_ALL)
            }
        } catch (e: Exception) { }
    }

    private fun translateText(raw: String, sink: ReplySink) {
        val t = TextUtil.norm(raw)
        if (!TextUtil.isMostlyLatin(raw)) {
            val words = t.split(" ")
            val translated = words.map { ContentBanks.dictArEn[it] ?: it }
            if (translated.any { it.matches(Regex("[a-zA-Z]+")) }) {
                instant(sink, "🌍 " + translated.joinToString(" "))
            } else if (Prefs.onlineMode) {
                OnlineBrain.ask("Translate to English only, no explanation: $raw", object : OnlineBrain.Sink {
                    override fun onChunk(f: String) = sink.onChunk("🌍 $f")
                    override fun onDone(f: String) = sink.onDone("🌍 $f")
                    override fun onFail() = instant(sink, "مش قادر اترجم دلوقتي 🥲")
                })
            } else instant(sink, "مش عارف الكلمه دي أوفلاين، شغلي الأونلاين للترجمه الكامله 🌍")
        } else {
            val words = raw.lowercase().split(" ")
            val translated = words.map { ContentBanks.dictEnAr[it] ?: it }
            if (translated.any { it.matches(Regex("[\\u0600-\\u06FF]+")) }) {
                instant(sink, "🌍 " + translated.joinToString(" "))
            } else if (Prefs.onlineMode) {
                OnlineBrain.ask("Translate to Egyptian Arabic only, no explanation: $raw", object : OnlineBrain.Sink {
                    override fun onChunk(f: String) = sink.onChunk("🌍 $f")
                    override fun onDone(f: String) = sink.onDone("🌍 $f")
                    override fun onFail() = instant(sink, "مش قادر اترجم دلوقتي 🥲")
                })
            } else instant(sink, "I don't know this word offline ya Dodo 🌍")
        }
    }

    private fun calc(raw: String): String? {
        var t = TextUtil.norm(raw)
        // conversions
        val conv = Regex("(\\d+(?:\\.\\d+)?)\\s*(كيلو|كيلوجرام|كجم|ميل|متر|كيلومتر|جنيه|باوند|رطل|ساعه|دقيقه|درجه|مئويه|فهرنهايت)\\s*(ل|ب)?\\s*(كيلو|كيلوجرام|كجم|ميل|متر|كيلومتر|باوند|رطل|ساعه|دقايق|دقيقه|مئويه|فهرنهايت)").find(t)
        if (conv != null) {
            val v = conv.groupValues[1].toDoubleOrNull() ?: return null
            val from = conv.groupValues[2]; val to = conv.groupValues[4]
            val result: Pair<Double, String>? = when {
                (from == "كيلو" || from == "كيلومتر") && to == "ميل" -> v * 0.621371 to "ميل"
                (from == "كيلو" || from == "كيلومتر") && to == "متر" -> v * 1000 to "متر"
                from == "ميل" && (to == "كيلو" || to == "كيلومتر") -> v * 1.60934 to "كيلومتر"
                (from == "كيلوجرام" || from == "كجم" || from == "كيلو") && (to == "باوند" || to == "رطل") -> v * 2.20462 to "باوند"
                (from == "باوند" || from == "رطل") && (to == "كيلوجرام" || to == "كجم" || to == "كيلو") -> v / 2.20462 to "كيلوجرام"
                from == "ساعه" && (to == "دقايق" || to == "دقيقه") -> v * 60 to "دقيقه"
                (from == "درجه" || from == "مئويه") && to == "فهرنهايت" -> v * 9 / 5 + 32 to "فهرنهايت"
                from == "فهرنهايت" && (to == "درجه" || to == "مئويه") -> (v - 32) * 5 / 9 to "مئويه"
                else -> null
            }
            if (result != null) {
                val nice = if (result.first == result.first.toLong().toDouble()) result.first.toLong().toString() else String.format("%.2f", result.first)
                return "$v $from = $nice ${result.second} ✅"
            }
        }
        // arithmetic
        val isCalc = t.startsWith("احسب") || t.startsWith("احسبلي") || t.matches(Regex("^[\\d+\\-*/x×÷\\s.()=]+$")) && t.any { it.isDigit() }
        if (!isCalc) return null
        var expr = t.removePrefix("احسبلي").removePrefix("احسب")
        expr = expr.replace("زائد", "+").replace("زايد", "+").replace("ناقص", "-")
            .replace("في", "*").replace("ضرب", "*").replace("x", "*").replace("×", "*")
            .replace("علي", "/").replace("قسمه", "/").replace("÷", "/")
            .replace(Regex("[^0-9+\\-*/.() ]"), "").replace("=", "").trim()
        if (expr.isEmpty() || !expr.any { it.isDigit() }) return null
        return try {
            val result = evalExpr(expr)
            val nice = if (result == result.toLong().toDouble()) result.toLong().toString() else String.format("%.4f", result).trimEnd('0').trimEnd('.')
            "$expr = $nice ✅"
        } catch (e: Exception) { "مش فاهم المساله دي يا دودو 😅 جربي: احسبلي 15 في 4" }
    }

    private fun evalExpr(expr: String): Double {
        val tokens = Regex("\\d+\\.?\\d*|[+\\-*/()]").findAll(expr).map { it.value }.toList()
        return parseExpr(tokens, intArrayOf(0))
    }

    private fun parseExpr(tokens: List<String>, pos: IntArray): Double {
        var v = parseTerm(tokens, pos)
        while (pos[0] < tokens.size && (tokens[pos[0]] == "+" || tokens[pos[0]] == "-")) {
            val op = tokens[pos[0]++]; val r = parseTerm(tokens, pos)
            v = if (op == "+") v + r else v - r
        }
        return v
    }

    private fun parseTerm(tokens: List<String>, pos: IntArray): Double {
        var v = parseFactor(tokens, pos)
        while (pos[0] < tokens.size && (tokens[pos[0]] == "*" || tokens[pos[0]] == "/")) {
            val op = tokens[pos[0]++]; val r = parseFactor(tokens, pos)
            v = if (op == "*") v * r else v / r
        }
        return v
    }

    private fun parseFactor(tokens: List<String>, pos: IntArray): Double {
        val tk = tokens[pos[0]++]
        if (tk == "(") { val v = parseExpr(tokens, pos); if (pos[0] < tokens.size && tokens[pos[0]] == ")") pos[0]++; return v }
        if (tk == "-") return -parseFactor(tokens, pos)
        return tk.toDouble()
    }
}
