package com.omik.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) {
            ReminderManager.rescheduleAll(c)
            if (Prefs.wakeEnabled) WakeWordService.start(c)
        }
    }
}
