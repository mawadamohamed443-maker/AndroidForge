package com.omik.assistant

import java.util.Calendar
import kotlin.math.*

object PrayerTimes {

    data class Day(val fajr: Double, val sunrise: Double, val dhuhr: Double, val asr: Double, val maghrib: Double, val isha: Double)
    val names = listOf("الفجر", "الشروق", "الظهر", "العصر", "المغرب", "العشاء")

    private fun julianDay(y: Int, m: Int, d: Int): Double {
        var yy = y; var mm = m
        if (mm <= 2) { yy -= 1; mm += 12 }
        val a = yy / 100
        val b = 2 - a + a / 4
        return floor(365.25 * (yy + 4716)) + floor(30.6001 * (mm + 1)) + d + b - 1524.5
    }

    private fun sunPosition(jd: Double): DoubleArray {
        val d = jd - 2451545.0
        val g = 357.529 + 0.98560028 * d
        val q = 280.459 + 0.98564736 * d
        val l = q + 1.915 * sin(Math.toRadians(g)) + 0.020 * sin(Math.toRadians(2 * g))
        val e = 23.439 - 0.00000036 * d
        var ra = Math.toDegrees(atan2(cos(Math.toRadians(e)) * sin(Math.toRadians(l)), cos(Math.toRadians(l)))) / 15.0
        ra = (ra + 24) % 24
        val decl = Math.toDegrees(asin(sin(Math.toRadians(e)) * sin(Math.toRadians(l))))
        val eqt = q / 15.0 - ra
        return doubleArrayOf(decl, (eqt + 24) % 24)
    }

    private fun hourAngle(lat: Double, decl: Double, angle: Double): Double {
        val cosH = (-sin(Math.toRadians(angle)) - sin(Math.toRadians(lat)) * sin(Math.toRadians(decl))) /
                (cos(Math.toRadians(lat)) * cos(Math.toRadians(decl)))
        if (cosH < -1 || cosH > 1) return Double.NaN
        return Math.toDegrees(acos(cosH)) / 15.0
    }

    fun compute(lat: Double, lng: Double, cal: Calendar = Calendar.getInstance()): Day {
        val jd = julianDay(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH) + 1, cal.get(Calendar.DAY_OF_MONTH))
        val tz = 2.0
        val sp = sunPosition(jd)
        val decl = sp[0]; val eqt = sp[1]
        val dhuhr = 12 + tz - lng / 15.0 - eqt
        val haFajr = hourAngle(lat, decl, 19.5)
        val haSunrise = hourAngle(lat, decl, 0.833)
        val haIsha = hourAngle(lat, decl, 17.5)
        val haAsr = run {
            val t = atan(1.0 / (1.0 + tan(Math.toRadians(abs(lat - decl)))))
            val angle = Math.toDegrees(t)
            hourAngle(lat, decl, -angle)
        }
        return Day(
            fix(dhuhr - haFajr), fix(dhuhr - haSunrise), fix(dhuhr),
            fix(dhuhr + haAsr), fix(dhuhr + haSunrise), fix(dhuhr + haIsha)
        )
    }

    private fun fix(h: Double): Double { var x = h % 24; if (x < 0) x += 24; return x }

    fun fmt(h: Double): String {
        var hh = h.toInt(); val mm = ((h - hh) * 60).roundToInt()
        val ampm = if (hh >= 12) "م" else "ص"
        hh %= 12; if (hh == 0) hh = 12
        return "$hh:${String.format("%02d", mm)} $ampm"
    }

    fun todayText(lat: Double, lng: Double): String {
        val d = compute(lat, lng)
        return "مواقيت الصلاه النهارده 🕌\nالفجر: ${fmt(d.fajr)}\nالشروق: ${fmt(d.sunrise)}\nالظهر: ${fmt(d.dhuhr)}\nالعصر: ${fmt(d.asr)}\nالمغرب: ${fmt(d.maghrib)}\nالعشاء: ${fmt(d.isha)}"
    }

    fun nextPrayer(lat: Double, lng: Double): Pair<String, Double> {
        val d = compute(lat, lng)
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) + cal.get(Calendar.MINUTE) / 60.0
        val times = listOf(d.fajr, d.sunrise, d.dhuhr, d.asr, d.maghrib, d.isha)
        for (i in times.indices) if (times[i] > now && i != 1) return names[i] to times[i]
        return names[0] to d.fajr
    }

    fun location(c: android.content.Context): Pair<Double, Double> {
        return try {
            val lm = c.getSystemService(android.content.Context.LOCATION_SERVICE) as android.location.LocationManager
            val loc = lm.getProviders(true).mapNotNull {
                try { lm.getLastKnownLocation(it) } catch (e: SecurityException) { null }
            }.maxByOrNull { it.time }
            if (loc != null) Pair(loc.latitude, loc.longitude) else Pair(30.0444, 31.2357)
        } catch (e: Exception) { Pair(30.0444, 31.2357) }
    }
}
