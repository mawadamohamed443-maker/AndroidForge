package com.omik.assistant

import android.app.Activity
import android.content.Intent
import android.graphics.BitmapFactory
import android.media.MediaRecorder
import android.media.MediaPlayer
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream

class PersonEditActivity : Activity() {
    private lateinit var store: PeopleStore
    private var person = Person()
    private var recorder: MediaRecorder? = null
    private var recording = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_person_edit)
        store = PeopleStore(this)
        val id = intent.getStringExtra("id")
        if (id != null) {
            store.all().firstOrNull { it.id == id }?.let { person = it }
        }
        val nameEt = findViewById<EditText>(R.id.name)
        val phoneEt = findViewById<EditText>(R.id.phone)
        val relEt = findViewById<EditText>(R.id.relation)
        val bdayEt = findViewById<EditText>(R.id.birthday)
        val photoBtn = findViewById<ImageButton>(R.id.photo)
        val voiceStatus = findViewById<TextView>(R.id.voiceStatus)
        nameEt.setText(person.name); phoneEt.setText(person.phone)
        relEt.setText(person.relation); bdayEt.setText(person.birthday)
        if (person.photo.isNotEmpty()) {
            try { photoBtn.setImageBitmap(BitmapFactory.decodeFile(person.photo)) } catch (e: Exception) {}
        }
        voiceStatus.text = if (person.voice.isNotEmpty()) "🎙 في بصمه صوت محفوظه" else "مفيش بصمه صوت لسه"

        photoBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(i, 42)
        }
        findViewById<Button>(R.id.btnRecord).setOnClickListener {
            if (!recording) startRecording(voiceStatus) else stopRecording(voiceStatus)
        }
        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            if (person.voice.isNotEmpty()) {
                try {
                    val mp = MediaPlayer()
                    mp.setDataSource(person.voice)
                    mp.prepare(); mp.start()
                } catch (e: Exception) { toast("مش قادر اشغل التسجيل") }
            } else toast("مفيش تسجيل لسه")
        }
        findViewById<Button>(R.id.btnDelete).setOnClickListener {
            if (person.id.isNotEmpty()) store.delete(person.id)
            finish()
        }
        findViewById<Button>(R.id.btnSave).setOnClickListener {
            person.name = nameEt.text.toString().trim()
            person.phone = phoneEt.text.toString().trim()
            person.relation = relEt.text.toString().trim()
            person.birthday = bdayEt.text.toString().trim()
            if (person.name.isEmpty()) { toast("اكتبي الاسم الاول"); return@setOnClickListener }
            store.upsert(person)
            toast("حفظت ${person.name} ✅")
            finish()
        }
    }

    private fun startRecording(status: TextView) {
        try {
            val f = File(filesDir, "voice_${System.currentTimeMillis()}.m4a")
            recorder = MediaRecorder()
            recorder?.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder?.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder?.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder?.setOutputFile(f.absolutePath)
            recorder?.prepare()
            recorder?.start()
            person.voice = f.absolutePath
            recording = true
            status.text = "🔴 بتسجل... دوسي تاني عشان توقفي"
            findViewById<Button>(R.id.btnRecord).text = "⏹ وقف التسجيل"
        } catch (e: Exception) { toast("محتاج إذن المايك") }
    }

    private fun stopRecording(status: TextView) {
        try { recorder?.stop(); recorder?.release() } catch (e: Exception) {}
        recorder = null
        recording = false
        status.text = "🎙 اتسجلت البصمه ✅"
        findViewById<Button>(R.id.btnRecord).text = "🎙 تسجيل بصمه الصوت"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK && data?.data != null) {
            try {
                val f = File(filesDir, "photo_${System.currentTimeMillis()}.jpg")
                contentResolver.openInputStream(data.data!!)?.use { input ->
                    FileOutputStream(f).use { out -> input.copyTo(out) }
                }
                person.photo = f.absolutePath
                findViewById<ImageButton>(R.id.photo).setImageBitmap(BitmapFactory.decodeFile(f.absolutePath))
            } catch (e: Exception) { toast("مش قادر احفظ الصوره") }
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
