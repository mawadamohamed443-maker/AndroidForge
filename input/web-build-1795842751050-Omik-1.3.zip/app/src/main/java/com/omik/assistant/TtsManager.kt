package com.omik.assistant

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

class TtsManager(context: Context) {
    private var tts: TextToSpeech? = null
    var ready = false
    var onDone: (() -> Unit)? = null

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("ar"))
                applyVoice()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { onDone?.invoke() }
                    @Deprecated("deprecated") override fun onError(id: String?) { onDone?.invoke() }
                })
                ready = true
            }
        }
    }

    fun applyVoice() {
        val t = tts ?: return
        val voices = t.voices ?: return
        val arabic = voices.filter { it.locale.language == "ar" }
        if (Prefs.voiceName.isNotEmpty()) {
            val chosen = arabic.firstOrNull { it.name == Prefs.voiceName }
            if (chosen != null) { t.voice = chosen; return }
        }
        val male = arabic.firstOrNull {
            it.name.contains("male", true) && !it.name.contains("female", true)
        } ?: arabic.firstOrNull { !it.name.contains("female", true) } ?: arabic.firstOrNull()
        if (male != null) t.voice = male
    }

    fun arabicVoices(): List<String> {
        return try {
            tts?.voices?.filter { it.locale.language == "ar" }?.map { it.name } ?: emptyList()
        } catch (e: Exception) { emptyList() }
    }

    fun speak(text: String, rateFactor: Float = 1f) {
        val t = tts ?: return
        if (Prefs.muted) { onDone?.invoke(); return }
        var rate = Prefs.ttsRate * rateFactor
        var pitch = Prefs.ttsPitch
        if (Prefs.isQuietNow()) { rate *= 0.92f; pitch *= 0.95f }
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        t.speak(TextUtil.stripForSpeech(text), TextToSpeech.QUEUE_FLUSH, null, "omik_utt")
    }

    fun stop() { tts?.stop() }
    fun shutdown() { tts?.stop(); tts?.shutdown() }
}
