package com.omik.assistant

import android.content.Context
import net.ladenthin.llama.LlamaModel
import net.ladenthin.llama.parameters.InferenceParameters
import net.ladenthin.llama.parameters.ModelParameters

// offline LLM. Supports GGUF (llama.cpp) and LiteRT/MediaPipe (.task/.litertlm).
// Lazy-loads on first use; any native failure flips broken and callers fall back.
object LlmEngine {

    interface Sink {
        fun onChunk(fullTextSoFar: String)
        fun onDone(fullText: String)
        fun onFail()
    }

    @Volatile private var gguf: LlamaModel? = null
    @Volatile private var litert: Any? = null // com.google.mediapipe.tasks.genai.llminference.LlmInference
    @Volatile private var broken = false

    fun available(c: Context): Boolean =
        !broken && Prefs.llmModelPath.isNotBlank() && java.io.File(Prefs.llmModelPath).isFile

    fun unload() {
        synchronized(this) {
            try { gguf?.close() } catch (t: Throwable) {}
            try { (litert as? com.google.mediapipe.tasks.genai.llminference.LlmInference)?.close() } catch (t: Throwable) {}
            gguf = null; litert = null; broken = false
        }
    }

    fun ask(c: Context, question: String, sink: Sink) {
        Thread {
            try {
                val prompt = "انتي اوميك، مساعدة ذكية بتتكلم بالعامية المصرية، ودودة وقصيرة في الكلام. جاوبي على السؤال ده:\n\n$question\n\nالاجابة:"
                if (Prefs.llmModelType == "litert") askLitert(c, prompt, sink) else askGguf(c, prompt, sink)
            } catch (t: Throwable) {
                broken = true
                sink.onFail()
            }
        }.start()
    }

    private fun askGguf(c: Context, prompt: String, sink: Sink) {
        var m = gguf
        if (m == null) {
            synchronized(this) {
                if (gguf == null) {
                    gguf = LlamaModel(
                        ModelParameters()
                            .setModel(Prefs.llmModelPath)
                            .setCtxSize(2048)
                            .setThreads(4)
                    )
                }
                m = gguf
            }
        }
        val sb = StringBuilder()
        val params = InferenceParameters(prompt).withNPredict(300).withTemperature(0.7f)
        for (out in m!!.generate(params)) {
            sb.append(out.text)
            sink.onChunk(sb.toString())
        }
        sink.onDone(sb.toString())
    }

    private fun askLitert(c: Context, prompt: String, sink: Sink) {
        var inf = litert as? com.google.mediapipe.tasks.genai.llminference.LlmInference
        if (inf == null) {
            synchronized(this) {
                if (litert == null) {
                    val options = com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions.builder()
                        .setModelPath(Prefs.llmModelPath)
                        .setMaxTokens(1024)
                        .build()
                    litert = com.google.mediapipe.tasks.genai.llminference.LlmInference.createFromOptions(c.applicationContext, options)
                }
                inf = litert as? com.google.mediapipe.tasks.genai.llminference.LlmInference
            }
        }
        val sb2 = StringBuilder()
        inf!!.generateResponseAsync(prompt,
            com.google.mediapipe.tasks.genai.llminference.ProgressListener<String> { partial, done ->
                sb2.append(partial)
                sink.onChunk(sb2.toString())
                if (done) sink.onDone(sb2.toString())
            })
    }
}
