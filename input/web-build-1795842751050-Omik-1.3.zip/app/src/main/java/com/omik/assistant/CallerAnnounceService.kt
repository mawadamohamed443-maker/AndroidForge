package com.omik.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder

class CallerAnnounceService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel("omik_caller", "المتصل", NotificationManager.IMPORTANCE_MIN))
        }
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, "omik_caller") else Notification.Builder(this)
        val notif = b.setSmallIcon(R.drawable.ic_stat).setContentTitle("أوميك").setContentText("بقولك مين بيتصل").build()
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(4, notif, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
            else if (Build.VERSION.SDK_INT >= 29) startForeground(4, notif, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL)
            else startForeground(4, notif)
        } catch (e: Exception) { try { startForeground(4, notif) } catch (e2: Exception) {} }
        val num = intent?.getStringExtra("number") ?: ""
        val name = if (num.isNotEmpty()) {
            PeopleStore(this).all().firstOrNull {
                it.phone.replace(Regex("[^0-9]"), "").takeLast(9) == num.replace(Regex("[^0-9]"), "").takeLast(9)
            }?.name
        } else null
        val tts = TtsManager(this)
        val text = if (name != null) "$name بيتصل بيكي يا دودو 📞" else "في حد بيتصل بيكي يا دودو 📞"
        android.os.Handler(mainLooper).postDelayed({
            tts.speak(text)
            android.os.Handler(mainLooper).postDelayed({
                tts.shutdown()
                try { stopSelf() } catch (e: Exception) {}
            }, 6000)
        }, 800)
        return START_NOT_STICKY
    }
}
