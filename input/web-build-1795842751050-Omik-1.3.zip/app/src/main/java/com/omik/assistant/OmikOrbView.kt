package com.omik.assistant

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

class OmikOrbView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    enum class State { IDLE, LISTENING, THINKING, SPEAKING, SLEEPING }

    private var state = State.IDLE
    private var baseColor = Prefs.orbColor
    private var voiceLevel = 0f
    private var dimmed = false
    private var time = 0f
    private var moodHueShift = 0f
    private var moodUntil = 0L

    private val particles = Array(48) {
        FloatArray(4).apply {
            this[0] = Random.nextFloat() * 360f
            this[1] = 0.55f + Random.nextFloat() * 0.7f
            this[2] = 0.5f + Random.nextFloat() * 1.6f
            this[3] = 0.3f + Random.nextFloat() * 0.7f
        }
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    fun setState(s: State) { state = s; invalidate() }
    fun setVoiceLevel(rms: Float) {
        voiceLevel = ((rms + 2f) / 12f).coerceIn(0f, 1f)
    }
    fun setColor(c: Int) { baseColor = c; invalidate() }
    fun setDim(d: Boolean) { dimmed = d; invalidate() }
    fun setMood(hueShift: Float, durationMs: Long) {
        moodHueShift = hueShift
        moodUntil = System.currentTimeMillis() + durationMs
    }

    private fun shiftedColor(c: Int, shift: Float): Int {
        if (shift == 0f) return c
        val hsv = FloatArray(3)
        Color.colorToHSV(c, hsv)
        hsv[0] = (hsv[0] + shift + 360f) % 360f
        return Color.HSVToColor(hsv)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (System.currentTimeMillis() > moodUntil) moodHueShift = 0f
        val w = width.toFloat(); val h = height.toFloat()
        val cx = w / 2f; val cy = h / 2f
        val maxR = Math.min(w, h) / 2f * 0.92f
        val color = shiftedColor(baseColor, moodHueShift)

        time += when (state) {
            State.THINKING -> 0.14f
            State.SPEAKING -> 0.09f
            State.LISTENING -> 0.06f
            State.SLEEPING -> 0.015f
            State.IDLE -> 0.04f
        }

        val breathe = when (state) {
            State.SPEAKING -> 1f + 0.22f * voiceLevel + 0.03f * sin(time * 3f)
            State.LISTENING -> 1f + 0.18f * voiceLevel
            State.THINKING -> 1f + 0.05f * sin(time * 6f)
            State.SLEEPING -> 0.82f + 0.02f * sin(time)
            State.IDLE -> 1f + 0.04f * sin(time * 1.5f)
        }
        val alpha = if (dimmed) 0.35f else 1f

        // glow
        val glowR = maxR * 1.35f * breathe
        val glowColor = Color.argb((60 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color))
        paint.shader = RadialGradient(cx, cy, glowR, intArrayOf(glowColor, Color.TRANSPARENT), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, glowR, paint)
        paint.shader = null

        // particles
        val speedMul = when (state) { State.THINKING -> 3f; State.SPEAKING -> 1.8f; else -> 1f }
        for (p in particles) {
            p[0] = (p[0] + p[2] * speedMul) % 360f
            val rad = maxR * p[1] * breathe
            val px = cx + rad * cos(Math.toRadians(p[0].toDouble())).toFloat()
            val py = cy + rad * sin(Math.toRadians(p[0].toDouble())).toFloat()
            val a = (p[3] * 160 * alpha).toInt()
            paint.color = Color.argb(a, Color.red(color), Color.green(color), Color.blue(color))
            paint.style = Paint.Style.FILL
            canvas.drawCircle(px, py, 2.2f + p[3] * 2.5f, paint)
        }

        // core
        val coreR = maxR * 0.62f * breathe
        val light = Color.argb((255 * alpha).toInt(),
            Math.min(255, Color.red(color) + 70),
            Math.min(255, Color.green(color) + 70),
            Math.min(255, Color.blue(color) + 70))
        val dark = Color.argb((255 * alpha).toInt(), Color.red(color) / 2, Color.green(color) / 2, Color.blue(color) / 2)
        paint.shader = RadialGradient(cx - coreR * 0.25f, cy - coreR * 0.25f, coreR * 1.5f,
            intArrayOf(light, color, dark), null, Shader.TileMode.CLAMP)
        canvas.drawCircle(cx, cy, coreR, paint)
        paint.shader = null

        // ring for thinking
        if (state == State.THINKING) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 3f
            paint.color = Color.argb((180 * alpha).toInt(), Color.red(color), Color.green(color), Color.blue(color))
            val ringR = maxR * 0.8f
            canvas.save()
            canvas.rotate(time * 60f, cx, cy)
            canvas.drawArc(cx - ringR, cy - ringR, cx + ringR, cy + ringR, 0f, 90f, false, paint)
            canvas.drawArc(cx - ringR, cy - ringR, cx + ringR, cy + ringR, 180f, 90f, false, paint)
            canvas.restore()
            paint.style = Paint.Style.FILL
        }

        postInvalidateOnAnimation()
    }
}
