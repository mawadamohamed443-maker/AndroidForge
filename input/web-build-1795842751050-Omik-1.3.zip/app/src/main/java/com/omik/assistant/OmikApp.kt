package com.omik.assistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build

class OmikApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel("omik_reminders", "تذكيرات أوميك", NotificationManager.IMPORTANCE_HIGH))
            nm.createNotificationChannel(NotificationChannel("omik_wake", "كلمة النداء", NotificationManager.IMPORTANCE_MIN))
            nm.createNotificationChannel(NotificationChannel("omik_caller", "المتصل", NotificationManager.IMPORTANCE_MIN))
        }
        ReminderManager.rescheduleAll(this)
    }
}
