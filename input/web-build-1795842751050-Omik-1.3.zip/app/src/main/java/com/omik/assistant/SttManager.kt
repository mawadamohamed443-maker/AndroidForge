package com.omik.assistant

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

class SttManager(
    context: Context,
    private val onFinal: (String?) -> Unit,
    private val onRms: (Float) -> Unit,
    private val onPartial: (String) -> Unit
) {
    private var rec: SpeechRecognizer? = null
    private var voskService: org.vosk.android.SpeechService? = null
    private val appContext = context.applicationContext
    private val useVosk: Boolean = Prefs.voskModelPath.isNotEmpty() &&
            java.io.File(Prefs.voskModelPath).exists()

    private fun newIntent(): Intent {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
        i.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        return i
    }

    fun start() {
        if (useVosk) { startVosk(); return }
        try {
            rec?.destroy()
            rec = SpeechRecognizer.createSpeechRecognizer(appContext)
            rec?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) { onRms(rmsdB) }
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onError(error: Int) { onFinal(null) }
                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    onFinal(list?.firstOrNull())
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    val list = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val s = list?.firstOrNull()
                    if (!s.isNullOrEmpty()) onPartial(s)
                }
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            rec?.startListening(newIntent())
        } catch (e: Exception) { onFinal(null) }
    }

    private fun startVosk() {
        Thread {
            try {
                val model = org.vosk.Model(Prefs.voskModelPath)
                val recognizer = org.vosk.Recognizer(model, 16000.0f)
                val service = org.vosk.android.SpeechService(recognizer, 16000.0f)
                voskService = service
                service.startListening(object : org.vosk.android.RecognitionListener {
                    override fun onPartialResult(hypothesis: String?) {
                        val t = extractJson(hypothesis, "partial")
                        if (t.isNotEmpty()) onPartial(t)
                        onRms(6f)
                    }
                    override fun onResult(hypothesis: String?) {
                        val t = extractJson(hypothesis, "text")
                        onFinal(if (t.isEmpty()) null else t)
                    }
                    override fun onFinalResult(hypothesis: String?) {
                        val t = extractJson(hypothesis, "text")
                        if (t.isNotEmpty()) onFinal(t)
                    }
                    override fun onError(exception: Exception?) { onFinal(null) }
                    override fun onTimeout() { onFinal(null) }
                })
            } catch (e: Exception) { onFinal(null) }
        }.start()
    }

    private fun extractJson(h: String?, key: String): String {
        if (h == null) return ""
        return try {
            org.json.JSONObject(h).optString(key)
        } catch (e: Exception) { "" }
    }

    fun stop() {
        try { rec?.stopListening() } catch (e: Exception) {}
        try { voskService?.stop() } catch (e: Exception) {}
    }
    fun destroy() {
        try { rec?.destroy() } catch (e: Exception) {}
        rec = null
        try { voskService?.shutdown() } catch (e: Exception) {}
        voskService = null
    }
}
