# أوميك (Omik) — Android AI Assistant

Kotlin, no external dependencies (Android framework only).

- Build: AndroidForge or any Gradle 8.9 + JDK 17 + AGP 8.5.2 setup
- `gradlew` not included; system Gradle 8.9 is used: `gradle assembleRelease`
- Signed APK (release keystore `app/omik.jks` included, JKS format)
- minSdk 24, targetSdk 34
- See README-اقراني.txt for build steps in Arabic.
