package com.omik.assistant

import android.content.Context

// offline LLM via MediaPipe LiteRT (.task / .litertlm models).
// Lazy-loads on first use; any native failure flips broken and callers fall back.
object LlmEngine {

    interface Sink {
        fun onChunk(fullTextSoFar: String)
        fun onDone(fullText: String)
        fun onFail()
    }

    @Volatile private var litert: Any? = null // com.google.mediapipe.tasks.genai.llminference.LlmInference
    @Volatile private var broken = false

    fun available(c: Context): Boolean =
        !broken && Prefs.llmModelPath.isNotBlank() && java.io.File(Prefs.llmModelPath).isFile

    fun unload() {
        synchronized(this) {
            try { (litert as? com.google.mediapipe.tasks.genai.llminference.LlmInference)?.close() } catch (t: Throwable) {}
            litert = null; broken = false
        }
    }

    fun ask(c: Context, question: String, sink: Sink) {
        Thread {
            try {
                val prompt = "انتي اوميك، مساعدة ذكية بتتكلم بالعامية المصرية، ودودة وقصيرة في الكلام. جاوبي على السؤال ده:\n\n$question\n\nالاجابة:"
                var inf = litert as? com.google.mediapipe.tasks.genai.llminference.LlmInference
                if (inf == null) {
                    synchronized(this) {
                        if (litert == null) {
                            val options = com.google.mediapipe.tasks.genai.llminference.LlmInference.LlmInferenceOptions.builder()
                                .setModelPath(Prefs.llmModelPath)
                                .setMaxTokens(1024)
                                .build()
                            litert = com.google.mediapipe.tasks.genai.llminference.LlmInference.createFromOptions(c.applicationContext, options)
                        }
                        inf = litert as? com.google.mediapipe.tasks.genai.llminference.LlmInference
                    }
                }
                val sb2 = StringBuilder()
                inf!!.generateResponseAsync(prompt,
                    com.google.mediapipe.tasks.genai.llminference.ProgressListener<String> { partial, done ->
                        sb2.append(partial)
                        sink.onChunk(sb2.toString())
                        if (done) sink.onDone(sb2.toString())
                    })
            } catch (t: Throwable) {
                broken = true
                sink.onFail()
            }
        }.start()
    }
}
