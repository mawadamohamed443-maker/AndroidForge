package com.nico.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var brain: NicoBrain
    private lateinit var llm: LlmEngine
    private val pickLlm = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) installLlm(uri) }
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        brain = NicoBrain(this); llm = LlmEngine(this)
        log = findViewById(R.id.log); status = findViewById(R.id.status)
        scroll = findViewById(R.id.scroll); input = findViewById(R.id.input)

        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar", "EG")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (r < 0) tts?.setLanguage(Locale("ar"))
            }
        }
        requestPermissions(perms, 1)

        findViewById<Button>(R.id.btnPerm).setOnClickListener { requestPermissions(perms, 1) }
        findViewById<Button>(R.id.btnAcc).setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        findViewById<Button>(R.id.btnLlm).setOnClickListener { llmMenu() }
        findViewById<Button>(R.id.btnVoice).setOnClickListener { voiceMenu() }
        findViewById<Button>(R.id.btnMic).setOnClickListener { listen() }
        findViewById<Button>(R.id.btnSend).setOnClickListener { send() }
        input.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        add("نيكو: أهلا! اضغطي على المايك واتكلمي، أو اكتبي أمر.")
    }

    private fun send() { val t = input.text.toString().trim(); if (t.isNotEmpty()) { input.setText(""); process(t) } }

    private fun process(t: String) {
        add("أنتِ: $t")
        val r = try { brain.handle(t) } catch (e: Exception) { "حصل خطأ وأنا بنفذ الأمر: ${e.javaClass.simpleName}" }
        if (r != null) { if (r.isNotEmpty()) { add("نيكو: $r"); say(r) }; return }
        if (!llm.installed) {
            add("نيكو: معرفتش قصدك. علشان أجاوب على أي سؤال أوفلاين، ثبتي موديل الذكاء من زر \"الذكاء\".")
            return
        }
        status.text = "بفكر..."
        thread {
            val a = llm.ask(t)
            runOnUiThread { if (!isFinishing) { status.text = "نيكو"; add("نيكو: $a"); say(a) } }
        }
    }

    private fun llmMenu() {
        val items = arrayOf(
            if (llm.installed) "🔁 استبدال موديل الذكاء (ملف .task)" else "➕ تثبيت موديل الذكاء (ملف .task)",
            "🗑 حذف موديل الذكاء"
        )
        AlertDialog.Builder(this).setTitle("الذكاء الأوفلاين").setItems(items) { _, i ->
            if (i == 0) pickLlm.launch(arrayOf("*/*"))
            else { llm.release(); llm.modelFile.delete(); add("نيكو: اتمسح موديل الذكاء.") }
        }.show()
    }

    private fun installLlm(uri: Uri) {
        var name = "model.task"
        try { contentResolver.query(uri, null, null, null, null)?.use { if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = it.getString(i) ?: name } } } catch (_: Exception) {}
        if (!name.lowercase().endsWith(".task")) { add("نيكو: لازم الملف يكون بامتداد .task (موديل MediaPipe)."); return }
        status.text = "بنسخ موديل الذكاء..."
        thread {
            llm.release()
            val dst = llm.modelFile.apply { parentFile?.mkdirs() }
            val tmp = File(dst.parentFile, "model.tmp")
            val ok = try {
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o ->
                        val buf = ByteArray(1 shl 20); var total = 0L
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); total += n
                            if (total % (50L shl 20) < (1L shl 20)) runOnUiThread { status.text = "بنسخ… ${total / 1_000_000} MB" }
                        }
                    }
                    dst.delete(); tmp.renameTo(dst)
                } ?: false
            } catch (e: Exception) { tmp.delete(); false }
            if (ok) llm.setTemplateFrom(name)
            val err = if (ok) llm.load() else "النسخ فشل (مساحة التخزين كفاية؟)."
            runOnUiThread { status.text = "نيكو"; add(if (err == null) "نيكو: موديل الذكاء جاهز ✅ اسأليني أي حاجة." else "نيكو: $err") }
        }
    }

    private fun say(t: String) { tts?.speak(t.take(1500), TextToSpeech.QUEUE_FLUSH, null, "nico") }
    private fun add(t: String) { log.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    private fun listen(offline: Boolean = true) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            add("نيكو: اسمحي بإذن المايك الأول وبعدين اضغطي على المايك تاني.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { add("نيكو: الاستماع مش متاح على الجهاز ده."); return }
        tts?.stop(); sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "بسمعك..." }
                override fun onResults(r: Bundle?) {
                    status.text = "نيكو"
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
                }
                override fun onError(e: Int) {
                    status.text = "نيكو"
                    if (e == 12 || e == 13) add("نيكو: اللغة العربية مش منزلة أوفلاين. اضغطي زر \"العربي أوفلاين\" ونزّليها مرة واحدة.")
                    else add("نيكو: معرفتش أسمعك (كود $e)، جربي تاني.")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline))
        }
    }

    private fun voiceMenu() {
        val items = arrayOf("🎤 تحميل التعرف على الصوت العربي", "🔊 تحميل صوت النطق العربي", "⚙ إعدادات النطق")
        AlertDialog.Builder(this).setTitle("العربي أوفلاين").setItems(items) { _, i ->
            when (i) {
                0 -> { add("نيكو: في الشاشة اللي هتفتح اختاري Google، وبعدين ⚙ ثم اللغات ثم العربية (مصر) ونزّليها للاستخدام بدون إنترنت."); open("android.settings.VOICE_INPUT_SETTINGS") }
                1 -> open("android.speech.tts.engine.INSTALL_TTS_DATA")
                else -> open("com.android.settings.TTS_SETTINGS")
            }
        }.show()
    }

    private fun open(action: String) {
        try { startActivity(Intent(action)) } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    override fun onDestroy() { sr?.destroy(); tts?.shutdown(); super.onDestroy() }
}
