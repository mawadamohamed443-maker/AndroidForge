package com.nico.assistant

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class NicoAccessibilityService : AccessibilityService() {
    companion object { var inst: NicoAccessibilityService? = null }

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(intent: android.content.Intent?): Boolean { inst = null; return super.onUnbind(intent) }
    override fun onDestroy() { if (inst === this) inst = null; super.onDestroy() }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun global(action: Int) = performGlobalAction(action)

    // ---------- أدوات البحث في الشاشة ----------
    private fun roots(): List<AccessibilityNodeInfo> {
        val l = ArrayList<AccessibilityNodeInfo>()
        rootInActiveWindow?.let { l.add(it) }
        try { windows?.forEach { w -> w.root?.let { r -> if (l.none { it == r }) l.add(r) } } } catch (_: Exception) {}
        return l
    }

    private fun find(n: AccessibilityNodeInfo?, ok: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        if (n == null) return null
        if (ok(n)) return n
        for (i in 0 until n.childCount) find(n.getChild(i), ok)?.let { return it }
        return null
    }

    private fun center(n: AccessibilityNodeInfo): Pair<Int, Int> {
        val r = Rect(); n.getBoundsInScreen(r); return r.centerX() to r.centerY()
    }

    fun screenSize(): Pair<Int, Int> = resources.displayMetrics.widthPixels to resources.displayMetrics.heightPixels

    // ---------- إيماءات (ضغط / سحب / ضغط مطوّل) ----------
    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long): Boolean {
        if (Build.VERSION.SDK_INT < 24) return false
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        return dispatchGesture(g, null, null)
    }

    fun tap(x: Int, y: Int) = gesture(x.toFloat(), y.toFloat(), x.toFloat(), y.toFloat(), 60)
    fun longPress(x: Int, y: Int) = gesture(x.toFloat(), y.toFloat(), x.toFloat(), y.toFloat(), 800)
    fun doubleTap(x: Int, y: Int): Boolean { val a = tap(x, y); Thread.sleep(120); return tap(x, y) && a }
    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, dur: Long = 350) =
        gesture(x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat(), dur)

    /** d: U = صابعك يتحرك لفوق، D = لتحت، L = شمال، R = يمين */
    fun swipeDir(d: Char): Boolean {
        val (w, h) = screenSize()
        return when (d) {
            'U' -> swipe(w / 2, h * 3 / 4, w / 2, h / 4)
            'D' -> swipe(w / 2, h / 4, w / 2, h * 3 / 4)
            'L' -> swipe(w * 4 / 5, h / 2, w / 5, h / 2)
            'R' -> swipe(w / 5, h / 2, w * 4 / 5, h / 2)
            else -> false
        }
    }

    // ---------- ضغط على عناصر ----------
    private fun act(n: AccessibilityNodeInfo?, long: Boolean): Boolean {
        if (n == null) return false
        val want = if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK
        var c: AccessibilityNodeInfo? = n
        while (c != null) {
            if ((if (long) c.isLongClickable else c.isClickable) && c.performAction(want)) return true
            c = c.parent
        }
        val (x, y) = center(n)
        return if (long) longPress(x, y) else tap(x, y)
    }

    fun clickText(t: String, long: Boolean = false): Boolean {
        for (root in roots()) {
            for (n in root.findAccessibilityNodeInfosByText(t)) if (act(n, long)) return true
            val m = find(root) {
                (it.contentDescription?.toString() ?: "").contains(t, true) ||
                    ((if (Build.VERSION.SDK_INT >= 26) it.hintText?.toString() else null) ?: "").contains(t, true)
            }
            if (m != null && act(m, long)) return true
        }
        return false
    }

    fun clickFirstSwitch(want: Boolean?): Boolean {
        for (root in roots()) {
            val sw = find(root) {
                val cn = it.className?.toString() ?: ""
                cn.contains("Switch") || cn.contains("ToggleButton") || cn.contains("CheckBox")
            } ?: continue
            if (want != null && sw.isChecked == want) return true
            return act(sw, false)
        }
        return false
    }

    fun scroll(forward: Boolean): Boolean {
        val root = rootInActiveWindow
        val n = if (root != null) find(root) { it.isScrollable } else null
        if (n != null && n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return true
        return swipeDir(if (forward) 'U' else 'D')
    }

    // ---------- قراءة الشاشة ----------
    fun readScreen(max: Int = 1500): String {
        val sb = StringBuilder()
        fun go(n: AccessibilityNodeInfo?, d: Int) {
            if (n == null || sb.length > max || d > 40) return
            if (n.isVisibleToUser && !n.isPassword) {
                val t = n.text?.toString() ?: n.contentDescription?.toString()
                if (!t.isNullOrBlank()) sb.append(t.trim()).append("، ")
            }
            for (i in 0 until n.childCount) go(n.getChild(i), d + 1)
        }
        go(rootInActiveWindow, 0)
        return sb.toString().take(max)
    }

    fun currentPackage(): String = rootInActiveWindow?.packageName?.toString() ?: ""

    // ---------- الكتابة والتعديل ----------
    private fun input(): AccessibilityNodeInfo? {
        for (root in roots()) {
            val n = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: find(root) { it.isEditable }
            if (n != null) return n
        }
        return null
    }

    private fun setText(n: AccessibilityNodeInfo, t: CharSequence): Boolean {
        val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }

    fun typeText(t: String): Boolean {
        val n = input() ?: return false
        val hint = Build.VERSION.SDK_INT >= 26 && n.isShowingHintText
        val cur = if (hint) "" else (n.text?.toString() ?: "")
        return setText(n, cur + t)
    }

    fun clearText(): Boolean { val n = input() ?: return false; return setText(n, "") }

    fun selectAll(): Boolean {
        val n = input() ?: return false
        n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val len = n.text?.length ?: 0
        val b = Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, 0)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, len)
        }
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, b)
    }

    fun copy() = input()?.performAction(AccessibilityNodeInfo.ACTION_COPY) ?: false
    fun cut() = input()?.performAction(AccessibilityNodeInfo.ACTION_CUT) ?: false
    fun paste() = input()?.performAction(AccessibilityNodeInfo.ACTION_PASTE) ?: false

    fun pressEnter(): Boolean {
        val n = input() ?: return false
        return if (Build.VERSION.SDK_INT >= 30) n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id) else false
    }
}
