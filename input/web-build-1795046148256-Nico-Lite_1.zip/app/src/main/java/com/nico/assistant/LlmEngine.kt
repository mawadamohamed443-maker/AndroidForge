package com.nico.assistant

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** ذكاء اصطناعي محلي بالكامل (MediaPipe LLM) - بيجاوب على أي سؤال من غير نت. */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    private val history = ArrayList<Pair<String, String>>()
    private val prefs = ctx.getSharedPreferences("nico", Context.MODE_PRIVATE)

    var memory: String = ""
    var persona: String = ""
    fun seed(pairs: List<Pair<String, String>>) { synchronized(this) { history.clear(); history.addAll(pairs.takeLast(8)) } }

    val modelFile: File get() = File(ctx.filesDir, "llm/model.task")
    val installed: Boolean get() = modelFile.exists() && modelFile.length() > 1_000_000

    /** اسم الملف الأصلي بيحدد قالب المحادثة: gemma / qwen / plain */
    fun setTemplateFrom(fileName: String) {
        val n = fileName.lowercase()
        val t = when { "gemma" in n -> "gemma"; "qwen" in n -> "qwen"; else -> "plain" }
        prefs.edit().putString("llm_tpl", t).apply()
    }

    @Synchronized
    fun release() { try { llm?.close() } catch (_: Throwable) {}; llm = null; history.clear() }

    @Synchronized
    fun load(): String? {
        if (llm != null) return null
        if (!installed) return "مفيش موديل ذكاء مثبت."
        return try {
            val o = LlmInference.LlmInferenceOptions.builder()
                .setModelPath(modelFile.absolutePath)
                .setMaxTokens(1024)
                .build()
            llm = LlmInference.createFromOptions(ctx, o)
            null
        } catch (e: Throwable) {
            llm = null
            "فشل تحميل موديل الذكاء: ${e.message}"
        }
    }

    private val baseSystem = "أنت نيكو، صاحب ومساعد شخصي على موبايل المستخدم: خفيف الدم وبتهزر بذوق وبتتفاعل بمشاعر حقيقية. بتتكلم عامية مصرية طبيعية بجمل قصيرة وبتجاوب على أي سؤال في أي مجال باختصار ودقة. لو مش متأكد قول إنك مش متأكد ومتألفش. متستخدمش إيموجي ولا رموز لأن كلامك بيتنطق بصوت."
    private val system: String get() = baseSystem +
        (if (memory.isNotBlank()) "\nمعلومات عن المستخدم (هو اللي قالها): $memory" else "") +
        (if (persona.isNotBlank()) "\n$persona" else "")

    private fun prompt(q: String): String {
        val h = history.takeLast(4).map { it.first.take(500) to it.second.take(700) }
        return when (prefs.getString("llm_tpl", "plain")) {
            "qwen" -> buildString {
                append("<|im_start|>system\n$system<|im_end|>\n")
                h.forEach { append("<|im_start|>user\n${it.first}<|im_end|>\n<|im_start|>assistant\n${it.second}<|im_end|>\n") }
                append("<|im_start|>user\n$q<|im_end|>\n<|im_start|>assistant\n")
            }
            "gemma" -> buildString {
                var first = true
                h.forEach {
                    append("<start_of_turn>user\n${if (first) "$system\n\n" else ""}${it.first}<end_of_turn>\n<start_of_turn>model\n${it.second}<end_of_turn>\n")
                    first = false
                }
                append("<start_of_turn>user\n${if (first) "$system\n\n" else ""}$q<end_of_turn>\n<start_of_turn>model\n")
            }
            else -> buildString {
                append("$system\n\n")
                h.forEach { append("سؤال: ${it.first}\nالجواب: ${it.second}\n\n") }
                append("سؤال: $q\nالجواب:")
            }
        }
    }

    /** نادّيها من thread خلفي. */
    @Synchronized
    fun ask(q: String): String {
        load()?.let { return it }
        return try {
            var r = llm!!.generateResponse(prompt(q)).trim()
            r = r.replace("<end_of_turn>", "").replace("<|im_end|>", "").trim()
            if (r.isEmpty()) return "معرفتش أرد على ده."
            history.add(q to r)
            while (history.size > 8) history.removeAt(0)
            r
        } catch (e: Throwable) {
            "حصل خطأ في الذكاء: ${e.message}"
        }
    }
}
