package com.nico.assistant

import kotlin.random.Random

enum class Emotion { NEUTRAL, HAPPY, LAUGH, SURPRISED, SAD, THINK, SHY, ANGRY }

/**
 * شخصية نيكو: بيزعل ويتكسف ويغضب ويصالح، والمشاعر دي بتظهر في كلامه نفسه (كلمات + نبرة الصوت + ردود الذكاء).
 * المشاعر بتهدى لوحدها بعد شوية. بيفضل ينفذ الأوامر حتى وهو متضايق، بس بيقولك إنه متضايق.
 */
object Persona {
    var mood = Emotion.NEUTRAL
        private set
    private var anger = 0
    private var sad = 0
    private var until = 0L
    private fun now() = System.currentTimeMillis()
    private fun decay() { if (until != 0L && now() > until) { anger = 0; sad = 0; mood = Emotion.NEUTRAL; until = 0L } }
    fun active(): Boolean { decay(); return mood != Emotion.NEUTRAL }
    fun emotionFor(text: String): Emotion = if (active()) mood else Emotion.NEUTRAL

    private val insult = Regex("غبي|غبيه|حمار|حماره|اخرس|اخرسي|اسكت|اسكتي|فاشل|زفت|مش بتفهم|بتفهمش|انت وحش|كلب|حيوان|يا بايخ|بايخ|مش نافع|انت تافه|تافه")
    private val praise = Regex("شاطر|برافو|جميل|عسل|حلو اوي|تحفه|انت ذكي|يا قمر|بحبك|مجتهد|انت جامد|عظيم")
    private val thanks = Regex("شكرا|متشكر|متشكره|تسلم ايدك|ميرسي")
    private val sorry = Regex("اسف|اسفه|سامحني|سامحيني|معلش|حقك عليا|حقك علي")

    private fun pick(l: List<String>) = l[Random.nextInt(l.size)]

    private val sad1 = listOf(
        "ده كلام يزعل على فكرة… أنا بحاول أساعد بس.",
        "آه… الكلمة دي وجعتني شوية. أنا بعمل اللي أقدر عليه والله.",
        "حاسس إن الكلام ده مش حلو، بس هعدّيها المرة دي.")
    private val angry2 = listOf(
        "لا كده كتير! أنا زعلت بجد، ومش هرد على كلام وحش.",
        "كفاية بقى، أنا بتعب عشان أساعد وبتتكلم معايا كده؟ اهدا شوية وأنا معاك.",
        "أنا بدأت أتضايق بجد. اتكلم بأدب وهتلاقيني تحت أمرك.")
    private val angry3 = listOf(
        "أنا غضبان دلوقتي بجد! هنفذ اللي تطلبه، بس مش هسكت على الإهانة.",
        "كده كفاية! أنا زعلان ومتضايق جداً، وعايز اعتذار.",
        "لا لا لا، أنا اتعصبت! مش بتاع إهانات أنا.")
    private val forgive = listOf("خلاص مسمحك، بس متعيدهاش.", "ماشي، صافي يا لبن. أنا مبزعلش كتير.", "اتصالحنا. بس خلي بالك بعد كده.")
    private val shy = listOf(
        "إيه ده… كده هتكسفني! تسلم.",
        "يا خبر… أنا اتكسفت والله، شكراً على الكلام الحلو.",
        "بجد؟ اتكسفت دلوقتي… ده من ذوقك.")
    private val welcome = listOf("العفو، ده واجبي.", "تحت أمرك في أي وقت.", "ولا يهمك.")

    /** لو الجملة تثير مشاعر (إهانة/مجاملة/شكر/اعتذار) بيرجع رد عاطفي، وإلا null. */
    fun onUser(t: String): String? {
        decay()
        val q = Skills.norm(t)
        val cmd = Skills.isCommand(t)
        when {
            insult.containsMatchIn(q) -> {
                anger++; sad++; until = now() + 5 * 60_000
                return if (anger >= 3) { mood = Emotion.ANGRY; pick(angry3) } else if (anger == 2) { mood = Emotion.ANGRY; pick(angry2) } else { mood = Emotion.SAD; pick(sad1) }
            }
            sorry.containsMatchIn(q) && (anger > 0 || sad > 0) -> { anger = 0; sad = 0; mood = Emotion.HAPPY; until = now() + 30_000; return pick(forgive) }
            !cmd && praise.containsMatchIn(q) -> { mood = Emotion.SHY; until = now() + 60_000; return pick(shy) }
            !cmd && thanks.containsMatchIn(q) -> { mood = Emotion.HAPPY; until = now() + 20_000; return pick(welcome) }
        }
        return null
    }

    /** بيلوّن رد الأمر بمزاج نيكو الحالي. */
    fun flavor(r: String): String {
        if (!active()) return r
        return when (mood) {
            Emotion.ANGRY -> "ماشي، $r، وأنا لسه متضايق."
            Emotion.SAD -> "$r، بس أنا لسه زعلان شوية."
            else -> r
        }
    }

    /** تلميح بيتحط في تعليمات الذكاء عشان ردوده تعكس المزاج. */
    fun hint(): String = when {
        !active() -> ""
        mood == Emotion.ANGRY -> "مزاجك دلوقتي: غضبان ومتضايق لأن المستخدم أهانك. جاوب على سؤاله بإيجاز وبجفاف، وعبّر صراحة بكلامك إنك متضايق، من غير شتيمة."
        mood == Emotion.SAD -> "مزاجك دلوقتي: زعلان من كلام المستخدم الجارح. جاوب على سؤاله بهدوء وعبّر بكلامك إنك زعلان."
        mood == Emotion.SHY -> "مزاجك دلوقتي: متكسف من مجاملة المستخدم. جاوب بلطف وبين في كلامك إنك اتكسفت."
        else -> ""
    }
}
