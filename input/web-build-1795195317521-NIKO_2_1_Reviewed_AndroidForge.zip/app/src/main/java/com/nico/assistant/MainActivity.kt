package com.nico.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.provider.OpenableColumns
import android.provider.Settings
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.accessibilityservice.AccessibilityService
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import android.speech.tts.UtteranceProgressListener
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private lateinit var brain: NicoBrain
    private lateinit var llm: LlmEngine
    private lateinit var store: Store
    private lateinit var people: People
    private val agent by lazy { Agent(llm) }
    private val prefs by lazy { getSharedPreferences("nico", MODE_PRIVATE) }
    private var pendingPerson: Person? = null
    private val pickPhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> val p = pendingPerson; if (uri != null && p != null) savePhoto(p, uri) }
    private lateinit var orb: WaterOrbView
    private val h = android.os.Handler(android.os.Looper.getMainLooper())
    private val pickLlm = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) installLlm(uri) }
    private var tts: TextToSpeech? = null
    private var sr: SpeechRecognizer? = null
    private lateinit var log: TextView
    private lateinit var status: TextView
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private val perms = arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        brain = NicoBrain(this); llm = LlmEngine(this)
        log = findViewById(R.id.log); status = findViewById(R.id.status)
        scroll = findViewById(R.id.scroll); input = findViewById(R.id.input)
        store = Store(this); people = People(this); orb = findViewById(R.id.orb); orb.setOnClickListener { listen() }
        store.lines.takeLast(40).forEach { log.append(it + "\n\n") }
        llm.seed(store.pairs()); llm.memory = store.memoryText()

        tts = TextToSpeech(this) {
            if (it == TextToSpeech.SUCCESS) {
                val r = tts?.setLanguage(Locale("ar", "EG")) ?: TextToSpeech.LANG_NOT_SUPPORTED
                if (r < 0) tts?.setLanguage(Locale("ar"))
                tts?.let { Voices.apply(it, Langs.byCode("ar"), prefs); Voices.prosody(it, Emotion.NEUTRAL, prefs) }
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.SPEAKING } }
                    override fun onDone(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.IDLE } }
                    @Deprecated("Deprecated in Java") override fun onError(id: String?) { runOnUiThread { orb.state = WaterOrbView.State.IDLE } }
                })
            }
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener { settingsHub() }
        findViewById<android.widget.ImageButton>(R.id.btnMic).setOnClickListener { listen() }
        findViewById<Button>(R.id.btnSend).setOnClickListener { send() }
        input.setOnEditorActionListener { _, a, _ -> if (a == EditorInfo.IME_ACTION_SEND) { send(); true } else false }
        if (store.lines.isEmpty()) add("نيكو: أهلا! اضغطي على الكرة واتكلمي، أو اكتبي أمر.")
    }

    private fun send() { val t = input.text.toString().trim(); if (t.isNotEmpty()) { input.setText(""); process(t) } }

    private fun process(t: String) {
        add("أنتِ: $t")
        Persona.onUser(t)?.let { orb.feel(Persona.mood, 8000); reply(it); return }
        Skills.handle(t, store, this)?.let { llm.memory = store.memoryText(); reply(it); return }
        val steps = Skills.split(t)
        if (steps.size > 1) { add("نيكو: فهمت ${steps.size} خطوات، هنفذهم واحدة واحدة."); runPlan(steps, 0); return }
        runSingle(t)
    }

    private fun tryBrain(t0: String): String? {
        val t = Mix.normalize(t0)
        Mix.whatsapp(this, t, null, people)?.let { return it }
        Mix.tryOpen(this, t)?.let { return it }
        return try { brain.handle(t) } catch (e: Exception) { "حصل خطأ وأنا بنفذ الأمر: ${e.javaClass.simpleName}" }
    }

    private fun runSingle(t: String) {
        val r = tryBrain(t)
        if (r != null) { if (r.isNotEmpty()) reply(Persona.flavor(r)); return }
        if (Skills.isCommand(t) && agentReady()) { runAgent(t) {}; return }
        if (!llm.installed) {
            reply("معرفتش قصدك. علشان أجاوب على أي سؤال أوفلاين، ثبتي موديل الذكاء من زر \"الذكاء\".")
            return
        }
        status.text = "بفكر..."; orb.state = WaterOrbView.State.THINKING
        llm.memory = store.memoryText(); llm.persona = Persona.hint()
        thread {
            val a = llm.ask(t)
            runOnUiThread { if (!isFinishing) { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; reply(a) } }
        }
    }

    private fun runPlan(steps: List<String>, i: Int) {
        if (i >= steps.size) { reply("خلصت كل الخطوات."); return }
        val s = steps[i]
        add("نيكو: [${i + 1}/${steps.size}] $s")
        val r = tryBrain(s)
        if (r != null) { if (r.isNotEmpty()) add("نيكو: $r") } else add("نيكو: معرفتش أنفذ الخطوة دي.")
        h.postDelayed({ runPlan(steps, i + 1) }, 2500)
    }

    private fun llmMenu() {
        val items = arrayOf(
            if (llm.installed) "🔁 استبدال موديل الذكاء (.task)" else "➕ تثبيت موديل الذكاء (.task)",
            "🗑 حذف موديل الذكاء"
        )
        AlertDialog.Builder(this).setTitle("الذكاء الأوفلاين").setItems(items) { _, i ->
            if (i == 0) pickLlm.launch(arrayOf("*/*"))
            else { llm.release(); llm.modelFile.delete(); add("نيكو: اتمسح موديل الذكاء.") }
        }.show()
    }

    private fun installLlm(uri: Uri) {
        var name = "model.task"
        try { contentResolver.query(uri, null, null, null, null)?.use { if (it.moveToFirst()) { val i = it.getColumnIndex(OpenableColumns.DISPLAY_NAME); if (i >= 0) name = it.getString(i) ?: name } } } catch (_: Exception) {}
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext != "task") { add("نيكو: النسخة دي بتشغّل موديلات MediaPipe بصيغة .task فقط. ملف .litertlm محتاج محرك مختلف ومش هيتحمّل بالمحرك الحالي."); return }
        status.text = "بنسخ موديل الذكاء..."
        thread {
            llm.release()
            val dst = llm.targetFor(ext)
            val tmp = File(dst.parentFile, "copy.tmp")
            val ok = try {
                contentResolver.openInputStream(uri)?.use { i ->
                    tmp.outputStream().use { o ->
                        val buf = ByteArray(1 shl 20); var total = 0L
                        while (true) {
                            val n = i.read(buf); if (n < 0) break
                            o.write(buf, 0, n); total += n
                            if (total % (50L shl 20) < (1L shl 20)) runOnUiThread { status.text = "بنسخ… ${total / 1_000_000} MB" }
                        }
                    }
                    if (tmp.length() <= 1_000_000L) {
                        tmp.delete()
                        false
                    } else {
                        val backup = File(dst.parentFile, "model.previous")
                        if (backup.exists()) backup.delete()
                        val hadPrevious = dst.exists() && dst.renameTo(backup)
                        val moved = tmp.renameTo(dst)
                        if (moved) backup.delete() else if (hadPrevious) backup.renameTo(dst)
                        moved
                    }
                } ?: false
            } catch (e: Exception) { tmp.delete(); false }
            if (ok) llm.setTemplateFrom(name)
            val err = if (ok) llm.load() else "النسخ فشل (مساحة التخزين كفاية؟)."
            runOnUiThread { status.text = "نيكو"; add(if (err == null) "نيكو: موديل الذكاء جاهز ✅ اسأليني أي حاجة." else "نيكو: $err") }
        }
    }

    private fun say(t: String) {
        if (!prefs.getBoolean("speak", true)) return
        val engine = tts ?: return
        val e = Persona.emotionFor(t); orb.feel(e); Voices.prosody(engine, e, prefs)
        orb.state = WaterOrbView.State.SPEAKING
        engine.speak(t.take(1500), TextToSpeech.QUEUE_FLUSH, null, "nico")
    }
    private fun reply(t: String) { add("نيكو: $t"); say(t) }
    private fun add(t: String) { store.addLine(t); log.append(t + "\n\n"); scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) } }

    private fun listen(offline: Boolean = true) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            add("نيكو: اسمحي بإذن المايك الأول وبعدين اضغطي على المايك تاني.")
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { add("نيكو: الاستماع مش متاح على الجهاز ده."); return }
        tts?.stop(); sr?.destroy()
        sr = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(p: Bundle?) { status.text = "بسمعك..."; orb.state = WaterOrbView.State.LISTENING }
                override fun onResults(r: Bundle?) {
                    status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                    r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { process(it) }
                }
                override fun onError(e: Int) {
                    status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE
                    if (e == 12 || e == 13) add("نيكو: اللغة العربية مش منزلة أوفلاين. اضغطي زر \"العربي أوفلاين\" ونزّليها مرة واحدة.")
                    else add("نيكو: معرفتش أسمعك (كود $e)، جربي تاني.")
                }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) { orb.pulse((v / 10f).coerceIn(0f, 1f)) }
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-EG")
                .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, offline))
        }
    }

    private fun voiceMenu() {
        val items = arrayOf("🎤 تحميل التعرف على الصوت العربي", "🔊 تحميل صوت النطق العربي", "⚙ إعدادات النطق")
        AlertDialog.Builder(this).setTitle("العربي أوفلاين").setItems(items) { _, i ->
            when (i) {
                0 -> { add("نيكو: في الشاشة اللي هتفتح اختاري Google، وبعدين ⚙ ثم اللغات ثم العربية (مصر) ونزّليها للاستخدام بدون إنترنت."); open("android.settings.VOICE_INPUT_SETTINGS") }
                1 -> open("android.speech.tts.engine.INSTALL_TTS_DATA")
                else -> open("com.android.settings.TTS_SETTINGS")
            }
        }.show()
    }

    private fun open(action: String) {
        try { startActivity(Intent(action)) } catch (e: Exception) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (_: Exception) {}
        }
    }

    private fun askText(title: String, def: String, onOk: (String) -> Unit) {
        val e = EditText(this); e.setText(def)
        AlertDialog.Builder(this).setTitle(title).setView(e).setPositiveButton("حفظ") { _, _ -> onOk(e.text.toString().trim()) }.setNegativeButton("إلغاء", null).show()
    }

    private fun voicePickMenu() {
        val l = curLang; val vs = tts?.let { Voices.forLang(it, l) } ?: emptyList()
        if (vs.isEmpty()) { add("نيكو: مفيش أصوات للغة ${l.label}. نزّلي بيانات النطق من اللغات."); return }
        val names = vs.map { "${it.name}  ${if (it.isNetworkConnectionRequired) "(نت)" else "(أوفلاين)"}  جودة ${it.quality}" }
        AlertDialog.Builder(this).setTitle("صوت النطق (جودة أعلى = أطبيعي أكتر)").setItems(names.toTypedArray()) { _, i ->
            prefs.edit().putString("voice_${l.code}", vs[i].name).apply(); applyTts(); say("ده صوتي الجديد، عجبك؟")
        }.show()
    }

    private fun memoryMenu() {
        if (store.memories.isEmpty()) { AlertDialog.Builder(this).setTitle("الذاكرة 🧠").setMessage("فاضية. قولي لنيكو: \"افتكر إن ...\" وهيحفظها. وتقدري تمسحيها من هنا أو بـ \"انسى ...\".").setPositiveButton("تمام", null).show(); return }
        AlertDialog.Builder(this).setTitle("اللي نيكو فاكره عنك (اضغطي على واحدة لمسحها)")
            .setItems(store.memories.toTypedArray()) { _, i -> store.removeMemory(i); llm.memory = store.memoryText(); memoryMenu() }
            .setNeutralButton("مسح الكل") { _, _ -> confirm("مسح كل الذاكرة؟") { store.clearMemory(); llm.memory = "" } }
            .setPositiveButton("إغلاق", null).show()
    }

    private fun savePhoto(p: Person, uri: Uri) {
        thread {
            try {
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) } ?: return@thread
                val sq = Bitmap.createScaledBitmap(bmp, 256, 256, true)
                val f = File(filesDir, "people/${p.id}.jpg"); f.parentFile?.mkdirs()
                f.outputStream().use { sq.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                p.photo = f.absolutePath; people.save()
                runOnUiThread { add("نيكو: اتحفظت صورة ${p.name}."); peopleMenu() }
            } catch (e: Exception) { runOnUiThread { add("نيكو: معرفتش أحفظ الصورة.") } }
        }
    }

    private fun peopleMenu() {
        val list = people.list
        val lv = ListView(this)
        val ad = object : ArrayAdapter<Person>(this, 0, list) {
            override fun getView(pos: Int, cv: View?, parent: android.view.ViewGroup): View {
                val p = getItem(pos)!!
                val row = LinearLayout(context).apply { orientation = LinearLayout.HORIZONTAL; setPadding(24, 16, 24, 16); gravity = Gravity.CENTER_VERTICAL }
                val img = ImageView(context).apply { layoutParams = LinearLayout.LayoutParams(120, 120) }
                val bm = if (p.photo.isNotBlank()) BitmapFactory.decodeFile(p.photo) else null
                if (bm != null) img.setImageBitmap(bm) else img.setImageResource(android.R.drawable.ic_menu_myplaces)
                val tv = TextView(context).apply {
                    text = p.name + (if (p.owner) "  ⭐ المالك" else "") + "\n" + listOf(p.relation, p.phone.takeIf { it.isNotBlank() }?.let { "📱 رقم محفوظ" }, p.birthday.takeIf { it.isNotBlank() }?.let { "🎂 $it" }).filterNotNull().filter { it.isNotBlank() }.joinToString(" • ")
                    textSize = 17f; setPadding(24, 0, 0, 0)
                }
                row.addView(img); row.addView(tv); return row
            }
        }
        lv.adapter = ad
        val dlg = AlertDialog.Builder(this).setTitle("الأشخاص 👥 (${list.size})").setView(lv)
            .setPositiveButton("➕ شخص جديد") { _, _ -> askText("اسم الشخص", "") { n ->
                if (n.isNotBlank()) {
                    val created = people.add(n)
                    askText("صلة القرابة أو العلاقة (اختياري)", "") { rel ->
                        created.relation = rel
                        askText("عيد الميلاد (اختياري: يوم/شهر مثل 08/04)", "") { day ->
                            created.birthday = day; people.save(); personMenu(created)
                        }
                    }
                }
            } }
            .setNegativeButton("إغلاق", null).create()
        lv.setOnItemClickListener { _, _, i, _ -> dlg.dismiss(); personMenu(list[i]) }
        dlg.show()
    }

    private fun personMenu(p: Person) {
        val items = arrayOf("🖼 اختيار صورة", "📱 رقم الواتساب/الموبايل", "✏ تغيير الاسم", "👪 صلة القرابة: ${p.relation.ifBlank { "غير محددة" }}", "🎂 عيد الميلاد: ${p.birthday.ifBlank { "غير محدد" }}", "⭐ ${if (p.owner) "إلغاء" else "تعيين"} كمالك (صاحب الموبايل)", "🗑 حذف الشخص")
        AlertDialog.Builder(this).setTitle(p.name).setItems(items) { _, i ->
            when (i) {
                0 -> { pendingPerson = p; pickPhoto.launch(arrayOf("image/*")) }
                1 -> askText("رقم ${p.name} (مثال 01012345678)", p.phone) { v -> p.phone = v; people.save(); add("نيكو: اتحفظ الرقم. دلوقتي قولي: نيكو افتح شات ${p.name} واتساب."); peopleMenu() }
                2 -> askText("الاسم", p.name) { v -> if (v.isNotBlank()) { p.name = v; people.save() }; peopleMenu() }
                3 -> askText("صلة القرابة أو العلاقة", p.relation) { v -> p.relation = v; people.save(); personMenu(p) }
                4 -> askText("عيد الميلاد (يوم/شهر مثل 08/04)", p.birthday) { v -> p.birthday = v; people.save(); personMenu(p) }
                5 -> { val was = p.owner; people.list.forEach { it.owner = false }; p.owner = !was; people.save(); peopleMenu() }
                else -> confirm("حذف ${p.name}؟") { people.remove(p); peopleMenu() }
            }
        }.setNegativeButton("رجوع") { _, _ -> peopleMenu() }.show()
    }

    private fun <T> onMain(f: () -> T): T? {
        if (Looper.myLooper() == Looper.getMainLooper()) return f()
        var r: T? = null; val l = CountDownLatch(1)
        runOnUiThread { try { r = f() } catch (_: Throwable) {}; l.countDown() }
        l.await(6, TimeUnit.SECONDS); return r
    }

    private fun execAction(a: String, v: String): String = onMain {
        val acc = NicoAccessibilityService.inst
        when (a) {
            "open" -> brain.handle("افتح $v")?.ifBlank { null } ?: "فتحت $v"
            "click" -> if (acc?.clickText(v) == true) "ضغطت على \"$v\"" else "ملقيتش \"$v\" على الشاشة"
            "type" -> if (acc?.typeText(v) == true) "كتبت \"$v\"" else "ملقيتش خانة كتابة"
            "scroll" -> if (acc?.scroll(v != "up") == true) "سكرولت" else "معرفتش أسكرول"
            "back" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_BACK); "رجعت" }
            "home" -> { acc?.global(AccessibilityService.GLOBAL_ACTION_HOME); "روحت للرئيسية" }
            else -> "أمر غير معروف: $a"
        }
    } ?: "التنفيذ اتأخر"

    private fun runAgent(goal: String, done: () -> Unit) {
        status.text = "بنفذ..."; orb.state = WaterOrbView.State.THINKING
        llm.memory = store.memoryText()
        thread {
            val res = agent.run(goal, prefs.getBoolean("sens", false),
                screen = { onMain { NicoAccessibilityService.inst?.readScreen(1200) } ?: "" },
                pkg = { onMain { NicoAccessibilityService.inst?.currentPackage() } ?: "" },
                exec = { a, v -> execAction(a, v) },
                log = { s -> runOnUiThread { add("نيكو: $s") } })
            runOnUiThread { status.text = "نيكو"; orb.state = WaterOrbView.State.IDLE; reply(res); done() }
        }
    }

    private fun agentReady() = prefs.getBoolean("agent", true) && NicoAccessibilityService.inst != null && llm.installed

    private fun confirm(msg: String, ok: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg).setPositiveButton("أيوه") { _, _ -> ok() }.setNegativeButton("لا", null).show()
    }

    private fun clearChat() { store.clearHistory(); llm.clearHistory(); log.text = ""; add("نيكو: مسحت المحادثة.") }

    private val curLang get() = Langs.byCode("ar")

    private fun applyTts() { tts?.let { Voices.apply(it, curLang, prefs); Voices.prosody(it, Emotion.NEUTRAL, prefs) } }

    private fun settingsHub() {
        val entries = arrayOf(
            "👥 الأشخاص وجهات الاتصال",
            "🔐 الأذونات",
            "♿ التحكم في الهاتف",
            "🧠 الذكاء الاصطناعي والموديل",
            "🎙 اللغة والصوت",
            "💾 الذاكرة والمحادثات",
            "⚙ إعدادات نيكو",
            "🧹 مسح المحادثة"
        )
        AlertDialog.Builder(this)
            .setTitle("إعدادات نيكو")
            .setItems(entries) { _, which ->
                when (which) {
                    0 -> peopleMenu()
                    1 -> permissionsMenu()
                    2 -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                    3 -> llmMenu()
                    4 -> voiceMenu()
                    5 -> memoryMenu()
                    6 -> settingsMenu()
                    7 -> confirm("مسح المحادثة كلها؟") { clearChat() }
                }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun permissionsMenu() {
        val names = arrayOf("الميكروفون", "الاتصال الهاتفي", "جهات الاتصال")
        val granted = perms.map { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        val rows = names.indices.map { i -> "${if (granted[i]) "✓" else "○"} ${names[i]}" }.toTypedArray()
        AlertDialog.Builder(this).setTitle("أذونات التطبيق")
            .setItems(rows) { _, i ->
                if (!granted[i]) requestPermissions(arrayOf(perms[i]), 20 + i)
                else AlertDialog.Builder(this).setMessage("إذن ${names[i]} مفعّل بالفعل.").setPositiveButton("تمام", null).show()
            }
            .setPositiveButton("طلب كل الأذونات") { _, _ -> requestPermissions(perms, 1) }
            .setNegativeButton("رجوع") { _, _ -> settingsHub() }
            .show()
    }

    private fun settingsMenu() {
        fun on(k: String, d: Boolean) = prefs.getBoolean(k, d)
        fun onoff(k: String, d: Boolean) = if (on(k, d)) "شغّال" else "واقف"
        val items = arrayOf(
            "🔊 النطق التلقائي: ${onoff("speak", true)}",
            "⏩ سرعة النطق: ${arrayOf("بطيء", "عادي", "سريع")[prefs.getInt("rate", 1).coerceIn(0, 2)]}",
            "🗣 اختيار صوت النطق (طبيعي أكتر)",
            "🤖 الوكيل الذكي (ينفذ أي أمر بالشاشة): ${onoff("agent", true)}",
            "⚠ خطوات حساسة للوكيل (إرسال/حذف/دفع): ${if (on("sens", false)) "مسموحة" else "ممنوعة"}",
            "📏 طول الرد: ${arrayOf("مختصر", "متوسط", "مفصّل")[prefs.getInt("style", 1).coerceIn(0, 2)]}"
        )
        AlertDialog.Builder(this).setTitle("الإعدادات ⚙").setItems(items) { _, i ->
            var reopen = true
            when (i) {
                0 -> prefs.edit().putBoolean("speak", !on("speak", true)).apply()
                1 -> { prefs.edit().putInt("rate", (prefs.getInt("rate", 1) + 1) % 3).apply(); applyTts() }
                2 -> { voicePickMenu(); reopen = false }
                3 -> prefs.edit().putBoolean("agent", !on("agent", true)).apply()
                4 -> prefs.edit().putBoolean("sens", !on("sens", false)).apply()
                5 -> { val st = (prefs.getInt("style", 1) + 1) % 3; prefs.edit().putInt("style", st).apply(); llm.style = st }
            }
            if (reopen) settingsMenu()
        }.setPositiveButton("إغلاق", null).show()
    }

    override fun onDestroy() { sr?.destroy(); tts?.shutdown(); llm.release(); super.onDestroy() }
}
