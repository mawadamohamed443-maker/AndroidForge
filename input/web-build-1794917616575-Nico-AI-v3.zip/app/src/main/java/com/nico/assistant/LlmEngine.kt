package com.nico.assistant

import android.content.Context
import com.google.mediapipe.tasks.genai.llminference.LlmInference
import java.io.File

/** ذكاء اصطناعي محلي بالكامل (MediaPipe LLM) - بيجاوب على أي سؤال من غير نت. */
class LlmEngine(private val ctx: Context) {
    private var llm: LlmInference? = null
    private val history = ArrayList<Pair<String, String>>()
    private val prefs = ctx.getSharedPreferences("nico", Context.MODE_PRIVATE)

    /** الذاكرة طويلة المدى (اللي المستخدم قال "افتكر") بتتحط في تعليمات النظام. */
    var memory: String = ""
    var replyLang: Lang = Langs.byCode(prefs.getString("lang", "ar") ?: "ar")
    var style: Int = prefs.getInt("style", 1)

    private val dir get() = File(ctx.filesDir, "llm")
    val modelFile: File get() = dir.listFiles()?.firstOrNull { it.name.startsWith("model.") && it.length() > 0 } ?: File(dir, "model.task")
    fun targetFor(ext: String): File { dir.mkdirs(); dir.listFiles()?.filter { it.name.startsWith("model.") }?.forEach { it.delete() }; return File(dir, "model.$ext") }
    val installed: Boolean get() = modelFile.exists() && modelFile.length() > 1_000_000

    /** اسم الملف الأصلي بيحدد قالب المحادثة: gemma / qwen / plain وحجم السياق لو مكتوب (ekv1280). */
    fun setTemplateFrom(fileName: String) {
        val n = fileName.lowercase()
        val t = when { "gemma" in n -> "gemma"; "qwen" in n -> "qwen"; else -> "plain" }
        val ctxN = Regex("ekv(\\d+)").find(n)?.groupValues?.get(1)?.toIntOrNull() ?: 0
        prefs.edit().putString("llm_tpl", t).putInt("llm_ctx", ctxN).apply()
    }

    fun seed(pairs: List<Pair<String, String>>) { synchronized(this) { history.clear(); history.addAll(pairs.takeLast(8)) } }
    @Synchronized fun clearHistory() { history.clear() }

    @Synchronized
    fun release() { try { llm?.close() } catch (_: Throwable) {}; llm = null }

    @Synchronized
    fun load(): String? {
        if (llm != null) return null
        if (!installed) return "مفيش موديل ذكاء مثبت."
        return try {
            val known = prefs.getInt("llm_ctx", 0)
            val tries = if (known > 0) listOf(known) else listOf(4096, 2048, 1024)
            var last: Throwable? = null
            for (mt in tries) {
                try {
                    val o = LlmInference.LlmInferenceOptions.builder().setModelPath(modelFile.absolutePath).setMaxTokens(mt).build()
                    llm = LlmInference.createFromOptions(ctx, o); last = null; break
                } catch (e: Throwable) { last = e }
            }
            if (last != null) throw last
            null
        } catch (e: Throwable) {
            llm = null
            "فشل تحميل موديل الذكاء: ${e.message}"
        }
    }

    private fun system(): String {
        val len = when (style) { 0 -> "اختصر جداً (جملة أو اتنين)."; 2 -> "اشرح بتفصيل مناسب ومرتب."; else -> "رد باختصار ودقة." }
        val lang = if (replyLang.code == "ar") "رد دايماً بالعربي المصري البسيط والواضح" else "Always reply in ${replyLang.english}"
        return "أنت نيكو، مساعد شخصي ذكي وودود بيجاوب على أي سؤال في أي مجال. $lang. $len لو مش متأكد من معلومة قول إنك مش متأكد ومتألفش." +
            (if (memory.isNotBlank()) "\nمعلومات عن المستخدم (هو اللي قالها): $memory" else "")
    }

    private fun build(q: String, sys: String, useHist: Boolean): String {
        val h = if (useHist) history.takeLast(4).map { it.first.take(500) to it.second.take(700) } else emptyList()
        return when (prefs.getString("llm_tpl", "plain")) {
            "qwen" -> buildString {
                append("<|im_start|>system\n$sys<|im_end|>\n")
                h.forEach { append("<|im_start|>user\n${it.first}<|im_end|>\n<|im_start|>assistant\n${it.second}<|im_end|>\n") }
                append("<|im_start|>user\n$q<|im_end|>\n<|im_start|>assistant\n")
            }
            "gemma" -> buildString {
                var first = true
                h.forEach {
                    append("<start_of_turn>user\n${if (first) "$sys\n\n" else ""}${it.first}<end_of_turn>\n<start_of_turn>model\n${it.second}<end_of_turn>\n")
                    first = false
                }
                append("<start_of_turn>user\n${if (first) "$sys\n\n" else ""}$q<end_of_turn>\n<start_of_turn>model\n")
            }
            else -> buildString {
                append("$sys\n\n")
                h.forEach { append("سؤال: ${it.first}\nالجواب: ${it.second}\n\n") }
                append("سؤال: $q\nالجواب:")
            }
        }
    }

    /** نادّيها من thread خلفي. useHist=false للوكيل (من غير ما يلوّث سجل المحادثة). */
    @Synchronized
    fun generate(sys: String, q: String, useHist: Boolean): String {
        load()?.let { return it }
        return try {
            var r = llm!!.generateResponse(build(q, sys, useHist)).trim()
            r = r.replace("<end_of_turn>", "").replace("<|im_end|>", "").trim()
            if (r.isEmpty()) return "معرفتش أرد على ده."
            if (useHist) { history.add(q to r); while (history.size > 8) history.removeAt(0) }
            r
        } catch (e: Throwable) {
            "حصل خطأ في الذكاء: ${e.message}"
        }
    }

    fun ask(q: String): String = generate(system(), q, true)
}
