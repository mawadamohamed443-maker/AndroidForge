package com.nico.assistant

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import java.io.File
import java.io.FilterInputStream
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/**
 * تعرف على الصوت أوفلاين (Vosk) بعدة لغات. كل لغة بتتنزل مرة واحدة (بنت أول مرة) وبعدها بتشتغل من غير نت.
 * العربي ممكن يتدمج في assets/model-ar أو يتنزل/يتستورد.
 */
class VoskSpeech(private val ctx: Context) {
    private var model: Model? = null
    private var loadedLang = ""
    private var svc: SpeechService? = null
    private val prefs = ctx.getSharedPreferences("nico", Context.MODE_PRIVATE)
    var listening = false; private set

    var lang: String
        get() = prefs.getString("lang", "ar") ?: "ar"
        set(v) { prefs.edit().putString("lang", v).apply() }

    fun dirFor(code: String) = File(ctx.filesDir, "vosk/$code")
    private fun valid(d: File) = File(d, "am").isDirectory && File(d, "conf").isDirectory
    private fun hasAsset(): Boolean = try { ctx.assets.list("model-ar")?.isNotEmpty() == true } catch (_: Exception) { false }
    fun installed(code: String) = valid(dirFor(code)) || (code == "ar" && hasAsset())
    fun available() = installed(lang)

    private fun copyAsset(path: String, out: File) {
        val kids = ctx.assets.list(path) ?: emptyArray()
        if (kids.isEmpty()) {
            out.parentFile?.mkdirs()
            ctx.assets.open(path).use { i -> out.outputStream().use { o -> i.copyTo(o, 1 shl 20) } }
        } else kids.forEach { copyAsset("$path/$it", File(out, it)) }
    }

    @Synchronized
    fun load(): String? {
        if (model != null && loadedLang == lang) return null
        release()
        return try {
            val d = dirFor(lang)
            if (!valid(d)) {
                if (lang == "ar" && hasAsset()) { d.deleteRecursively(); copyAsset("model-ar", d) }
                if (!valid(d)) return "اللغة دي مش منزلة. نزّليها من زر اللغات."
            }
            model = Model(d.absolutePath); loadedLang = lang; null
        } catch (e: Throwable) { model = null; "فشل تحميل موديل الصوت: ${e.message}" }
    }

    private class Counting(i: InputStream, val onBytes: (Long) -> Unit) : FilterInputStream(i) {
        var n = 0L
        override fun read(): Int { val r = super.read(); if (r >= 0) { n++; onBytes(n) }; return r }
        override fun read(b: ByteArray, off: Int, len: Int): Int { val r = super.read(b, off, len); if (r > 0) { n += r; onBytes(n) }; return r }
    }

    /** بيفك zip من أي stream لفولدر اللغة. بيرجع null لو نجح. */
    fun installStream(code: String, input: InputStream, progress: (String) -> Unit): String? {
        if (code == lang) release()
        val tmp = File(ctx.filesDir, "vosk-tmp-$code")
        return try {
            tmp.deleteRecursively(); tmp.mkdirs()
            val root = tmp.canonicalPath + File.separator
            var n = 0
            ZipInputStream(input.buffered()).use { z ->
                while (true) {
                    val e = z.nextEntry ?: break
                    val f = File(tmp, e.name)
                    if (!f.canonicalPath.startsWith(root)) continue // حماية zip-slip
                    if (e.isDirectory) f.mkdirs() else {
                        f.parentFile?.mkdirs()
                        f.outputStream().use { o -> z.copyTo(o, 1 shl 20) }
                        if (++n % 15 == 0) progress("بفك الموديل… $n ملف")
                    }
                }
            }
            val src = tmp.walkTopDown().firstOrNull { it.isDirectory && valid(it) }
                ?: return "الملف ده مش موديل صوت صحيح (مفيش am و conf)."
            val dst = dirFor(code); dst.deleteRecursively(); dst.parentFile?.mkdirs()
            if (!src.renameTo(dst)) src.copyRecursively(dst, true)
            null
        } catch (e: Throwable) { "فشل التثبيت: ${e.message}" }
        finally { tmp.deleteRecursively() }
    }

    /** تنزيل لغة من النت (أول مرة بس). */
    fun download(l: Lang, progress: (String) -> Unit): String? {
        var c: HttpURLConnection? = null
        return try {
            c = (URL(Langs.url(l)).openConnection() as HttpURLConnection).apply { connectTimeout = 15000; readTimeout = 30000; instanceFollowRedirects = true }
            if (c.responseCode != 200) return "السيرفر رد بكود ${c.responseCode}. جربي بعدين."
            val total = c.contentLengthLong.takeIf { it > 0 } ?: (l.mb * 1_000_000L)
            var last = 0L
            val cin = Counting(c.inputStream) { n ->
                val now = System.currentTimeMillis()
                if (now - last > 400) { last = now; progress("بنزّل ${l.label}… ${(n * 100 / total).coerceAtMost(99)}%") }
            }
            installStream(l.code, cin, progress)
        } catch (e: java.io.IOException) { "مفيش اتصال بالنت أو الاتصال اتقطع. التنزيل بيحتاج نت أول مرة بس." }
        catch (e: Throwable) { "فشل التنزيل: ${e.message}" }
        finally { c?.disconnect() }
    }

    fun delete(code: String) { if (code == lang) release(); dirFor(code).deleteRecursively() }

    fun start(onPartial: (String) -> Unit, onFinal: (String) -> Unit, onError: (String) -> Unit) {
        val m = model ?: return onError("الموديل مش محمّل.")
        try {
            stop()
            svc = SpeechService(Recognizer(m, 16000f), 16000f)
            listening = true
            svc!!.startListening(object : org.vosk.android.RecognitionListener {
                override fun onPartialResult(h: String?) {
                    val t = try { JSONObject(h ?: "{}").optString("partial") } catch (_: Exception) { "" }
                    if (t.isNotBlank()) onPartial(t)
                }
                override fun onResult(h: String?) {
                    val t = try { JSONObject(h ?: "{}").optString("text") } catch (_: Exception) { "" }
                    if (t.isNotBlank()) { stop(); onFinal(t) }
                }
                override fun onFinalResult(h: String?) {}
                override fun onError(e: Exception?) { stop(); onError(e?.message ?: "خطأ في الميكروفون") }
                override fun onTimeout() { stop(); onFinal("") }
            }, 12000)
        } catch (e: Throwable) { listening = false; onError(e.message ?: "تعذر تشغيل الميكروفون") }
    }

    fun stop() { listening = false; try { svc?.stop(); svc?.shutdown() } catch (_: Throwable) {}; svc = null }
    @Synchronized fun release() { stop(); try { model?.close() } catch (_: Throwable) {}; model = null; loadedLang = "" }
}
