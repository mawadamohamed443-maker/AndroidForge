package com.nico.assistant

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import kotlin.math.min
import kotlin.math.sin

/** كرة مائية متحركة بتتفاعل مع حالة نيكو: خامل / بيسمع / بيفكر / بيتكلم. */
class WaterOrbView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    enum class State { IDLE, LISTENING, THINKING, SPEAKING }

    var state = State.IDLE
    private var target = 0f
    private var level = 0f
    private var amp = 0.02f
    private val t0 = System.nanoTime()

    /** نبضة من الصوت (0..1) */
    fun pulse(v: Float = 1f) { target = v.coerceIn(0f, 1f) }

    private var cx = 0f; private var cy = 0f; private var r = 0f
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val clip = Path()
    private val wave = Path()
    private var bg: Shader? = null
    private var water1: Shader? = null
    private var water2: Shader? = null
    private var shine: Shader? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        cx = w / 2f; cy = h / 2f; r = min(w, h) / 2f * 0.70f
        clip.reset(); clip.addCircle(cx, cy, r, Path.Direction.CW)
        bg = RadialGradient(cx, cy, r, intArrayOf(0xFF0A2038.toInt(), 0xFF050B18.toInt()), null, Shader.TileMode.CLAMP)
        water1 = LinearGradient(0f, cy - r, 0f, cy + r,
            intArrayOf(0xCC2EE6D6.toInt(), 0xDD1486C8.toInt(), 0xEE0B3D8F.toInt()), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        water2 = LinearGradient(0f, cy - r, 0f, cy + r,
            intArrayOf(0x887CF5EA.toInt(), 0x881E9BE0.toInt(), 0x88104BA8.toInt()), floatArrayOf(0f, .5f, 1f), Shader.TileMode.CLAMP)
        shine = RadialGradient(cx - r * .35f, cy - r * .45f, r * .75f,
            intArrayOf(0x66FFFFFF, 0x00FFFFFF), null, Shader.TileMode.CLAMP)
    }

    private fun drawWave(cv: Canvas, level: Float, a: Float, k: Float, phase: Float, sh: Shader?) {
        wave.reset()
        val left = cx - r; val right = cx + r; val bottom = cy + r
        wave.moveTo(left, bottom)
        var x = left
        while (x <= right + 6f) {
            wave.lineTo(x, level + a * sin(x * k + phase))
            x += 6f
        }
        wave.lineTo(right, bottom); wave.close()
        p.reset(); p.isAntiAlias = true; p.shader = sh
        cv.drawPath(wave, p)
    }

    override fun onDraw(cv: Canvas) {
        if (r <= 0f) return
        val t = (System.nanoTime() - t0) / 1e9f

        target *= 0.93f
        level += (target - level) * 0.18f
        val tgtAmp = when (state) {
            State.IDLE -> 0.035f
            State.LISTENING -> 0.05f + 0.12f * level
            State.THINKING -> 0.07f
            State.SPEAKING -> 0.06f + 0.07f * (0.5f + 0.5f * sin(t * 9f))
        }
        amp += (tgtAmp - amp) * 0.08f
        val speed = if (state == State.THINKING) 4.5f else if (state == State.IDLE) 1.4f else 2.6f
        val scale = 1f + when (state) {
            State.IDLE -> 0.015f * sin(t * 1.5f)
            State.LISTENING -> 0.02f + 0.06f * level
            State.THINKING -> 0.02f * sin(t * 3f)
            State.SPEAKING -> 0.03f * sin(t * 8f)
        }

        cv.save(); cv.scale(scale, scale, cx, cy)

        // هالة
        for (i in 7 downTo 1) {
            p.reset(); p.isAntiAlias = true
            p.color = 0x2E86F0; p.alpha = (9 + 3 * (8 - i)).coerceAtMost(40)
            if (state == State.LISTENING) p.alpha = (p.alpha + 20 * level).toInt().coerceAtMost(90)
            cv.drawCircle(cx, cy, r + i * r * 0.05f, p)
        }

        cv.save(); cv.clipPath(clip)
        p.reset(); p.isAntiAlias = true; p.shader = bg; cv.drawCircle(cx, cy, r, p)
        val lvl = cy + r * (0.12f - 0.10f * level)
        val a = r * amp
        drawWave(cv, lvl + r * .04f, a * 1.2f, 0.021f, -t * speed * 0.8f + 1.7f, water2)
        drawWave(cv, lvl, a, 0.017f, t * speed, water1)
        // فقاعات صغيرة
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE; p.strokeWidth = 2f; p.color = 0x99BFF6FF.toInt()
        for (i in 0 until 5) {
            val bt = (t * (0.15f + i * 0.04f) + i * 0.37f) % 1f
            val bx = cx + r * 0.55f * sin(i * 2.3f + t * 0.4f)
            val by = cy + r - bt * r * 1.5f
            if (by > lvl) cv.drawCircle(bx, by, r * (0.02f + 0.012f * i), p)
        }
        cv.restore()

        // زجاج + لمعة
        p.reset(); p.isAntiAlias = true; p.shader = shine; cv.drawCircle(cx, cy, r, p)
        p.reset(); p.isAntiAlias = true; p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.025f; p.color = 0xCC7CF5EA.toInt(); cv.drawCircle(cx, cy, r, p)

        if (state == State.THINKING) {
            p.strokeWidth = r * 0.045f; p.strokeCap = Paint.Cap.ROUND; p.color = 0xFFFFFFFF.toInt()
            cv.drawArc(cx - r * 1.1f, cy - r * 1.1f, cx + r * 1.1f, cy + r * 1.1f, t * 220f, 70f, false, p)
        }
        cv.restore()
        postInvalidateOnAnimation()
    }
}
